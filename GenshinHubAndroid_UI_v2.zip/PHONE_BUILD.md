# Build the APK from an Android phone

This project includes a GitHub Actions workflow that builds the APK in the cloud.

1. On your phone, open GitHub in Chrome and sign in.
2. Create a new repository, for example `GenshinHub`.
3. Upload all files from this project ZIP to the repository (the `.github/workflows/build-apk.yml` file must also be uploaded).
4. Open the repository's **Actions** tab.
5. Select **Build Android APK**.
6. Tap **Run workflow** and choose the `main` branch.
7. Wait for the workflow to finish.
8. Open the completed workflow run and download the artifact named **GenshinHub-debug-apk**.
9. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

If Android asks for permission to install apps from the browser/file manager, allow it for that app and then install the APK.

Important:
- This is a debug APK for testing, not a Play Store release.
- The current prototype uses stylized placeholder artwork rather than the game's copyrighted character images.
