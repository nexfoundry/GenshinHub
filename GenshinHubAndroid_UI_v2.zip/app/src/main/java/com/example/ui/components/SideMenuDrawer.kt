package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.R
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.TextMuted
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

private data class SideMenuItem(
  val title: String,
  val icon: ImageVector,
  val tag: String
)

private val menuItems = listOf(
  SideMenuItem("Home", Icons.Rounded.Home, "home"),
  SideMenuItem("Character Builds", Icons.Rounded.ViewList, "character_builds"),
  SideMenuItem("My Character", Icons.Rounded.Person, "my_character"),
  SideMenuItem("My Weapon", Icons.Rounded.Shield, "my_weapon"),
  SideMenuItem("My Wish", Icons.Rounded.AutoAwesome, "my_wish"),
  SideMenuItem("Settings", Icons.Rounded.Settings, "settings")
)

/**
 * Sliding side drawer menu overlay for Genshin HUB.
 *
 * 1) Scrim: full-screen dimmed scrim behind drawer (tapping dismisses). Alpha dynamically
 *    fades out proportionally as the drawer is dragged to close.
 * 2) Panel: width 300.dp, full height, right edge rounded corners (topEnd = 20.dp, bottomEnd = 20.dp),
 *    dark navy gradient background from 0xFF12141C to 0xFF0B0C14, 16.dp right-edge shadow elevation.
 * 3) Drag gesture & physics:
 *    - Leftward drag tracks finger position, clamped between -drawerWidthPx and 0f.
 *    - If dragged > 35% of panel width OR fling velocity < -1000f: animates closed (tween 200ms) and dismisses.
 *    - Otherwise: snaps back open with spring animation (DampingRatioLowBouncy, StiffnessMedium).
 *    - Resets offset to 0f whenever drawer is reopened.
 * 4) Header:
 *    - 64.dp rounded-square avatar (RoundedCornerShape(16.dp)), no border.
 *    - Bold "Traveler" (18.sp, white) and subtitle "AR 60 • World Lv. 9" (13.sp, gold/amber).
 *    - Two support buttons side-by-side: "Support on Ko-fi" and "Support on Trakteer".
 *    - No "X" close icon button anywhere in the drawer header (dismissal via drag or scrim tap).
 * 5) Menu items:
 *    - All items render with transparent idle background (no selection tint or highlights).
 *    - Ripple on touch, 24.dp icon (PurplePrimary) + 15.sp label, 4.dp item spacing.
 * 6) Footer: "App Version 1.0.0" 11.sp TextMuted centered, with navigation bar insets + bottom breathing room.
 * 7) Layering: topmost overlay via Modifier.zIndex(100f).
 */
@Composable
fun SideMenuDrawer(
  visible: Boolean,
  onDismiss: () -> Unit,
  onMenuItemClick: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val density = LocalDensity.current
  val drawerWidthDp = 300.dp
  val drawerWidthPx = with(density) { drawerWidthDp.toPx() }
  val offsetX = remember { Animatable(0f) }
  val coroutineScope = rememberCoroutineScope()

  // Reset horizontal drag offset whenever the drawer is displayed
  LaunchedEffect(visible) {
    if (visible) {
      offsetX.snapTo(0f)
    }
  }

  // Draggable state for tracking drag amount, clamping strictly between -drawerWidthPx and 0f
  val draggableState = rememberDraggableState { delta ->
    coroutineScope.launch {
      val newOffset = (offsetX.value + delta).coerceIn(-drawerWidthPx, 0f)
      offsetX.snapTo(newOffset)
    }
  }

  // Fade scrim alpha proportionally with drag offset for connected physical feel
  val scrimAlpha = (0.6f * (1f - (abs(offsetX.value) / drawerWidthPx))).coerceIn(0f, 0.6f)

  AnimatedVisibility(
    visible = visible,
    enter = fadeIn(animationSpec = tween(220)),
    exit = fadeOut(animationSpec = tween(220)),
    modifier = modifier
      .fillMaxSize()
      .zIndex(100f)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .testTag("side_menu_drawer_overlay")
    ) {
      // 1. Scrim overlay: full-screen dimmed scrim behind drawer (tapping dismisses)
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black.copy(alpha = scrimAlpha))
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onDismiss
          )
          .testTag("side_menu_scrim")
      )

      // 2. Sliding side panel (positioned at Alignment.CenterStart, width 300.dp, full height)
      Box(
        modifier = Modifier
          .align(Alignment.CenterStart)
          .offset { IntOffset(offsetX.value.roundToInt(), 0) }
          .width(drawerWidthDp)
          .fillMaxHeight()
          .animateEnterExit(
            enter = slideInHorizontally(
              initialOffsetX = { -it },
              animationSpec = tween(280, easing = FastOutSlowInEasing)
            ),
            exit = slideOutHorizontally(
              targetOffsetX = { -it },
              animationSpec = tween(220, easing = FastOutSlowInEasing)
            )
          )
          .shadow(
            elevation = 16.dp,
            shape = RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp),
            spotColor = Color.Black.copy(alpha = 0.8f),
            ambientColor = Color.Black.copy(alpha = 0.8f)
          )
          .clip(RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp))
          .background(
            Brush.verticalGradient(
              colors = listOf(Color(0xFF12141C), Color(0xFF0B0C14))
            )
          )
          .border(
            width = 1.dp,
            color = Color(0x1FFFFFFF),
            shape = RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp)
          )
          .draggable(
            state = draggableState,
            orientation = Orientation.Horizontal,
            onDragStopped = { velocity ->
              val draggedPercent = abs(offsetX.value) / drawerWidthPx
              val shouldClose = if (velocity < -1000f) {
                true
              } else if (velocity > 1000f) {
                false
              } else {
                draggedPercent > 0.35f
              }

              if (shouldClose) {
                offsetX.animateTo(-drawerWidthPx, animationSpec = tween(200))
                onDismiss()
              } else {
                offsetX.animateTo(
                  0f,
                  animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMedium
                  )
                )
              }
            }
          )
          // Consume clicks inside panel so tapping does not dismiss via scrim
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = {}
          )
          .testTag("side_menu_panel")
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars),
          verticalArrangement = Arrangement.SpaceBetween
        ) {
          // Top & Middle Section: Header + Divider + Menu Items
          Column(modifier = Modifier.fillMaxWidth()) {
            // Header Section
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 8.dp)
            ) {
              // Avatar + Name + Subtitle (NO close "X" button)
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
              ) {
                // 64.dp rounded-square avatar (RoundedCornerShape(16.dp)), no border
                Box(
                  modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1E2130)),
                  contentAlignment = Alignment.Center
                ) {
                  Image(
                    painter = painterResource(id = R.drawable.character),
                    contentDescription = "Traveler Avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                      .fillMaxSize()
                      .clip(RoundedCornerShape(16.dp))
                  )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                  Text(
                    text = "Traveler",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "AR 60 • World Lv. 9",
                    color = Color(0xFFFBBF24).copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                  )
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              // Two side-by-side support buttons: Ko-fi and Trakteer
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                // Button 1: Support on Ko-fi
                Surface(
                  onClick = {},
                  modifier = Modifier
                    .weight(1f)
                    .height(42.dp),
                  shape = RoundedCornerShape(10.dp),
                  color = Color.Transparent,
                  border = BorderStroke(1.dp, Color(0x33FFFFFF))
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxSize()
                      .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.LocalCafe,
                      contentDescription = "Ko-fi",
                      tint = Color(0xFFFF5E5B),
                      modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "Support on\nKo-fi",
                      color = Color.White,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Medium,
                      lineHeight = 12.sp,
                      textAlign = TextAlign.Center
                    )
                  }
                }

                // Button 2: Support on Trakteer
                Surface(
                  onClick = {},
                  modifier = Modifier
                    .weight(1f)
                    .height(42.dp),
                  shape = RoundedCornerShape(10.dp),
                  color = Color.Transparent,
                  border = BorderStroke(1.dp, Color(0x33FFFFFF))
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxSize()
                      .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.WaterDrop,
                      contentDescription = "Trakteer",
                      tint = Color(0xFFE53935),
                      modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "Support on\nTrakteer",
                      color = Color.White,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Medium,
                      lineHeight = 12.sp,
                      textAlign = TextAlign.Center
                    )
                  }
                }
              }
            }

            // Divider below header with 16.dp vertical spacing above and below
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(
              modifier = Modifier.padding(horizontal = 24.dp),
              color = Color(0x1AFFFFFF),
              thickness = 1.dp
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Menu Items List (consistent 4.dp spacing, identical idle state for all rows)
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              menuItems.forEach { item ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(
                      interactionSource = remember { MutableInteractionSource() },
                      indication = ripple(bounded = true, color = Color.White.copy(alpha = 0.2f)),
                      onClick = { onMenuItemClick(item.title) }
                    )
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .testTag("menu_item_${item.tag}"),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    imageVector = item.icon,
                    contentDescription = item.title,
                    tint = PurplePrimary,
                    modifier = Modifier.size(24.dp)
                  )

                  Spacer(modifier = Modifier.width(16.dp))

                  Text(
                    text = item.title,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                  )
                }
              }
            }
          }

          // Footer: App version text with navigation bar insets + bottom breathing room
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .windowInsetsPadding(WindowInsets.navigationBars)
              .padding(top = 16.dp, bottom = 24.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "App Version 1.0.0",
              color = TextMuted,
              fontSize = 11.sp,
              fontWeight = FontWeight.Normal,
              modifier = Modifier.testTag("side_menu_version_text")
            )
          }
        }
      }
    }
  }
}
