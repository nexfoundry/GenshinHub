package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.util.rememberSubtleHaptics

// ---------- Data model ----------
data class NavItem(
    @DrawableRes val iconRes: Int,
    val label: String
)

val navItems = listOf(
    NavItem(R.drawable.ic_nav_characters, "Characters"),
    NavItem(R.drawable.ic_nav_weapons, "Weapons"),
    NavItem(R.drawable.ic_nav_artifacts, "Artifacts"),
    NavItem(R.drawable.ic_nav_teams, "Teams"),
    NavItem(R.drawable.ic_nav_tier_list, "Tier List")
)

// Purple gradient: #8E2DE2 to #6A11CB at 135 degrees
private val purpleGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF8E2DE2), Color(0xFF6A11CB)),
    start = Offset(0f, 0f),
    end = Offset.Infinite
)

// ---------- Bottom Nav Bar ----------
@Composable
fun FloatingBottomNavBar(
    selectedIndex: Int,
    onItemSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 8.dp)
            .height(68.dp)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(34.dp),
                spotColor = Color(0x66000000),
                ambientColor = Color(0x66000000)
            )
            .clip(RoundedCornerShape(34.dp))
            .background(Color(0xFF12141C))
            .border(
                width = 1.dp,
                color = Color(0x1AFFFFFF),
                shape = RoundedCornerShape(34.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        // Inner capsule row (height: 56.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEachIndexed { index, item ->
                val isSelected = index == selectedIndex

                NavBarItem(
                    item = item,
                    isSelected = isSelected,
                    onClick = { onItemSelected(index) }
                )
            }
        }
    }
}

@Composable
private fun RowScope.NavBarItem(
    item: NavItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val subtleHaptics = rememberSubtleHaptics()
    val interactionSource = remember { MutableInteractionSource() }

    // Immediate, lightweight animation tuned for instant responsive feel upon tap
    val navAnimSpec = remember {
        tween<Float>(durationMillis = 140, easing = FastOutSlowInEasing)
    }

    // 1. weight animation: immediate flex growth for the active capsule
    // Target weight: 2.4f for selected vs 1f for others; applies to all items simultaneously
    val flexGrow by animateFloatAsState(
        targetValue = if (isSelected) 2.4f else 1.0f,
        animationSpec = navAnimSpec,
        label = "item_weight_${item.label}"
    )

    // 2. Background gradient alpha transition
    val bgAlpha by animateFloatAsState(
        targetValue = if (isSelected) 1f else 0f,
        animationSpec = navAnimSpec,
        label = "item_bg_alpha_${item.label}"
    )

    Box(
        modifier = Modifier
            .weight(flexGrow, fill = true)
            .height(56.dp)
            .clip(RoundedCornerShape(28.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = Color.White.copy(alpha = 0.25f)),
                onClick = {
                    subtleHaptics.performTabSelect()
                    onClick()
                }
            )
            .testTag("nav_tab_${item.label.lowercase().replace(" ", "_")}"),
        contentAlignment = Alignment.Center
    ) {
        // Purple gradient background capsule (#8E2DE2 to #6A11CB, 135deg)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = bgAlpha }
                .background(purpleGradient, RoundedCornerShape(28.dp))
        )

        Row(
            modifier = Modifier.padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = item.iconRes),
                contentDescription = item.label,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("nav_icon_${item.label.lowercase().replace(" ", "_")}")
            )

            // Immediate, fluid animated visibility for label
            AnimatedVisibility(
                visible = isSelected,
                enter = expandHorizontally(
                    animationSpec = tween(durationMillis = 140, easing = FastOutSlowInEasing),
                    expandFrom = Alignment.Start
                ) + fadeIn(
                    animationSpec = tween(durationMillis = 120)
                ),
                exit = shrinkHorizontally(
                    animationSpec = tween(durationMillis = 120, easing = FastOutSlowInEasing),
                    shrinkTowards = Alignment.Start
                ) + fadeOut(
                    animationSpec = tween(durationMillis = 80)
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.label,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}

// ---------- Preview Usage ----------
@Composable
fun BottomNavBarPreviewUsage() {
    var selected by remember { mutableStateOf(0) }

    FloatingBottomNavBar(
        selectedIndex = selected,
        onItemSelected = { selected = it }
    )
}
