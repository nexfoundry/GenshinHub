package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.Character
import com.example.model.ElementType
import com.example.model.SampleCharacters
import com.example.model.SampleWeapons
import com.example.model.Weapon
import com.example.model.WeaponType
import com.example.ui.components.BottomNavItem
import com.example.ui.components.CharacterDetailDialog
import com.example.ui.components.CharacterDetailScreen
import com.example.ui.components.CharacterGridCard
import com.example.ui.components.CharacterListCard
import com.example.ui.components.FeatureBanner
import com.example.ui.components.FloatingBottomNavBar
import com.example.ui.components.RedemptionCodesSheet
import com.example.ui.components.SearchAndFilterBar
import com.example.ui.components.SideMenuDrawer
import com.example.ui.components.TeamsPartyContent
import com.example.ui.components.TopHeader
import com.example.ui.components.WeaponCard
import com.example.ui.theme.BackgroundNavy
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.rememberSubtleHaptics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GenshinHubScreen(
  modifier: Modifier = Modifier,
  viewModel: GenshinHubViewModel = viewModel(),
) {
  val snackbarHostState = remember { SnackbarHostStateStateWrapper() }
  val scope = rememberCoroutineScope()

  // State
  var searchQuery by remember { mutableStateOf("") }
  var selectedElement by remember { mutableStateOf<ElementType?>(null) }
  var showFavoritesOnly by remember { mutableStateOf(false) }
  var isGridView by remember { mutableStateOf(true) }
  var selectedIndex by remember { mutableIntStateOf(0) }
  var selectedTopCategory by remember { mutableStateOf("CHARACTERS") }
  var selectedCharacterDetail by remember { mutableStateOf<Character?>(null) }
  var showRedemptionSheet by remember { mutableStateOf(false) }
  var showSideMenu by remember { mutableStateOf(false) }

  // Character list and pull-to-refresh state from Room Database ViewModel
  val characters by viewModel.characters.collectAsStateWithLifecycle()
  val activeParty by viewModel.activeParty.collectAsStateWithLifecycle()
  val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
  val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

  // Scroll state for Character List driving TopHeader shrink and fade animation
  val characterListState = rememberLazyListState()

  val characterScrollFraction by remember {
    derivedStateOf {
      if (characterListState.firstVisibleItemIndex > 0) {
        1f
      } else {
        (characterListState.firstVisibleItemScrollOffset / 260f).coerceIn(0f, 1f)
      }
    }
  }

  val animatedHeaderScrollFraction by animateFloatAsState(
    targetValue = if (selectedIndex == 0) characterScrollFraction else 0f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "top_header_scroll_anim"
  )

  // Filtered characters
  val filteredCharacters by remember {
    derivedStateOf {
      characters.filter { char ->
        val matchesElement = selectedElement == null || char.element == selectedElement
        val matchesSearch = searchQuery.isBlank() ||
          char.name.contains(searchQuery, ignoreCase = true) ||
          char.title.contains(searchQuery, ignoreCase = true) ||
          char.weapon.displayName.contains(searchQuery, ignoreCase = true)
        val matchesFavorite = !showFavoritesOnly || char.isFavorite

        matchesElement && matchesSearch && matchesFavorite
      }
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(BackgroundNavy)
  ) {
    // 1. Main Application Shell: Contains the main Scaffold with bottomBar slot
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      containerColor = BackgroundNavy,
      snackbarHost = { SnackbarHost(snackbarHostState.state) },
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      bottomBar = {
        if (selectedCharacterDetail == null) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    Color.Transparent,
                    Color(0xFF0B0C14).copy(alpha = 0.5f),
                    Color(0xFF0B0C14)
                  )
                )
              )
              .windowInsetsPadding(WindowInsets.navigationBars)
              .padding(top = 8.dp, bottom = 4.dp),
            contentAlignment = Alignment.Center
          ) {
            FloatingBottomNavBar(
              selectedIndex = selectedIndex,
              onItemSelected = { index ->
                selectedIndex = index
                selectedCharacterDetail = null
                selectedTopCategory = when (index) {
                  0 -> "CHARACTERS"
                  1 -> "BUILDS"
                  2 -> "ARTIFACTS"
                  3 -> "GUIDES"
                  4 -> "MORE"
                  else -> "CHARACTERS"
                }
              },
              modifier = Modifier.testTag("bottom_nav")
            )
          }
        }
      }
    ) { _ ->
      Column(
        modifier = Modifier
          .fillMaxSize()
          .windowInsetsPadding(WindowInsets.statusBars)
      ) {
        // Top Header with scroll-based shrink and fade animation
        TopHeader(
          onMenuClick = {
            showSideMenu = true
          },
          onSearchClick = {
            snackbarHostState.show(scope, "Notifications: Version 5.6 Lunar New Banners are live!")
          },
          onTicketClick = {
            showRedemptionSheet = true
          },
          selectedCategory = selectedTopCategory,
          onCategoryClick = { category ->
            selectedTopCategory = category
            selectedCharacterDetail = null
            when (category) {
              "CHARACTERS" -> selectedIndex = 0
              "BUILDS" -> selectedIndex = 1
              "GUIDES" -> selectedIndex = 3
              "MORE" -> selectedIndex = 4
            }
          },
          scrollFraction = animatedHeaderScrollFraction,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("top_header")
        )

        // Main Content Area taking remaining space
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
        ) {
          // Lightweight, fluid page crossfade transition with zero layout shifting or lag
          Crossfade(
            targetState = selectedIndex,
            animationSpec = tween(durationMillis = 140, easing = FastOutSlowInEasing),
            modifier = Modifier.fillMaxSize(),
            label = "tab_screen_transition"
          ) { targetIndex ->
            when (targetIndex) {
              0 -> {
                CharactersContent(
                  searchQuery = searchQuery,
                  onSearchQueryChange = { searchQuery = it },
                  selectedElement = selectedElement,
                  onElementSelect = { element ->
                    selectedElement = if (selectedElement == element) null else element
                  },
                  isGridView = isGridView,
                  onViewToggle = { isGridView = it },
                  filteredCharacters = filteredCharacters,
                  onCharacterClick = { selectedCharacterDetail = it },
                  onFavoriteToggle = { char ->
                    viewModel.toggleFavorite(char)
                    val status = if (!char.isFavorite) "Added to Favorites" else "Removed from Favorites"
                    snackbarHostState.show(scope, "${char.name} $status")
                  },
                  showFavoritesOnly = showFavoritesOnly,
                  onFavoritesClick = {
                    showFavoritesOnly = !showFavoritesOnly
                    val msg = if (showFavoritesOnly) "Showing Favorites only" else "Showing all characters"
                    snackbarHostState.show(scope, msg)
                  },
                  onBannerClick = { banner ->
                    val bannerChar = if (banner.id == "astral_actuation") {
                      characters.firstOrNull { it.id == "ineffa" }
                    } else {
                      characters.firstOrNull { it.id == "flins" }
                    } ?: characters.firstOrNull() ?: SampleCharacters.list.first()
                    selectedCharacterDetail = bannerChar
                  },
                  isLoading = isLoading,
                  isRefreshing = isRefreshing,
                  onRefresh = {
                    viewModel.refresh()
                    snackbarHostState.show(scope, "Refetched characters from database")
                  },
                  listState = characterListState
                )
              }
              1 -> {
                WeaponsContent(
                  onWeaponClick = { weapon ->
                    snackbarHostState.show(scope, "${weapon.name} (${weapon.rarity}★ ${weapon.type.displayName})")
                  }
                )
              }
              2 -> {
                CompanionPlaceholderView(
                  title = "Artifact Sets",
                  subtitle = "Noblesse Oblige, Deepwood Memories, Golden Troupe & more",
                  badge = "48 Sets"
                )
              }
              3 -> {
                TeamsPartyContent(
                  activeParty = activeParty,
                  allCharacters = characters,
                  onAddToParty = { char ->
                    val added = viewModel.addToParty(char)
                    if (added) {
                      snackbarHostState.show(scope, "${char.name} added to party lineup!")
                    } else {
                      snackbarHostState.show(scope, "${char.name} is already in active party!")
                    }
                  },
                  onRemoveFromParty = { charId ->
                    viewModel.removeFromParty(charId)
                  },
                  onClearParty = {
                    viewModel.clearParty()
                    snackbarHostState.show(scope, "Active party lineup cleared")
                  },
                  onCharacterClick = { char ->
                    selectedCharacterDetail = char
                  }
                )
              }
              4 -> {
                CompanionPlaceholderView(
                  title = "Tier List Archive",
                  subtitle = "Explore top character rankings, abyss evaluations, and meta ratings",
                  badge = "Meta Tier List"
                )
              }
            }
          }
        }
      }
    }

    // 2. Detail / Sub-screens: Displayed outside the main Bottom Navigation shell
    // Takes full available screen height; Bottom Navigation is completely hidden.
    // When the user presses back/dismiss, smoothly reveals the main screen with Bottom Navigation intact.
    AnimatedVisibility(
      visible = selectedCharacterDetail != null,
      enter = fadeIn(tween(180)),
      exit = fadeOut(tween(150))
    ) {
      selectedCharacterDetail?.let { character ->
        CharacterDetailScreen(
          character = character,
          modifier = Modifier.fillMaxSize(),
          onDismiss = { selectedCharacterDetail = null },
          onFavoriteToggle = { char ->
            viewModel.toggleFavorite(char)
            val updated = char.copy(isFavorite = !char.isFavorite)
            selectedCharacterDetail = updated
          },
          onAddToTeam = { char ->
            val added = viewModel.addToParty(char)
            if (added) {
              snackbarHostState.show(scope, "${char.name} added to Active Party (${viewModel.activeParty.value.size}/4)!")
            } else {
              snackbarHostState.show(scope, "${char.name} is already in Active Party!")
            }
          }
        )
      }
    }

    // 3. Redemption Codes Bottom Sheet (compact bottom sheet matching visual reference)
    AnimatedVisibility(
      visible = showRedemptionSheet,
      enter = fadeIn(tween(200)) + slideInVertically(
        initialOffsetY = { it },
        animationSpec = tween(300, easing = FastOutSlowInEasing)
      ),
      exit = fadeOut(tween(180)) + slideOutVertically(
        targetOffsetY = { it },
        animationSpec = tween(250, easing = FastOutSlowInEasing)
      )
    ) {
      RedemptionCodesSheet(
        onDismiss = { showRedemptionSheet = false },
        onCodeCopied = { code ->
          snackbarHostState.show(scope, "Copied $code to clipboard!")
        }
      )
    }

    // 4. Sliding Side Menu Drawer (highest zIndex / placed last in Box stack as full-screen overlay)
    SideMenuDrawer(
      visible = showSideMenu,
      onDismiss = { showSideMenu = false },
      onMenuItemClick = { title ->
        showSideMenu = false
        snackbarHostState.show(scope, "Selected: $title")
      }
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CharactersContent(
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  selectedElement: ElementType?,
  onElementSelect: (ElementType) -> Unit,
  isGridView: Boolean,
  onViewToggle: (Boolean) -> Unit,
  filteredCharacters: List<Character>,
  onCharacterClick: (Character) -> Unit,
  onFavoriteToggle: (Character) -> Unit,
  showFavoritesOnly: Boolean = false,
  onFavoritesClick: (() -> Unit)? = null,
  onBannerClick: (com.example.ui.components.BannerItem) -> Unit,
  isLoading: Boolean = false,
  isRefreshing: Boolean,
  onRefresh: () -> Unit,
  listState: LazyListState = rememberLazyListState(),
) {
  val pullToRefreshState = rememberPullToRefreshState()
  val haptic = LocalHapticFeedback.current
  val subtleHaptics = rememberSubtleHaptics()
  val coroutineScope = rememberCoroutineScope()
  val showScrollToTop by remember {
    derivedStateOf {
      listState.firstVisibleItemIndex > 1 ||
        (listState.firstVisibleItemIndex == 1 && listState.firstVisibleItemScrollOffset > 200)
    }
  }
  val gridRows = remember(filteredCharacters) { filteredCharacters.chunked(3) }

  PullToRefreshBox(
    isRefreshing = isRefreshing,
    onRefresh = {
      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
      onRefresh()
    },
    state = pullToRefreshState,
    modifier = Modifier
      .fillMaxSize()
      .testTag("characters_pull_to_refresh"),
    indicator = {
      PullToRefreshDefaults.Indicator(
        state = pullToRefreshState,
        isRefreshing = isRefreshing,
        modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
        containerColor = Color(0xFF192038),
        color = PurplePrimary,
      )
    }
  ) {
    LazyColumn(
      state = listState,
      modifier = Modifier
        .fillMaxSize()
        .testTag("characters_lazy_list"),
      contentPadding = PaddingValues(top = 4.dp, bottom = 120.dp)
    ) {
    // 1. Promotional Feature Banner
    item(key = "feature_banner") {
      Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        FeatureBanner(onBannerClick = onBannerClick)
      }
    }

    // 2. Search & Filter Bar + Elemental Chips
    item(key = "search_and_filter") {
      Spacer(modifier = Modifier.height(10.dp))
      SearchAndFilterBar(
        searchQuery = searchQuery,
        onSearchQueryChange = onSearchQueryChange,
        selectedElement = selectedElement,
        onElementSelect = onElementSelect,
        showFavoritesOnly = showFavoritesOnly,
        onFavoritesClick = onFavoritesClick,
        onFilterClick = {
          // Cycle through elements or open filter
        }
      )
    }

    // 3. Characters Section Header with Counter and Grid/List toggle
    item(key = "characters_header") {
      Spacer(modifier = Modifier.height(16.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Heading & Counter
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = if (selectedElement != null) "${selectedElement.displayName} Characters" else "All Characters",
            color = TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.2).sp
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "${filteredCharacters.size} Characters",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Normal
          )
        }

        // Grid / List Toggle
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0F1530))
            .border(1.dp, Color(0xFF1E2850), RoundedCornerShape(8.dp))
            .padding(2.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Grid button
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(if (isGridView) PurplePrimary else Color.Transparent)
              .clickable {
                subtleHaptics.performToggle()
                onViewToggle(true)
              }
              .testTag("btn_toggle_grid"),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Rounded.GridView,
              contentDescription = "Grid View",
              tint = if (isGridView) Color.White else TextMuted,
              modifier = Modifier.size(16.dp)
            )
          }

          // List button
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(if (!isGridView) PurplePrimary else Color.Transparent)
              .clickable {
                subtleHaptics.performToggle()
                onViewToggle(false)
              }
              .testTag("btn_toggle_list"),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Rounded.ViewList,
              contentDescription = "List View",
              tint = if (!isGridView) Color.White else TextMuted,
              modifier = Modifier.size(16.dp)
            )
          }
        }
      }
      Spacer(modifier = Modifier.height(10.dp))
    }

    // 4. Character Cards (Loading State or 3-Column Grid or Detailed List)
    if (isLoading) {
      item(key = "characters_loading_indicator") {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 56.dp)
            .testTag("characters_loading_indicator"),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            CircularProgressIndicator(
              modifier = Modifier
                .size(42.dp)
                .testTag("loading_circular_progress"),
              color = PurplePrimary,
              strokeWidth = 3.5.dp,
              trackColor = Color(0xFF1B2342)
            )
            Text(
              text = "Loading character data...",
              color = TextSecondary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }
    } else if (isGridView) {
      // 3-column rows inside the parent LazyColumn
      itemsIndexed(
        items = gridRows,
        key = { _, row -> row.joinToString("-") { it.id } }
      ) { _, rowChars ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .animateItem(
              fadeInSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing),
              fadeOutSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
              placementSpec = spring(dampingRatio = 0.82f, stiffness = 380f)
            ),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          rowChars.forEach { char ->
            Box(modifier = Modifier.weight(1f)) {
              CharacterGridCard(
                character = char,
                onCharacterClick = onCharacterClick,
                onFavoriteToggle = onFavoriteToggle
              )
            }
          }
          // Empty spacers if last row has fewer than 3 items
          for (i in 0 until (3 - rowChars.size)) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }
    } else {
      itemsIndexed(
        items = filteredCharacters,
        key = { _, char -> char.id }
      ) { _, char ->
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .animateItem(
              fadeInSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing),
              fadeOutSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
              placementSpec = spring(dampingRatio = 0.82f, stiffness = 380f)
            )
        ) {
          CharacterListCard(
            character = char,
            onCharacterClick = onCharacterClick,
            onFavoriteToggle = onFavoriteToggle
          )
        }
      }
    }

    if (!isLoading && filteredCharacters.isEmpty()) {
      item(key = "empty_state") {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp)
            .animateItem(
              fadeInSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
              fadeOutSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
              placementSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
            ),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "No characters found",
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Try adjusting your search query or elemental filter.",
              color = TextSecondary,
              fontSize = 12.sp
            )
          }
        }
      }
    }
  }

    // Subtle floating scroll-to-top button
    AnimatedVisibility(
      visible = showScrollToTop,
      enter = fadeIn(animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing)) +
              scaleIn(initialScale = 0.82f, animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing)),
      exit = fadeOut(animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing)) +
             scaleOut(targetScale = 0.82f, animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing)),
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(end = 20.dp, bottom = 96.dp)
    ) {
      Box(
        modifier = Modifier.size(48.dp),
        contentAlignment = Alignment.Center
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .shadow(
              elevation = 8.dp,
              shape = CircleShape,
              spotColor = Color(0x66A855F7),
              ambientColor = Color(0x33000000)
            )
            .clip(CircleShape)
            .background(Color(0xE612182F))
            .border(
              width = 1.dp,
              color = Color(0xFFC084FC).copy(alpha = 0.45f),
              shape = CircleShape
            )
            .clickable {
              haptic.performHapticFeedback(HapticFeedbackType.LongPress)
              coroutineScope.launch {
                listState.animateScrollToItem(0)
              }
            }
            .testTag("scroll_to_top_button"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Rounded.ArrowUpward,
            contentDescription = "Scroll to top",
            tint = Color(0xFFEDE9FE),
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}

@Composable
private fun CompanionPlaceholderView(
  title: String,
  subtitle: String,
  badge: String,
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp)
      .padding(top = 16.dp, bottom = 100.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1E1538),
        border = BorderStroke(1.dp, PurplePrimary.copy(alpha = 0.5f))
      ) {
        Text(
          text = badge,
          color = Color(0xFFD8B4FE),
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = title,
        color = TextPrimary,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = subtitle,
        color = TextSecondary,
        fontSize = 13.sp,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
      )
    }
  }
}

class SnackbarHostStateStateWrapper {
  val state = SnackbarHostState()
  fun show(scope: kotlinx.coroutines.CoroutineScope, message: String) {
    scope.launch {
      state.currentSnackbarData?.dismiss()
      state.showSnackbar(message)
    }
  }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WeaponsContent(
  onWeaponClick: (Weapon) -> Unit,
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedType by remember { mutableStateOf<WeaponType?>(null) }
  var isRefreshing by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()
  val listState = rememberLazyListState()
  val haptic = LocalHapticFeedback.current
  val subtleHaptics = rememberSubtleHaptics()
  val pullToRefreshState = rememberPullToRefreshState()

  val allWeapons = remember { SampleWeapons.list }
  val filteredWeapons by remember(searchQuery, selectedType) {
    derivedStateOf {
      allWeapons.filter { weapon ->
        val matchesType = selectedType == null || weapon.type == selectedType
        val matchesSearch = searchQuery.isBlank() ||
          weapon.name.contains(searchQuery, ignoreCase = true) ||
          weapon.type.displayName.contains(searchQuery, ignoreCase = true) ||
          weapon.subStatName.contains(searchQuery, ignoreCase = true)
        matchesType && matchesSearch
      }
    }
  }

  PullToRefreshBox(
    isRefreshing = isRefreshing,
    onRefresh = {
      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
      isRefreshing = true
      scope.launch {
        delay(500)
        isRefreshing = false
      }
    },
    state = pullToRefreshState,
    modifier = Modifier
      .fillMaxSize()
      .testTag("weapons_pull_to_refresh"),
    indicator = {
      PullToRefreshDefaults.Indicator(
        state = pullToRefreshState,
        isRefreshing = isRefreshing,
        modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
        containerColor = Color(0xFF192038),
        color = PurplePrimary,
      )
    }
  ) {
    LazyColumn(
      state = listState,
      modifier = Modifier
        .fillMaxSize()
        .testTag("weapons_lazy_list"),
      contentPadding = PaddingValues(top = 4.dp, bottom = 120.dp)
    ) {
      // 1. Search Bar
      item(key = "weapons_search") {
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
          SearchAndFilterBar(
            searchQuery = searchQuery,
            onSearchQueryChange = { searchQuery = it },
            selectedElement = null,
            onElementSelect = {},
            onFilterClick = {}
          )
        }
      }

      // 2. Weapon Type Filter Chips
      item(key = "weapons_filter_chips") {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          val isAllSelected = selectedType == null
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isAllSelected) PurplePrimary else Color(0xFF131A33),
            border = BorderStroke(1.dp, if (isAllSelected) PurpleLight else Color(0xFF233055)),
            modifier = Modifier.clickable {
              subtleHaptics.performToggle()
              selectedType = null
            }
          ) {
            Text(
              text = "All Types",
              color = if (isAllSelected) Color.White else TextSecondary,
              fontSize = 12.sp,
              fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Medium,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
            )
          }

          WeaponType.entries.forEach { type ->
            val isSelected = selectedType == type
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) PurplePrimary else Color(0xFF131A33),
              border = BorderStroke(1.dp, if (isSelected) PurpleLight else Color(0xFF233055)),
              modifier = Modifier.clickable {
                subtleHaptics.performToggle()
                selectedType = if (isSelected) null else type
              }
            ) {
              Text(
                text = type.displayName,
                color = if (isSelected) Color.White else TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
              )
            }
          }
        }
      }

      // 3. Section Header
      item(key = "weapons_header") {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (selectedType != null) "${selectedType?.displayName}s" else "All Weapons",
            color = TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.2).sp
          )
          Text(
            text = "${filteredWeapons.size} Weapons",
            color = TextSecondary,
            fontSize = 12.sp
          )
        }
      }

      // 4. Staggered 2-Column Weapon Grid
      val rows = filteredWeapons.chunked(2)
      itemsIndexed(
        items = rows,
        key = { _, row -> row.joinToString("-") { it.id } }
      ) { _, rowWeapons ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .animateItem(
              fadeInSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing),
              fadeOutSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
              placementSpec = spring(dampingRatio = 0.82f, stiffness = 380f)
            ),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          rowWeapons.forEach { weapon ->
            Box(modifier = Modifier.weight(1f)) {
              WeaponCard(
                weapon = weapon,
                onClick = onWeaponClick
              )
            }
          }
          if (rowWeapons.size < 2) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }

      // Empty State
      if (filteredWeapons.isEmpty()) {
        item(key = "weapons_empty") {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "No weapons found matching \"$searchQuery\"",
              color = TextMuted,
              fontSize = 14.sp
            )
          }
        }
      }
    }
  }
}

