package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Character
import com.example.model.CharacterDetailProvider
import com.example.model.ConstellationNode
import com.example.model.TalentInfo
import com.example.util.rememberSubtleHaptics
import com.example.model.TalentType
import com.example.ui.theme.BackgroundNavy
import com.example.ui.theme.CardBorderNavy
import com.example.ui.theme.CardNavy
import com.example.ui.theme.ChipBackground
import com.example.ui.theme.ChipBorder
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.StarGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class DetailTab(val label: String, val icon: ImageVector) {
  STATS("Base Stats", Icons.Default.FitnessCenter),
  TALENTS("Talents", Icons.Default.Bolt),
  CONSTELLATION("Constellation", Icons.Default.AutoAwesome),
  OVERVIEW("Overview", Icons.AutoMirrored.Filled.MenuBook),
}

@Composable
fun CharacterDetailScreen(
  character: Character,
  onDismiss: () -> Unit,
  onFavoriteToggle: (Character) -> Unit,
  modifier: Modifier = Modifier,
  onAddToTeam: (Character) -> Unit = {},
) {
  BackHandler(onBack = onDismiss)

  val subtleHaptics = rememberSubtleHaptics()
  val profile = remember(character.id) { CharacterDetailProvider.getProfile(character) }
  var selectedTab by remember { mutableStateOf(DetailTab.STATS) }
  var selectedLevel by remember { mutableIntStateOf(90) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(BackgroundNavy)
      .testTag("screen_character_detail")
  ) {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(
        bottom = 84.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
      )
    ) {
      // 1. Hero Header & Portrait
      item(key = "hero_header") {
        DetailHeroHeader(
          character = character,
          profile = profile,
          onDismiss = onDismiss,
          onFavoriteToggle = onFavoriteToggle
        )
      }

      // 2. Tab Navigation
      item(key = "tab_row") {
        DetailTabBar(
          selectedTab = selectedTab,
          onTabSelect = { tab ->
            subtleHaptics.performToggle()
            selectedTab = tab
          },
          elementColor = character.element.color
        )
      }

      // 3. Tab Content
      item(key = "tab_content") {
        AnimatedContent(
          targetState = selectedTab,
          transitionSpec = { fadeIn() togetherWith fadeOut() },
          label = "tab_content_anim"
        ) { tab ->
          when (tab) {
            DetailTab.STATS -> StatsTabContent(
              character = character,
              selectedLevel = selectedLevel,
              onLevelSelect = { lvl ->
                subtleHaptics.performToggle()
                selectedLevel = lvl
              }
            )
            DetailTab.TALENTS -> TalentsTabContent(
              talents = profile.talents,
              elementColor = character.element.color
            )
            DetailTab.CONSTELLATION -> ConstellationTabContent(
              character = character,
              constellations = profile.constellations,
              elementColor = character.element.color
            )
            DetailTab.OVERVIEW -> OverviewTabContent(
              character = character,
              profile = profile
            )
          }
        }
      }
    }

    // Anchored Character Details Action Bar at the bottom of the detail screen
    CharacterDetailActionBar(
      character = character,
      onAddToTeam = onAddToTeam,
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
    )
  }
}

@Composable
fun CharacterDetailActionBar(
  character: Character,
  onAddToTeam: (Character) -> Unit,
  modifier: Modifier = Modifier,
) {
  val subtleHaptics = rememberSubtleHaptics()

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("character_detail_action_bar"),
    color = Color(0xF2090E20),
    border = BorderStroke(1.dp, CardBorderNavy),
    shadowElevation = 8.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(
        modifier = Modifier.weight(1f, fill = false),
        verticalArrangement = Arrangement.Center
      ) {
        Text(
          text = character.name,
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = "${character.role} • ${character.constellation}",
          color = PurpleLight,
          fontSize = 11.5.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Button(
        onClick = {
          subtleHaptics.performPartyAdd()
          onAddToTeam(character)
        },
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = PurplePrimary,
          contentColor = Color.White
        ),
        modifier = Modifier
          .height(44.dp)
          .testTag("detail_btn_add_team")
      ) {
        Icon(
          imageVector = Icons.Default.Groups,
          contentDescription = null,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Add to Party",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
    }
  }
}

@Composable
private fun DetailHeroHeader(
  character: Character,
  profile: com.example.model.CharacterExtendedProfile,
  onDismiss: () -> Unit,
  onFavoriteToggle: (Character) -> Unit,
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(280.dp)
  ) {
    // Character Portrait Canvas
    CharacterPortraitArt(
      character = character,
      modifier = Modifier.fillMaxSize()
    )

    // Dark Bottom Gradient for Text Legibility
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(
              Color.Transparent,
              Color(0x88070B19),
              BackgroundNavy
            ),
            startY = 100f
          )
        )
    )

    // Top Navigation Icons
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .windowInsetsPadding(WindowInsets.statusBars)
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = onDismiss,
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(Color(0x990A0F24))
          .border(1.dp, CardBorderNavy, CircleShape)
          .testTag("detail_back_btn")
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = Color.White,
          modifier = Modifier.size(20.dp)
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        val subtleHaptics = rememberSubtleHaptics()
        IconButton(
          onClick = {
            subtleHaptics.performToggle()
            onFavoriteToggle(character)
          },
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0x990A0F24))
            .border(1.dp, CardBorderNavy, CircleShape)
            .testTag("detail_fav_btn")
        ) {
          Icon(
            imageVector = if (character.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            contentDescription = "Favorite",
            tint = if (character.isFavorite) Color(0xFFF43F5E) else Color.White,
            modifier = Modifier.size(20.dp)
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        IconButton(
          onClick = onDismiss,
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0x990A0F24))
            .border(1.dp, CardBorderNavy, CircleShape)
            .testTag("detail_close_btn")
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }

    // Bottom Content on Hero
    Column(
      modifier = Modifier
        .align(Alignment.BottomStart)
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      // Stars
      Row(verticalAlignment = Alignment.CenterVertically) {
        repeat(character.rarity) {
          Icon(
            imageVector = Icons.Filled.Star,
            contentDescription = null,
            tint = StarGold,
            modifier = Modifier.size(16.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(2.dp))

      Text(
        text = character.name,
        color = TextPrimary,
        fontSize = 26.sp,
        fontWeight = FontWeight.Bold
      )

      Text(
        text = character.title,
        color = PurpleLight,
        fontSize = 13.sp
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Badges
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        ElementBadge(element = character.element, size = 26.dp)
        BadgePill(text = character.element.displayName, color = character.element.color)
        BadgePill(text = character.weapon.displayName, color = Color(0xFFA5B4FC))
        BadgePill(text = character.role, color = StarGold)
      }
    }
  }
}

@Composable
private fun DetailTabBar(
  selectedTab: DetailTab,
  onTabSelect: (DetailTab) -> Unit,
  elementColor: Color,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
      .clip(RoundedCornerShape(14.dp))
      .background(Color(0xFF0F152E))
      .border(1.dp, CardBorderNavy, RoundedCornerShape(14.dp))
      .padding(4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    DetailTab.entries.forEach { tab ->
      val isSelected = selectedTab == tab
      val tabBackground = if (isSelected) {
        elementColor.copy(alpha = 0.22f)
      } else {
        Color.Transparent
      }
      val contentColor = if (isSelected) {
        elementColor
      } else {
        TextSecondary
      }

      Box(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(10.dp))
          .background(tabBackground)
          .then(
            if (isSelected) Modifier.border(1.dp, elementColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            else Modifier
          )
          .clickable { onTabSelect(tab) }
          .padding(vertical = 8.dp)
          .testTag("tab_${tab.name.lowercase()}"),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = tab.icon,
            contentDescription = tab.label,
            tint = contentColor,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.height(3.dp))
          Text(
            text = tab.label,
            color = contentColor,
            fontSize = 10.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
          )
        }
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 1: BASE STATS
// -------------------------------------------------------------
@Composable
private fun StatsTabContent(
  character: Character,
  selectedLevel: Int,
  onLevelSelect: (Int) -> Unit,
) {
  val stats = remember(character.id, selectedLevel) {
    CharacterDetailProvider.calculateStats(character, selectedLevel)
  }
  val profile = remember(character.id) {
    CharacterDetailProvider.getProfile(character)
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Level Selector Row
    Text(
      text = "SELECT LEVEL / ASCENSION",
      color = TextMuted,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.8.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    val levels = listOf(1, 20, 40, 60, 70, 80, 90)
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(levels) { lvl ->
        val isSelected = selectedLevel == lvl
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) PurplePrimary else ChipBackground)
            .border(
              1.dp,
              if (isSelected) PurpleLight else ChipBorder,
              RoundedCornerShape(10.dp)
            )
            .clickable { onLevelSelect(lvl) }
            .padding(horizontal = 14.dp, vertical = 7.dp)
            .testTag("level_chip_$lvl"),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "Lv. $lvl",
            color = if (isSelected) Color.White else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Primary Stat Cards
    Text(
      text = "CORE ATTRIBUTES",
      color = TextMuted,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.8.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      StatGaugeCard(
        title = "Base HP",
        value = stats["Base HP"] ?: "${character.baseHp}",
        maxReference = 16500f,
        current = (stats["Base HP"]?.toFloatOrNull() ?: 1000f),
        color = Color(0xFF10B981),
        modifier = Modifier.weight(1f)
      )
      StatGaugeCard(
        title = "Base ATK",
        value = stats["Base ATK"] ?: "${character.baseAtk}",
        maxReference = 400f,
        current = (stats["Base ATK"]?.toFloatOrNull() ?: 50f),
        color = Color(0xFFEF4444),
        modifier = Modifier.weight(1f)
      )
      StatGaugeCard(
        title = "Base DEF",
        value = stats["Base DEF"] ?: "${profile.baseDef}",
        maxReference = 950f,
        current = (stats["Base DEF"]?.toFloatOrNull() ?: 100f),
        color = Color(0xFFF59E0B),
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Ascension Bonus Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CardNavy),
      border = BorderStroke(1.dp, character.element.color.copy(alpha = 0.35f))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(character.element.color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.MilitaryTech,
              contentDescription = null,
              tint = character.element.color,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "Ascension Stat (${profile.ascensionStatName})",
              color = TextPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold
            )
            Text(
              text = if (selectedLevel >= 60) "Unlocked (Ascension 4+)" else "Unlocks at Level 60",
              color = if (selectedLevel >= 60) character.element.color else TextMuted,
              fontSize = 11.sp
            )
          }
        }

        Text(
          text = stats["Ascension Stat"] ?: profile.ascensionStatValue,
          color = character.element.color,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Secondary Attributes Table
    Text(
      text = "SECONDARY COMBAT ATTRIBUTES",
      color = TextMuted,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.8.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CardNavy),
      border = BorderStroke(1.dp, CardBorderNavy)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        SecondaryStatRow("CRIT Rate", stats["CRIT Rate"] ?: "5.0%")
        HorizontalDivider(color = Color(0xFF161F40), modifier = Modifier.padding(vertical = 8.dp))
        SecondaryStatRow("CRIT DMG", stats["CRIT DMG"] ?: "50.0%")
        HorizontalDivider(color = Color(0xFF161F40), modifier = Modifier.padding(vertical = 8.dp))
        SecondaryStatRow("Energy Recharge", stats["Energy Recharge"] ?: "100.0%")
        HorizontalDivider(color = Color(0xFF161F40), modifier = Modifier.padding(vertical = 8.dp))
        SecondaryStatRow("Elemental Mastery", stats["Elemental Mastery"] ?: "0")
        HorizontalDivider(color = Color(0xFF161F40), modifier = Modifier.padding(vertical = 8.dp))
        SecondaryStatRow("${character.element.displayName} DMG Bonus", if (profile.ascensionStatName.contains("DMG") && selectedLevel >= 60) profile.ascensionStatValue else "0.0%")
      }
    }
  }
}

@Composable
private fun StatGaugeCard(
  title: String,
  value: String,
  maxReference: Float,
  current: Float,
  color: Color,
  modifier: Modifier = Modifier,
) {
  val ratio = (current / maxReference).coerceIn(0f, 1f)

  Card(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = CardNavy),
    border = BorderStroke(1.dp, CardBorderNavy)
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Text(
        text = title,
        color = TextMuted,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        color = TextPrimary,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(8.dp))
      LinearProgressIndicator(
        progress = { ratio },
        modifier = Modifier
          .fillMaxWidth()
          .height(4.dp)
          .clip(RoundedCornerShape(2.dp)),
        color = color,
        trackColor = Color(0xFF161E3B),
        strokeCap = StrokeCap.Round
      )
    }
  }
}

@Composable
private fun SecondaryStatRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      color = TextSecondary,
      fontSize = 12.sp
    )
    Text(
      text = value,
      color = TextPrimary,
      fontSize = 12.5.sp,
      fontWeight = FontWeight.SemiBold
    )
  }
}

// -------------------------------------------------------------
// TAB 2: TALENTS
// -------------------------------------------------------------
@Composable
private fun TalentsTabContent(
  talents: List<TalentInfo>,
  elementColor: Color,
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    val combatTalents = talents.filter {
      it.type in listOf(TalentType.NORMAL_ATTACK, TalentType.ELEMENTAL_SKILL, TalentType.ELEMENTAL_BURST)
    }
    val passiveTalents = talents.filter {
      it.type in listOf(TalentType.PASSIVE_1, TalentType.PASSIVE_2, TalentType.PASSIVE_UTILITY)
    }

    Text(
      text = "COMBAT TALENTS",
      color = TextMuted,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.8.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    combatTalents.forEach { talent ->
      TalentCard(talent = talent, elementColor = elementColor)
      Spacer(modifier = Modifier.height(10.dp))
    }

    Spacer(modifier = Modifier.height(10.dp))

    Text(
      text = "PASSIVE TALENTS",
      color = TextMuted,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.8.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    passiveTalents.forEach { talent ->
      TalentCard(talent = talent, elementColor = elementColor)
      Spacer(modifier = Modifier.height(10.dp))
    }
  }
}

@Composable
private fun TalentCard(
  talent: TalentInfo,
  elementColor: Color,
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("talent_card_${talent.name.lowercase().replace(" ", "_")}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = CardNavy),
    border = BorderStroke(1.dp, CardBorderNavy)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        BadgePill(
          text = talent.type.label,
          color = when (talent.type) {
            TalentType.NORMAL_ATTACK -> Color(0xFFA5B4FC)
            TalentType.ELEMENTAL_SKILL -> elementColor
            TalentType.ELEMENTAL_BURST -> PurpleLight
            else -> StarGold
          }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          talent.cooldown?.let { cd ->
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(0xFF131B38)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Timer,
                  contentDescription = null,
                  tint = TextMuted,
                  modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(text = cd, color = TextSecondary, fontSize = 10.sp)
              }
            }
          }

          talent.energyCost?.let { cost ->
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(0xFF131B38)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Bolt,
                  contentDescription = null,
                  tint = elementColor,
                  modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(text = "$cost Energy", color = elementColor, fontSize = 10.sp)
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = talent.name,
        color = TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = talent.description,
        color = TextSecondary,
        fontSize = 12.5.sp,
        lineHeight = 18.sp
      )
    }
  }
}

// -------------------------------------------------------------
// TAB 3: CONSTELLATIONS
// -------------------------------------------------------------
@Composable
private fun ConstellationTabContent(
  character: Character,
  constellations: List<ConstellationNode>,
  elementColor: Color,
) {
  val subtleHaptics = rememberSubtleHaptics()
  var activeNodes by remember { mutableIntStateOf(6) }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Header Banner
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1634)),
      border = BorderStroke(1.2.dp, elementColor.copy(alpha = 0.5f))
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(elementColor.copy(alpha = 0.2f))
            .border(1.dp, elementColor, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = elementColor,
            modifier = Modifier.size(24.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(
            text = character.constellation,
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Celestial Pattern of ${character.name}",
            color = PurpleLight,
            fontSize = 12.sp
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Text(
      text = "CONSTELLATION NODES (C1 - C6)",
      color = TextMuted,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.8.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    constellations.forEach { node ->
      val isUnlocked = node.level <= activeNodes
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
          .clickable {
            subtleHaptics.performToggle()
            activeNodes = if (activeNodes == node.level) node.level - 1 else node.level
          }
          .testTag("constellation_node_${node.level}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (isUnlocked) CardNavy else Color(0xFF0A0E22)
        ),
        border = BorderStroke(
          1.dp,
          if (isUnlocked) elementColor.copy(alpha = 0.6f) else CardBorderNavy
        )
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          verticalAlignment = Alignment.Top
        ) {
          // Roman numeral badge
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(if (isUnlocked) elementColor.copy(alpha = 0.2f) else Color(0xFF12172F))
              .border(
                1.dp,
                if (isUnlocked) elementColor else Color(0xFF1E2648),
                CircleShape
              ),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "C${node.level}",
              color = if (isUnlocked) elementColor else TextMuted,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = node.name,
                color = if (isUnlocked) TextPrimary else TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
              )

              if (isUnlocked) {
                Icon(
                  imageVector = Icons.Filled.Star,
                  contentDescription = "Unlocked",
                  tint = StarGold,
                  modifier = Modifier.size(14.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = node.description,
              color = if (isUnlocked) TextSecondary else TextMuted,
              fontSize = 12.sp,
              lineHeight = 17.sp
            )
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// TAB 4: OVERVIEW & LORE
// -------------------------------------------------------------
@Composable
private fun OverviewTabContent(
  character: Character,
  profile: com.example.model.CharacterExtendedProfile,
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Combat Role Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CardNavy),
      border = BorderStroke(1.dp, CardBorderNavy)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Text(
          text = "COMBAT SYNERGY & SUMMARY",
          color = TextMuted,
          fontSize = 10.5.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = profile.combatRoleSummary,
          color = TextPrimary,
          fontSize = 13.sp,
          lineHeight = 18.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Profile Metadata
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CardNavy),
      border = BorderStroke(1.dp, CardBorderNavy)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Text(
          text = "CHARACTER DOSSIER",
          color = TextMuted,
          fontSize = 10.5.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        SecondaryStatRow("Affiliation", profile.affiliation)
        HorizontalDivider(color = Color(0xFF161F40), modifier = Modifier.padding(vertical = 8.dp))
        SecondaryStatRow("Birthday", profile.birthday)
        HorizontalDivider(color = Color(0xFF161F40), modifier = Modifier.padding(vertical = 8.dp))
        SecondaryStatRow("Signature Dish", profile.specialDish)
        HorizontalDivider(color = Color(0xFF161F40), modifier = Modifier.padding(vertical = 8.dp))
        SecondaryStatRow("Constellation", character.constellation)
        HorizontalDivider(color = Color(0xFF161F40), modifier = Modifier.padding(vertical = 8.dp))
        SecondaryStatRow("Weapon Specialty", character.weapon.displayName)
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Lore Description
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CardNavy),
      border = BorderStroke(1.dp, CardBorderNavy)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Text(
          text = "BACKGROUND & LORE",
          color = TextMuted,
          fontSize = 10.5.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = character.description,
          color = TextSecondary,
          fontSize = 13.sp,
          lineHeight = 19.sp
        )
      }
    }
  }
}

@Composable
private fun BadgePill(text: String, color: Color) {
  Surface(
    shape = RoundedCornerShape(6.dp),
    color = color.copy(alpha = 0.15f),
    border = BorderStroke(1.dp, color.copy(alpha = 0.4f))
  ) {
    Text(
      text = text,
      color = color,
      fontSize = 11.sp,
      fontWeight = FontWeight.Medium,
      modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
    )
  }
}
