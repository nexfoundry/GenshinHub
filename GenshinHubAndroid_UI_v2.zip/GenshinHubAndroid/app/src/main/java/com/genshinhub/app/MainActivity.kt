package com.genshinhub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF040713)
private val Surface = Color(0xFF080F20)
private val Surface2 = Color(0xFF0D1528)
private val Purple = Color(0xFF9B63FF)
private val PurpleBright = Color(0xFFB982FF)
private val TextPrimary = Color(0xFFF5F2FF)
private val Muted = Color(0xFF9699AF)
private val Gold = Color(0xFFFFD21C)

private data class Character(
    val name: String,
    val element: String,
    val weapon: String,
    val stars: Int,
    val image: Int
)

private val characters = listOf(
    Character("Alyosha", "Electro", "Sword", 5, R.drawable.char_alyosha),
    Character("Varka", "Geo", "Claymore", 5, R.drawable.char_varka),
    Character("Columbina", "Hydro", "Polearm", 5, R.drawable.char_columbina),
    Character("Dainsleif", "Electro", "Sword", 5, R.drawable.char_dainsleif),
    Character("Nelu", "Dendro", "Catalyst", 5, R.drawable.char_nelu),
    Character("Iansan", "Pyro", "Polearm", 4, R.drawable.char_iansan),
    Character("Mavuika", "Pyro", "Claymore", 5, R.drawable.char_alyosha),
    Character("Furina", "Hydro", "Sword", 5, R.drawable.char_columbina),
    Character("Xilonen", "Geo", "Sword", 5, R.drawable.char_varka)
)

private val elements = listOf("All", "Pyro", "Hydro", "Anemo", "Electro", "Geo", "Dendro", "Cryo")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GenshinHubApp() }
    }
}

@Composable
fun GenshinHubApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Surface,
            primary = Purple,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        )
    ) {
        var selectedElement by remember { mutableStateOf("All") }
        var query by remember { mutableStateOf("") }
        var favorites by remember { mutableStateOf(setOf<String>()) }
        var tab by remember { mutableStateOf(0) }

        val filtered = characters.filter {
            (selectedElement == "All" || it.element == selectedElement) &&
                it.name.contains(query, ignoreCase = true)
        }

        Scaffold(
            containerColor = Bg,
            bottomBar = { BottomBar(tab) { tab = it } }
        ) { padding ->
            if (tab == 0) {
                HomeScreen(
                    modifier = Modifier.padding(padding),
                    query = query,
                    onQuery = { query = it },
                    selectedElement = selectedElement,
                    onElement = { selectedElement = it },
                    characters = filtered,
                    favorites = favorites,
                    onFavorite = { name ->
                        favorites = if (name in favorites) favorites - name else favorites + name
                    }
                )
            } else {
                PlaceholderScreen(
                    modifier = Modifier.padding(padding),
                    title = listOf("Characters", "Weapons", "Artifacts", "Teams", "Tier List")[tab]
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    query: String,
    onQuery: (String) -> Unit,
    selectedElement: String,
    onElement: (String) -> Unit,
    characters: List<Character>,
    favorites: Set<String>,
    onFavorite: (String) -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF070B18), Bg, Bg)
                )
            )
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(6.dp))
        Header()
        TopLinks()
        Spacer(Modifier.height(12.dp))
        HeroBanner()
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchBox(query, onQuery, Modifier.weight(1f))
            FilterButton()
        }

        Spacer(Modifier.height(12.dp))
        ElementRow(selectedElement, onElement)
        Spacer(Modifier.height(14.dp))

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "✦  All Characters",
                    fontSize = 19.sp,
                    fontStyle = FontStyle.Italic,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Text("${characters.size} Characters", color = Muted, fontSize = 11.sp)
            }
            ViewModeButton(Icons.Default.GridView, true)
            Spacer(Modifier.width(4.dp))
            ViewModeButton(Icons.Default.ViewList, false)
        }

        Spacer(Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(characters) { character ->
                CharacterCard(
                    character,
                    character.name in favorites,
                    { onFavorite(character.name) }
                )
            }
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier.fillMaxWidth().height(52.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CompactIconButton(Icons.Default.Menu)
        Spacer(Modifier.width(10.dp))
        Icon(Icons.Default.AutoAwesome, null, tint = PurpleBright, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(6.dp))
        Column {
            Text(
                "Genshin",
                fontSize = 25.sp,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Medium,
                lineHeight = 25.sp
            )
            Text("H U B", fontSize = 10.sp, color = PurpleBright, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        }
        Spacer(Modifier.weight(1f))
        CompactIconButton(Icons.Default.NotificationsNone)
        Spacer(Modifier.width(6.dp))
        CompactIconButton(Icons.Default.StarBorder)
    }
}

@Composable
private fun TopLinks() {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 48.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        listOf("CHARACTERS", "BUILDS", "GUIDES", "MORE").forEachIndexed { index, text ->
            Text(
                text,
                fontSize = 8.sp,
                letterSpacing = 0.7.sp,
                color = if (index == 0) TextPrimary else Muted
            )
        }
    }
}

@Composable
private fun CompactIconButton(icon: ImageVector) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Surface2)
            .border(1.dp, Color(0xFF1D2944), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = TextPrimary, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun HeroBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(196.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, Purple.copy(alpha = .65f), RoundedCornerShape(20.dp))
            .background(Surface)
    ) {
        Image(
            painter = painterResource(R.drawable.hero_character),
            contentDescription = null,
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.72f)
                .align(Alignment.CenterEnd),
            contentScale = ContentScale.Crop,
            alignment = Alignment.Center
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color(0xFF130F2B),
                            Color(0xCC17112E),
                            Color.Transparent
                        )
                    )
                )
        )
        Column(
            modifier = Modifier.fillMaxHeight().padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(color = Purple.copy(alpha = .35f), shape = RoundedCornerShape(8.dp)) {
                Text("Version 5.6", modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), fontSize = 10.sp)
            }
            Column(modifier = Modifier.width(205.dp)) {
                Text("New Adventures,\nNew Legends", fontSize = 25.sp, lineHeight = 27.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text("Discover new characters and build\nyour ultimate team", color = Color(0xFFD7D4E4), fontSize = 11.sp, lineHeight = 15.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {},
                    modifier = Modifier.height(38.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 15.dp)
                ) {
                    Text("Explore Now  →", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun SearchBox(value: String, onValueChange: (String) -> Unit, modifier: Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.height(48.dp),
        singleLine = true,
        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
        placeholder = { Text("Search characters, weapons, or elements...", color = Muted, fontSize = 12.sp, maxLines = 1) },
        leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted, modifier = Modifier.size(20.dp)) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Purple,
            unfocusedBorderColor = Color(0xFF1D2944),
            focusedContainerColor = Surface,
            unfocusedContainerColor = Surface,
            cursorColor = PurpleBright
        ),
        shape = RoundedCornerShape(24.dp)
    )
}

@Composable
private fun FilterButton() {
    Surface(
        modifier = Modifier.height(48.dp).width(92.dp),
        color = Surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1D2944)),
        shape = RoundedCornerShape(24.dp),
        onClick = {}
    ) {
        Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FilterAlt, null, modifier = Modifier.size(18.dp), tint = TextPrimary)
            Spacer(Modifier.width(6.dp))
            Text("Filter", fontSize = 12.sp)
        }
    }
}

@Composable
private fun ElementRow(selected: String, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        elements.forEach { element ->
            val selectedElement = element == selected
            Surface(
                onClick = { onSelect(element) },
                modifier = Modifier.size(54.dp),
                color = if (selectedElement) Purple.copy(alpha = .18f) else Surface,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (selectedElement) Purple else Color(0xFF1B2942)
                ),
                shape = CircleShape
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(elementIcon(element), fontSize = 19.sp, color = elementColor(element))
                }
            }
        }
    }
}

private fun elementIcon(element: String) = when (element) {
    "Pyro" -> "♨"
    "Hydro" -> "≋"
    "Anemo" -> "≋"
    "Electro" -> "ϟ"
    "Geo" -> "◆"
    "Dendro" -> "♧"
    "Cryo" -> "❄"
    else -> "✦"
}

private fun elementColor(element: String) = when (element) {
    "Pyro" -> Color(0xFFFF6B3D)
    "Hydro" -> Color(0xFF27B9FF)
    "Anemo" -> Color(0xFF62E0C3)
    "Electro" -> Color(0xFFB36BFF)
    "Geo" -> Color(0xFFFFC83D)
    "Dendro" -> Color(0xFF92D449)
    "Cryo" -> Color(0xFF7EDBFF)
    else -> TextPrimary
}

@Composable
private fun ViewModeButton(icon: ImageVector, selected: Boolean) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(if (selected) Purple.copy(alpha = .22f) else Surface2)
            .border(1.dp, if (selected) Purple.copy(alpha = .65f) else Color(0xFF18243B), RoundedCornerShape(9.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = if (selected) PurpleBright else Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun CharacterCard(character: Character, favorite: Boolean, onFavorite: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(15.dp))
            .clip(RoundedCornerShape(15.dp))
            .background(Surface)
            .clickable { }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(128.dp)
                .clip(RoundedCornerShape(topStart = 15.dp, topEnd = 15.dp))
        ) {
            Image(
                painter = painterResource(character.image),
                contentDescription = character.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Transparent, Color(0xE6090D19))
                    )
                )
            )
            Box(
                modifier = Modifier
                    .padding(7.dp)
                    .size(27.dp)
                    .clip(CircleShape)
                    .background(Color(0xCC11172A)),
                contentAlignment = Alignment.Center
            ) {
                Text(elementIcon(character.element), fontSize = 13.sp, color = elementColor(character.element))
            }
            IconButton(
                onClick = onFavorite,
                modifier = Modifier.align(Alignment.TopEnd).size(34.dp)
            ) {
                Icon(
                    if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    null,
                    tint = if (favorite) Color(0xFFFF5574) else TextPrimary,
                    modifier = Modifier.size(19.dp)
                )
            }
            Text(
                "★".repeat(character.stars),
                color = Gold,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(start = 8.dp, bottom = 5.dp)
            )
        }
        Text(
            character.name,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 8.dp, top = 5.dp, end = 5.dp)
        )
        Text(
            "⚔  ${character.weapon}",
            color = Muted,
            fontSize = 10.sp,
            maxLines = 1,
            modifier = Modifier.padding(start = 8.dp, bottom = 7.dp, top = 1.dp)
        )
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        "Characters" to Icons.Default.AutoAwesome,
        "Weapons" to Icons.Default.ContentCut,
        "Artifacts" to Icons.Default.Hexagon,
        "Teams" to Icons.Default.Group,
        "Tier List" to Icons.Default.EmojiEvents
    )

    NavigationBar(
        modifier = Modifier.height(72.dp),
        containerColor = Color(0xFF070B18),
        tonalElevation = 0.dp
    ) {
        items.forEachIndexed { index, (label, icon) ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = { Icon(icon, null, modifier = Modifier.size(21.dp)) },
                label = { Text(label, fontSize = 9.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PurpleBright,
                    selectedTextColor = PurpleBright,
                    indicatorColor = Purple.copy(alpha = .15f),
                    unselectedIconColor = Muted,
                    unselectedTextColor = Muted
                )
            )
        }
    }
}

@Composable
private fun PlaceholderScreen(modifier: Modifier, title: String) {
    Box(modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Construction, null, tint = Purple, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("This section is ready for the next data module.", color = Muted, fontSize = 12.sp)
        }
    }
}
