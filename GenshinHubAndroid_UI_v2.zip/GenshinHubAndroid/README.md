# Genshin HUB — Android prototype

A Kotlin + Jetpack Compose mobile prototype inspired by the supplied Genshin HUB reference image.

## Included
- Dark purple mobile UI
- Header, hero banner and search
- Element filters
- Character grid
- Working search
- Working favorites
- Bottom navigation
- Placeholder screens for Weapons, Artifacts, Teams and More

## Open in Android Studio
1. Extract the ZIP.
2. Open the `GenshinHubAndroid` folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android emulator or device.

The character artwork is intentionally represented by stylized placeholders in this prototype. Real character assets and a data source can be added in the next iteration.
