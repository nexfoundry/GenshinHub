package com.example.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView

/**
 * Provides refined, subtle haptic feedback for key user interactions
 * such as tapping character cards, adding/removing items in party lineups,
 * and toggling favorites or view options.
 */
class SubtleHaptics(
  private val view: View,
  private val haptic: HapticFeedback,
  private val context: Context,
) {
  private val vibrator: Vibrator? by lazy {
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
      } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
      }
    } catch (_: Exception) {
      null
    }
  }

  /**
   * Subtle tap feedback for tapping character cards, weapon cards, or list cards.
   */
  fun performCardTap() {
    val handled = view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    if (!handled) {
      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      triggerSubtleVibrationFallback(durationMs = 8, amplitude = 35)
    }
  }

  /**
   * Subtle confirmation feedback when adding a character/item to the active party lineup.
   */
  fun performPartyAdd() {
    val handled = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
    } else {
      view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }
    if (!handled) {
      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      triggerSubtleVibrationFallback(durationMs = 15, amplitude = 60)
    }
  }

  /**
   * Subtle tick feedback when removing an item from the active party lineup.
   */
  fun performPartyRemove() {
    val handled = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      view.performHapticFeedback(HapticFeedbackConstants.REJECT)
    } else {
      view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }
    if (!handled) {
      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      triggerSubtleVibrationFallback(durationMs = 8, amplitude = 35)
    }
  }

  /**
   * Subtle tick feedback for toggling favorites, grid/list modes, filters, or constellations.
   */
  fun performToggle() {
    val handled = view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    if (!handled) {
      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      triggerSubtleVibrationFallback(durationMs = 6, amplitude = 30)
    }
  }

  /**
   * Subtle tick feedback when switching navigation tabs.
   */
  fun performTabSelect() {
    val handled = view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    if (!handled) {
      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      triggerSubtleVibrationFallback(durationMs = 6, amplitude = 30)
    }
  }

  /**
   * Subtle tick feedback when navigating back or closing panels.
   */
  fun performBack() {
    val handled = view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    if (!handled) {
      haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      triggerSubtleVibrationFallback(durationMs = 6, amplitude = 30)
    }
  }

  private fun triggerSubtleVibrationFallback(durationMs: Long, amplitude: Int) {
    try {
      if (vibrator?.hasVibrator() == true) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          vibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, amplitude.coerceIn(1, 255)))
        } else {
          @Suppress("DEPRECATION")
          vibrator?.vibrate(durationMs)
        }
      }
    } catch (_: Exception) {
      // Gracefully ignore if vibrator is not present or restricted
    }
  }
}

@Composable
fun rememberSubtleHaptics(): SubtleHaptics {
  val view = LocalView.current
  val haptic = LocalHapticFeedback.current
  val context = LocalContext.current
  return remember(view, haptic, context) {
    SubtleHaptics(view, haptic, context)
  }
}
