package com.example.data.repository

import com.example.data.local.CharacterDao
import com.example.data.local.CharacterEntity
import com.example.model.Character
import com.example.model.SampleCharacters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class CharacterRepository(
  private val characterDao: CharacterDao
) {
  val charactersFlow: Flow<List<Character>> = characterDao.getAllCharacters().map { list ->
    list.map { it.toDomain() }
  }

  suspend fun initializeIfEmpty() = withContext(Dispatchers.IO) {
    if (characterDao.getCount() == 0) {
      val entities = SampleCharacters.list.map { CharacterEntity.fromDomain(it) }
      characterDao.insertCharacters(entities)
    }
  }

  suspend fun refetchFromDatabase(): List<Character> = withContext(Dispatchers.IO) {
    initializeIfEmpty()
    characterDao.getCharactersList().map { it.toDomain() }
  }

  suspend fun insertCharacter(character: Character) = withContext(Dispatchers.IO) {
    characterDao.insertCharacter(CharacterEntity.fromDomain(character))
  }

  suspend fun insertCharacters(characters: List<Character>) = withContext(Dispatchers.IO) {
    characterDao.insertCharacters(characters.map { CharacterEntity.fromDomain(it) })
  }

  fun getCharacterById(id: String): Flow<Character?> {
    return characterDao.getCharacterById(id).map { it?.toDomain() }
  }

  fun getCharactersByElement(elementName: String): Flow<List<Character>> {
    return characterDao.getCharactersByElement(elementName).map { list ->
      list.map { it.toDomain() }
    }
  }

  fun getCharactersByWeapon(weaponName: String): Flow<List<Character>> {
    return characterDao.getCharactersByWeaponType(weaponName).map { list ->
      list.map { it.toDomain() }
    }
  }

  fun getCharactersByRarity(rarity: Int): Flow<List<Character>> {
    return characterDao.getCharactersByRarity(rarity).map { list ->
      list.map { it.toDomain() }
    }
  }

  suspend fun toggleFavorite(characterId: String, currentFavorite: Boolean) = withContext(Dispatchers.IO) {
    characterDao.updateFavorite(characterId, !currentFavorite)
  }

  suspend fun deleteCharacterById(id: String) = withContext(Dispatchers.IO) {
    characterDao.deleteCharacterById(id)
  }
}
