package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import com.example.model.Character
import com.example.model.ElementType
import com.example.model.WeaponType

/**
 * Room database entity representing a Genshin Impact character.
 * Stores core character attributes including name, element, rarity, and weapon type.
 */
@Entity(tableName = "characters")
data class CharacterEntity(
  @PrimaryKey
  val id: String,
  val name: String,
  @ColumnInfo(name = "element")
  val element: String,
  @ColumnInfo(name = "rarity")
  val rarity: Int,
  @ColumnInfo(name = "weapon_type")
  val weaponType: String,
  val title: String = "",
  val description: String = "",
  val baseAtk: Int = 0,
  val baseHp: Int = 0,
  val constellation: String = "",
  val role: String = "",
  val isFavorite: Boolean = false,
  val portraitSeed: Int = 0,
) {
  @get:Ignore
  val elementName: String get() = element

  @get:Ignore
  val weaponName: String get() = weaponType

  fun toDomain(): Character {
    val parsedElement = try {
      ElementType.valueOf(element.uppercase())
    } catch (_: Exception) {
      ElementType.ELECTRO
    }
    val parsedWeapon = try {
      WeaponType.valueOf(weaponType.uppercase())
    } catch (_: Exception) {
      WeaponType.POLEARM
    }
    return Character(
      id = id,
      name = name,
      title = title,
      element = parsedElement,
      weapon = parsedWeapon,
      rarity = rarity,
      description = description,
      baseAtk = baseAtk,
      baseHp = baseHp,
      constellation = constellation,
      role = role,
      isFavorite = isFavorite,
      portraitSeed = portraitSeed,
    )
  }

  companion object {
    fun fromDomain(character: Character): CharacterEntity {
      return CharacterEntity(
        id = character.id,
        name = character.name,
        element = character.element.name,
        rarity = character.rarity,
        weaponType = character.weapon.name,
        title = character.title,
        description = character.description,
        baseAtk = character.baseAtk,
        baseHp = character.baseHp,
        constellation = character.constellation,
        role = character.role,
        isFavorite = character.isFavorite,
        portraitSeed = character.portraitSeed,
      )
    }
  }
}

