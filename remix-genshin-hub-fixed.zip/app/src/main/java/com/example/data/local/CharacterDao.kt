package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object (DAO) for Genshin Impact characters.
 * Provides methods to store, retrieve, update, and delete character data.
 */
@Dao
interface CharacterDao {

  // --- Storing Characters ---

  /**
   * Insert a single character into the database. Replaces on conflict.
   */
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCharacter(character: CharacterEntity)

  /**
   * Insert a list of characters into the database. Replaces on conflict.
   */
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCharacters(characters: List<CharacterEntity>)

  /**
   * Update an existing character in the database.
   */
  @Update
  suspend fun updateCharacter(character: CharacterEntity)

  /**
   * Toggle or set the favorite status of a character by ID.
   */
  @Query("UPDATE characters SET isFavorite = :isFavorite WHERE id = :id")
  suspend fun updateFavorite(id: String, isFavorite: Boolean)

  // --- Retrieving Characters ---

  /**
   * Observe all characters ordered by name ascending.
   */
  @Query("SELECT * FROM characters ORDER BY name ASC")
  fun getAllCharacters(): Flow<List<CharacterEntity>>

  /**
   * Synchronously or one-shot retrieve all characters ordered by name ascending.
   */
  @Query("SELECT * FROM characters ORDER BY name ASC")
  suspend fun getCharactersList(): List<CharacterEntity>

  /**
   * Observe a single character by ID.
   */
  @Query("SELECT * FROM characters WHERE id = :id LIMIT 1")
  fun getCharacterById(id: String): Flow<CharacterEntity?>

  /**
   * Retrieve a single character by ID (one-shot).
   */
  @Query("SELECT * FROM characters WHERE id = :id LIMIT 1")
  suspend fun getCharacterByIdSync(id: String): CharacterEntity?

  /**
   * Retrieve characters filtered by elemental alignment (e.g., PYRO, HYDRO, ELECTRO).
   */
  @Query("SELECT * FROM characters WHERE UPPER(element) = UPPER(:element) ORDER BY name ASC")
  fun getCharactersByElement(element: String): Flow<List<CharacterEntity>>

  /**
   * Retrieve characters filtered by weapon type (e.g., SWORD, CLAYMORE, BOW, CATALYST, POLEARM).
   */
  @Query("SELECT * FROM characters WHERE UPPER(weapon_type) = UPPER(:weaponType) ORDER BY name ASC")
  fun getCharactersByWeaponType(weaponType: String): Flow<List<CharacterEntity>>

  /**
   * Retrieve characters filtered by star rarity (4 or 5 stars).
   */
  @Query("SELECT * FROM characters WHERE rarity = :rarity ORDER BY name ASC")
  fun getCharactersByRarity(rarity: Int): Flow<List<CharacterEntity>>

  /**
   * Observe all bookmarked/favorite characters.
   */
  @Query("SELECT * FROM characters WHERE isFavorite = 1 ORDER BY name ASC")
  fun getFavoriteCharacters(): Flow<List<CharacterEntity>>

  /**
   * Search characters by partial name match.
   */
  @Query("SELECT * FROM characters WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
  fun searchCharactersByName(query: String): Flow<List<CharacterEntity>>

  /**
   * Count total stored characters in the database.
   */
  @Query("SELECT COUNT(*) FROM characters")
  suspend fun getCount(): Int

  // --- Deleting Characters ---

  /**
   * Delete a character entity from the database.
   */
  @Delete
  suspend fun deleteCharacter(character: CharacterEntity)

  /**
   * Delete a character by ID.
   */
  @Query("DELETE FROM characters WHERE id = :id")
  suspend fun deleteCharacterById(id: String)

  /**
   * Clear all characters from the database.
   */
  @Query("DELETE FROM characters")
  suspend fun deleteAllCharacters()
}

