package com.example.model

data class Weapon(
  val id: String,
  val name: String,
  val type: WeaponType,
  val rarity: Int = 5,
  val baseAtk: Int,
  val subStatName: String,
  val subStatValue: String,
  val passiveName: String,
  val passiveDesc: String,
)

object SampleWeapons {
  val list = listOf(
    Weapon(
      id = "mistsplitter",
      name = "Mistsplitter Reforged",
      type = WeaponType.SWORD,
      rarity = 5,
      baseAtk = 674,
      subStatName = "CRIT DMG",
      subStatValue = "44.1%",
      passiveName = "Mistsplitter's Edge",
      passiveDesc = "Gain a 12% Elemental DMG Bonus for all elements and receive the might of the Mistsplitter's Emblem."
    ),
    Weapon(
      id = "homa",
      name = "Staff of Homa",
      type = WeaponType.POLEARM,
      rarity = 5,
      baseAtk = 608,
      subStatName = "CRIT DMG",
      subStatValue = "66.2%",
      passiveName = "Reckless Cinnabar",
      passiveDesc = "HP increased by 20%. Additionally, provides an ATK Bonus based on 0.8% of the wielder's Max HP."
    ),
    Weapon(
      id = "aqua",
      name = "Aqua Simulacra",
      type = WeaponType.BOW,
      rarity = 5,
      baseAtk = 542,
      subStatName = "CRIT DMG",
      subStatValue = "88.2%",
      passiveName = "The Cleansing Form",
      passiveDesc = "HP increased by 16%. When opponents are nearby, DMG dealt by the wielder is increased by 20%."
    ),
    Weapon(
      id = "gravestone",
      name = "Wolf's Gravestone",
      type = WeaponType.CLAYMORE,
      rarity = 5,
      baseAtk = 608,
      subStatName = "ATK",
      subStatValue = "49.6%",
      passiveName = "Wolfish Tracker",
      passiveDesc = "Increases ATK by 20%. On hit against enemies with less than 30% HP, increases all party members' ATK by 40%."
    ),
    Weapon(
      id = "floating_dreams",
      name = "A Thousand Floating Dreams",
      type = WeaponType.CATALYST,
      rarity = 5,
      baseAtk = 542,
      subStatName = "Elemental Mastery",
      subStatValue = "265",
      passiveName = "A Thousand Nights' Dawnsong",
      passiveDesc = "Party members with matching Elemental Type grant 32 EM. Differing types grant 10% Elemental DMG Bonus."
    ),
    Weapon(
      id = "engulfing",
      name = "Engulfing Lightning",
      type = WeaponType.POLEARM,
      rarity = 5,
      baseAtk = 608,
      subStatName = "Energy Recharge",
      subStatValue = "55.1%",
      passiveName = "Timeless Dream",
      passiveDesc = "ATK increased by 28% of Energy Recharge over the base 100%. Gain 30% Energy Recharge after using Burst."
    ),
    Weapon(
      id = "redhorn",
      name = "Redhorn Stonethresher",
      type = WeaponType.CLAYMORE,
      rarity = 5,
      baseAtk = 542,
      subStatName = "CRIT DMG",
      subStatValue = "88.2%",
      passiveName = "Gokadaiou Otogibanashi",
      passiveDesc = "DEF is increased by 28%. Normal and Charged Attack DMG is increased by 40% of DEF."
    ),
    Weapon(
      id = "thundering_pulse",
      name = "Thundering Pulse",
      type = WeaponType.BOW,
      rarity = 5,
      baseAtk = 608,
      subStatName = "CRIT DMG",
      subStatValue = "66.2%",
      passiveName = "Rule By Thunder",
      passiveDesc = "Increases ATK by 20% and grants Thunder Emblem stacks that boost Normal Attack DMG by up to 40%."
    ),
    Weapon(
      id = "kagura",
      name = "Kagura's Verity",
      type = WeaponType.CATALYST,
      rarity = 5,
      baseAtk = 608,
      subStatName = "CRIT DMG",
      subStatValue = "66.2%",
      passiveName = "Kagura Dance",
      passiveDesc = "Gains Kagura Dance effect when using Elemental Skill, increasing Elemental Skill DMG by 12% for 16s (max 3 stacks)."
    ),
    Weapon(
      id = "hararan",
      name = "Haran Geppaku Futsu",
      type = WeaponType.SWORD,
      rarity = 5,
      baseAtk = 608,
      subStatName = "CRIT Rate",
      subStatValue = "33.1%",
      passiveName = "Honed Flow",
      passiveDesc = "Obtain 12% All Elemental DMG Bonus. Grants Wavespike stacks that consume to buff Normal Attack DMG by 40%."
    ),
    Weapon(
      id = "jade_spear",
      name = "Primordial Jade Winged-Spear",
      type = WeaponType.POLEARM,
      rarity = 5,
      baseAtk = 674,
      subStatName = "CRIT Rate",
      subStatValue = "22.1%",
      passiveName = "Eagle Spear of Justice",
      passiveDesc = "On hit, increases ATK by 3.2% for 6s (max 7 stacks). At maximum stacks, DMG dealt is increased by 12%."
    ),
    Weapon(
      id = "the_catch",
      name = "The Catch",
      type = WeaponType.POLEARM,
      rarity = 4,
      baseAtk = 510,
      subStatName = "Energy Recharge",
      subStatValue = "45.9%",
      passiveName = "Shanty",
      passiveDesc = "Increases Elemental Burst DMG by 32% and Elemental Burst CRIT Rate by 12%."
    ),
    Weapon(
      id = "favonius_sword",
      name = "Favonius Sword",
      type = WeaponType.SWORD,
      rarity = 4,
      baseAtk = 454,
      subStatName = "Energy Recharge",
      subStatValue = "61.3%",
      passiveName = "Windfall",
      passiveDesc = "CRIT hits have a 100% chance to generate 6 Elemental Energy for the character every 6s."
    ),
    Weapon(
      id = "rust",
      name = "Rust",
      type = WeaponType.BOW,
      rarity = 4,
      baseAtk = 510,
      subStatName = "ATK",
      subStatValue = "41.3%",
      passiveName = "Rapid Firing",
      passiveDesc = "Increases Normal Attack DMG by 80% but decreases Charged Attack DMG by 10%."
    ),
    Weapon(
      id = "sacrificial_fragments",
      name = "Sacrificial Fragments",
      type = WeaponType.CATALYST,
      rarity = 4,
      baseAtk = 454,
      subStatName = "Elemental Mastery",
      subStatValue = "221",
      passiveName = "Composed",
      passiveDesc = "After damaging an opponent with an Elemental Skill, the skill has an 80% chance to end its own CD."
    ),
    Weapon(
      id = "serpent_spine",
      name = "Serpent Spine",
      type = WeaponType.CLAYMORE,
      rarity = 4,
      baseAtk = 510,
      subStatName = "CRIT Rate",
      subStatValue = "27.6%",
      passiveName = "Wavesplitter",
      passiveDesc = "Every 4s a character is on the field, they will deal 10% more DMG and take 3% more DMG (max 5 stacks)."
    )
  )
}
