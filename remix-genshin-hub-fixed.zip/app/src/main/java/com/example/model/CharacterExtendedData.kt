package com.example.model

enum class TalentType(val label: String) {
  NORMAL_ATTACK("Normal Attack"),
  ELEMENTAL_SKILL("Elemental Skill"),
  ELEMENTAL_BURST("Elemental Burst"),
  PASSIVE_1("1st Ascension Passive"),
  PASSIVE_2("4th Ascension Passive"),
  PASSIVE_UTILITY("Utility Passive"),
}

data class TalentInfo(
  val name: String,
  val type: TalentType,
  val description: String,
  val cooldown: String? = null,
  val energyCost: Int? = null,
)

data class ConstellationNode(
  val level: Int,
  val name: String,
  val description: String,
)

data class CharacterExtendedProfile(
  val baseDef: Int,
  val ascensionStatName: String,
  val ascensionStatValue: String,
  val affiliation: String,
  val birthday: String,
  val specialDish: String,
  val talents: List<TalentInfo>,
  val constellations: List<ConstellationNode>,
  val combatRoleSummary: String,
)

object CharacterDetailProvider {
  fun getProfile(character: Character): CharacterExtendedProfile {
    return profiles[character.id] ?: generateFallbackProfile(character)
  }

  fun calculateStats(character: Character, level: Int): Map<String, String> {
    val scale = when (level) {
      1 -> 0.08f
      20 -> 0.22f
      40 -> 0.42f
      60 -> 0.65f
      70 -> 0.78f
      80 -> 0.89f
      else -> 1.0f // Level 90
    }
    val profile = getProfile(character)
    val calculatedHp = (character.baseHp * scale).toInt()
    val calculatedAtk = (character.baseAtk * scale).toInt()
    val calculatedDef = (profile.baseDef * scale).toInt()

    val ascensionActive = level >= 60
    val statVal = if (ascensionActive) profile.ascensionStatValue else "0.0%"
    val critRateVal = if (profile.ascensionStatName == "CRIT Rate" && ascensionActive) "24.2%" else "5.0%"
    val critDmgVal = if (profile.ascensionStatName == "CRIT DMG" && ascensionActive) "88.4%" else "50.0%"
    val erVal = if (profile.ascensionStatName == "Energy Recharge" && ascensionActive) "132.0%" else "100.0%"
    val emVal = if (profile.ascensionStatName == "Elemental Mastery" && ascensionActive) profile.ascensionStatValue else "0"

    return mapOf(
      "Base HP" to "$calculatedHp",
      "Base ATK" to "$calculatedAtk",
      "Base DEF" to "$calculatedDef",
      "Ascension Stat" to statVal,
      "CRIT Rate" to critRateVal,
      "CRIT DMG" to critDmgVal,
      "Energy Recharge" to erVal,
      "Elemental Mastery" to emVal
    )
  }

  private val profiles = mapOf(
    "ineffa" to CharacterExtendedProfile(
      baseDef = 825,
      ascensionStatName = "CRIT DMG",
      ascensionStatValue = "+38.4%",
      affiliation = "Ancient Fontaine Workshop",
      birthday = "July 16",
      specialDish = "Supercharged Spring Roll",
      combatRoleSummary = "High-voltage Lunar Shielder & Coordinated Electro Sub-DPS with automatic homing burst.",
      talents = listOf(
        TalentInfo(
          name = "Ancient Vanguard Spear",
          type = TalentType.NORMAL_ATTACK,
          description = "Performs up to 5 consecutive spear thrusts infused with crackling lunar energy. Charged Attack consumes 25 Stamina to lunge forward with an electrified spiral drill."
        ),
        TalentInfo(
          name = "Thunderwave Pulse",
          type = TalentType.ELEMENTAL_SKILL,
          description = "Deploys an electrified lunar barrier that absorbs damage scaling with Ineffa's Max HP. While the barrier is active, coordinated Electro arcs fire at nearby opponents every 1.5s.",
          cooldown = "12.0s"
        ),
        TalentInfo(
          name = "Sublime Supernova Blast",
          type = TalentType.ELEMENTAL_BURST,
          description = "Calibrates the orbital workshop cannon, unleashing an apocalyptic Electro beam that deals massive AoE Electro DMG and detonates all existing elemental reactions.",
          cooldown = "15.0s",
          energyCost = 60
        ),
        TalentInfo(
          name = "Kinetic Feedback Dynamo",
          type = TalentType.PASSIVE_1,
          description = "When the Thunderwave barrier absorbs damage, all party members gain 15% ATK bonus for 10 seconds. Can trigger once every 5 seconds."
        ),
        TalentInfo(
          name = "Overclocked Overdrive",
          type = TalentType.PASSIVE_2,
          description = "Increases Ineffa's Electro DMG Bonus by 0.1% for every 100 points of Max HP above 10,000, up to a maximum bonus of 36%."
        ),
        TalentInfo(
          name = "Ancient Workshop Protocol",
          type = TalentType.PASSIVE_UTILITY,
          description = "When crafting Weapon Ascension Materials, has a 25% chance to refund a portion of the crafting materials used."
        )
      ),
      constellations = listOf(
        ConstellationNode(
          level = 1,
          name = "Resonant Capacitor",
          description = "Thunderwave barrier DMG absorption is increased by 25%. When broken or expired, releases an Electro shockwave dealing 180% of Ineffa's ATK."
        ),
        ConstellationNode(
          level = 2,
          name = "High-Voltage Overload",
          description = "Sublime Supernova Blast shreds opponents' Electro RES and Defense by 25% for 12 seconds upon hitting them."
        ),
        ConstellationNode(
          level = 3,
          name = "Orbital Calibration",
          description = "Increases the Level of Sublime Supernova Blast by 3. Maximum upgrade level is 15."
        ),
        ConstellationNode(
          level = 4,
          name = "Arc Discharge Relay",
          description = "Coordinated attacks from Thunderwave barrier restore 3 Energy to all active and off-field party members. Can trigger every 3 seconds."
        ),
        ConstellationNode(
          level = 5,
          name = "Aegis Core Matrix",
          description = "Increases the Level of Thunderwave Pulse by 3. Maximum upgrade level is 15."
        ),
        ConstellationNode(
          level = 6,
          name = "Perpetual Lightning Drive",
          description = "While shielded by Thunderwave Pulse, the active character gains +15% CRIT Rate and +45% CRIT DMG against Electro-affected enemies."
        )
      )
    ),

    "flins" to CharacterExtendedProfile(
      baseDef = 792,
      ascensionStatName = "CRIT Rate",
      ascensionStatValue = "+19.2%",
      affiliation = "Nocturnal Wandering Guild",
      birthday = "October 31",
      specialDish = "Midnight Phantom Stew",
      combatRoleSummary = "High-mobility on-field Electro Hypercarry with stance-switching specter mechanics.",
      talents = listOf(
        TalentInfo(
          name = "Phantom Lance Technique",
          type = TalentType.NORMAL_ATTACK,
          description = "Delivers 6 rapid piercing strikes with the Spirit Lantern spear. Charged attack hurls a ghost spear that pins small opponents."
        ),
        TalentInfo(
          name = "Spirit Lantern Mirage",
          type = TalentType.ELEMENTAL_SKILL,
          description = "Teleports through shadows leaving an ethereal decoy. Enters Nightfall Stance for 10s, converting Normal Attacks to pure Electro DMG and enhancing attack reach.",
          cooldown = "8.0s"
        ),
        TalentInfo(
          name = "Specter Hunt: Midnight Requiem",
          type = TalentType.ELEMENTAL_BURST,
          description = "Opens the spirit gate of the lantern, summoning a devastating tempest of specters that relentlessly strike marked enemies across the field.",
          cooldown = "18.0s",
          energyCost = 70
        ),
        TalentInfo(
          name = "Ethereal Drift",
          type = TalentType.PASSIVE_1,
          description = "During Nightfall Stance, Flins gains +20% Movement SPD and +15% Normal Attack SPD."
        ),
        TalentInfo(
          name = "Soul-Harvest Cascade",
          type = TalentType.PASSIVE_2,
          description = "Defeating an opponent under the effect of Midnight Requiem extends Nightfall Stance by 2.5 seconds, up to a maximum of 6 seconds."
        ),
        TalentInfo(
          name = "Nocturnal Wayfarer",
          type = TalentType.PASSIVE_UTILITY,
          description = "Increases Movement SPD of all party members by 10% between the hours of 18:00 and 06:00."
        )
      ),
      constellations = listOf(
        ConstellationNode(1, "Lantern of the Stray", "Nightfall Stance gains 1 additional charge, and the initial strike deals +30% Electro DMG."),
        ConstellationNode(2, "Veil of Phantoms", "Opponents struck by Midnight Requiem have their DEF reduced by 30% for 10 seconds."),
        ConstellationNode(3, "Shadow Stitcher", "Increases the Level of Spirit Lantern Mirage by 3. Maximum upgrade level is 15."),
        ConstellationNode(4, "Violet Resurgence", "When Flins takes fatal damage, he resists falling and regenerates 40% Max HP while triggering a spectral explosion."),
        ConstellationNode(5, "Ghostly Cadence", "Increases the Level of Specter Hunt: Midnight Requiem by 3. Maximum upgrade level is 15."),
        ConstellationNode(6, "Lord of the Nightfall", "During Nightfall Stance, every 3rd Normal Attack triggers a Spectral Nova dealing 320% Electro ATK.")
      )
    ),

    "alyosha" to CharacterExtendedProfile(
      baseDef = 812,
      ascensionStatName = "CRIT DMG",
      ascensionStatValue = "+38.4%",
      affiliation = "Snezhnaya Frost Wardens",
      birthday = "December 12",
      specialDish = "Northern Frost Roast",
      combatRoleSummary = "Heavy Greatsword Burst DPS capable of catastrophic single-hit Electro strikes.",
      talents = listOf(
        TalentInfo("Northern Greatsword", TalentType.NORMAL_ATTACK, "Executes 4 punishing heavy swings. Charged attack performs continuous spinning strikes ending in a massive downward slash."),
        TalentInfo("Glacial Thunder Cleave", TalentType.ELEMENTAL_SKILL, "Infuses the blade with sub-zero lightning, cleaving forward in a wide arc that launches enemies.", cooldown = "7.5s"),
        TalentInfo("Tempest of the North", TalentType.ELEMENTAL_BURST, "Leaps into the stratosphere and plunges down with divine northern lightning, creating a shattered thunder field for 12s.", cooldown = "16.0s", energyCost = 60),
        TalentInfo("Frost-Forged Edge", TalentType.PASSIVE_1, "Triggering Superconduct increases Alyosha's Physical and Electro DMG by 25% for 8 seconds."),
        TalentInfo("Unyielding Resolve", TalentType.PASSIVE_2, "When HP falls below 50%, Base ATK is boosted by 30% and interruption resistance is drastically increased."),
        TalentInfo("Polar Expedition Mastery", TalentType.PASSIVE_UTILITY, "Reduces the expedition time in Snezhnaya and Mondstadt by 25%.")
      ),
      constellations = listOf(
        ConstellationNode(1, "Frostbite Cleaver", "Glacial Thunder Cleave has its CRIT Rate increased by 15% and inflicts Frost Shock."),
        ConstellationNode(2, "Thunderous Roar", "Opponents inside Tempest of the North have their Physical and Electro RES shredded by 20%."),
        ConstellationNode(3, "Blizzard Stance", "Increases the Level of Glacial Thunder Cleave by 3."),
        ConstellationNode(4, "Glacier Wall", "Gains a frost shield equal to 25% of Max HP upon casting Elemental Burst."),
        ConstellationNode(5, "Crown of the North", "Increases the Level of Tempest of the North by 3."),
        ConstellationNode(6, "Winter Sovereign", "Normal and Charged attacks ignore 40% of the target's Defense while in the tempest field.")
      )
    ),

    "varka" to CharacterExtendedProfile(
      baseDef = 835,
      ascensionStatName = "Anemo DMG Bonus",
      ascensionStatValue = "+28.8%",
      affiliation = "Knights of Favonius",
      birthday = "March 10",
      specialDish = "Knightly Meat Platter",
      combatRoleSummary = "Charismatic Grand Master driving roaring Anemo gales and crowd-sweeping vortexes.",
      talents = listOf(
        TalentInfo("Favonius Sword Feats", TalentType.NORMAL_ATTACK, "Performs 5 commanding sword slashes. Charged attack unleashes two fierce crossing wind blades."),
        TalentInfo("Boreas Gale Force", TalentType.ELEMENTAL_SKILL, "Gathers howling northern winds into the blade and thrusts forward, creating a forward vacuum tunnel.", cooldown = "6.0s"),
        TalentInfo("Wrath of the Northern Wolf", TalentType.ELEMENTAL_BURST, "Manifests the spirit of the Great Wolf, howling across the battlefield and pulling in all opponents with continuous Anemo gales.", cooldown = "15.0s", energyCost = 60),
        TalentInfo("Gale-Rider", TalentType.PASSIVE_1, "Swirl reactions increase the ATK of all party members by 20% for 10 seconds."),
        TalentInfo("Pack Leader", TalentType.PASSIVE_2, "Party members within the burst field gain 15% Anemo DMG and 10% Movement SPD."),
        TalentInfo("Grand Master's Guidance", TalentType.PASSIVE_UTILITY, "Displays the location of nearby resources unique to Mondstadt on the mini-map.")
      ),
      constellations = listOf(
        ConstellationNode(1, "Eye of the Blizzard", "Boreas Gale Force pulls enemies with 50% stronger suction force."),
        ConstellationNode(2, "Pack Sentinel", "Decreases the Anemo RES of opponents struck by Elemental Burst by 25%."),
        ConstellationNode(3, "Knightly Heritage", "Increases the Level of Boreas Gale Force by 3."),
        ConstellationNode(4, "Howling Tempest", "When Swirl is triggered, regenerates 3.5 Energy for all party members."),
        ConstellationNode(5, "Lupine Wrath", "Increases the Level of Wrath of the Northern Wolf by 3."),
        ConstellationNode(6, "Apex Sovereign", "Normal attacks unleash miniature razor winds dealing 80% ATK as Anemo DMG.")
      )
    ),

    "columbina" to CharacterExtendedProfile(
      baseDef = 760,
      ascensionStatName = "HP%",
      ascensionStatValue = "+28.8%",
      affiliation = "Fatui Harbingers",
      birthday = "February 14",
      specialDish = "Ethereal Lullaby Nectar",
      combatRoleSummary = "Mystical Off-field Hydro enabler and team buffer with soothing choral resonance.",
      talents = listOf(
        TalentInfo("Lullaby Threads", TalentType.NORMAL_ATTACK, "Conducts 4 delicate strikes using hydro starlight filaments."),
        TalentInfo("Dreamveil Chorus", TalentType.ELEMENTAL_SKILL, "Summons a floating halo of hydro feathers that orbits the active character, applying Wet and healing allies.", cooldown = "10.0s"),
        TalentInfo("Serenade of the Abyss", TalentType.ELEMENTAL_BURST, "Begins a haunting celestial melody, submerging the domain in ethereal waters and amplifying party Elemental Burst DMG by 30%.", cooldown = "16.0s", energyCost = 70),
        TalentInfo("Submerged Slumber", TalentType.PASSIVE_1, "Hydro feathers restore 20% more HP when the active character is below 50% HP."),
        TalentInfo("Harmonic Echo", TalentType.PASSIVE_2, "Every 1,000 points of Columbina's Max HP increases party Elemental Reaction DMG by 1.2%."),
        TalentInfo("Enigmatic Grace", TalentType.PASSIVE_UTILITY, "Decreases swimming stamina consumption for party members by 20%.")
      ),
      constellations = listOf(
        ConstellationNode(1, "Feathers of Silence", "Dreamveil Chorus summons 2 additional orbiting hydro feathers."),
        ConstellationNode(2, "Sleepwalker's Blessing", "All party members gain 250 Elemental Mastery while within the burst domain."),
        ConstellationNode(3, "Choral Reverie", "Increases the Level of Dreamveil Chorus by 3."),
        ConstellationNode(4, "Nocturne Weave", "When an ally triggers Vaporize or Electro-Charged, regenerates 5 Energy for Columbina."),
        ConstellationNode(5, "Diva of the Deep", "Increases the Level of Serenade of the Abyss by 3."),
        ConstellationNode(6, "Eternal Serenade", "Party members gain +30% CRIT DMG for Hydro and Vaporize attacks during the burst.")
      )
    ),

    "durin" to CharacterExtendedProfile(
      baseDef = 805,
      ascensionStatName = "Pyro DMG Bonus",
      ascensionStatValue = "+28.8%",
      affiliation = "Dragonspine Dragon Core",
      birthday = "December 21",
      specialDish = "Embers of Dragonspine",
      combatRoleSummary = "Furious Pyro Claymore carry fueled by draconic embers and scorching frostburn.",
      talents = listOf(
        TalentInfo("Draconic Cleave", TalentType.NORMAL_ATTACK, "Strikes 4 times with the fiery dragonfang claymore."),
        TalentInfo("Corrupted Flame Slash", TalentType.ELEMENTAL_SKILL, "Slashes with abyssal fire, generating 3 Dragon Core embers that scorch surrounding foes.", cooldown = "8.0s"),
        TalentInfo("Awakening: Draconic Wrath", TalentType.ELEMENTAL_BURST, "Releases the full draconic core within, bathing the arena in primordial flames and entering Dragonfire state.", cooldown = "15.0s", energyCost = 60),
        TalentInfo("Blazing Resilience", TalentType.PASSIVE_1, "Immune to Sheer Cold effects and gains +15% Pyro DMG in low temperature zones."),
        TalentInfo("Draconic Core Overload", TalentType.PASSIVE_2, "Each active Dragon Core ember increases Durin's Normal and Charged Attack DMG by 12%."),
        TalentInfo("Mountain Pathfinder", TalentType.PASSIVE_UTILITY, "Decreases climbing stamina consumption by 20% for your party members.")
      ),
      constellations = listOf(
        ConstellationNode(1, "Draco Ignis Core", "Elemental Skill generates 2 additional embers and refunds 10 Energy."),
        ConstellationNode(2, "Corrupted Embers", "Opponents scorched by Durin suffer -25% Pyro RES for 8 seconds."),
        ConstellationNode(3, "Dragonblood Surge", "Increases the Level of Corrupted Flame Slash by 3."),
        ConstellationNode(4, "Scale of the Wyrm", "Gains a pyro shield that absorbs 20% of Max HP when entering Dragonfire state."),
        ConstellationNode(5, "Primordial Blaze", "Increases the Level of Awakening: Draconic Wrath by 3."),
        ConstellationNode(6, "Calamity of Dragonspine", "In Dragonfire state, all attacks ignore 35% Defense and deal +50% CRIT DMG.")
      )
    )
  )

  private fun generateFallbackProfile(character: Character): CharacterExtendedProfile {
    val elem = character.element.displayName
    val elemDmg = "$elem DMG Bonus"
    return CharacterExtendedProfile(
      baseDef = 780,
      ascensionStatName = elemDmg,
      ascensionStatValue = "+28.8%",
      affiliation = "Teyvat Adventurers Guild",
      birthday = "June 1",
      specialDish = "Signature Specialty Delicacy",
      combatRoleSummary = "${character.role} leveraging ${elem} elemental masteries.",
      talents = listOf(
        TalentInfo(
          name = "${character.weapon.displayName} Martial Form",
          type = TalentType.NORMAL_ATTACK,
          description = "Performs up to 5 consecutive weapon strikes tailored to the ${character.weapon.displayName} discipline."
        ),
        TalentInfo(
          name = "${character.name}'s Elemental Surge",
          type = TalentType.ELEMENTAL_SKILL,
          description = "Channels pristine ${elem} energy forward, dealing AoE ${elem} DMG and applying elemental status.",
          cooldown = "8.0s"
        ),
        TalentInfo(
          name = "Grand ${character.constellation} Cataclysm",
          type = TalentType.ELEMENTAL_BURST,
          description = "Unleashes the supreme power of the ${character.constellation}, devastating adversaries with an expansive ${elem} vortex.",
          cooldown = "15.0s",
          energyCost = 60
        ),
        TalentInfo(
          name = "Ascension Insight",
          type = TalentType.PASSIVE_1,
          description = "Triggering ${elem} elemental reactions boosts party ATK by 15% for 10 seconds."
        ),
        TalentInfo(
          name = "Tactical Mastery",
          type = TalentType.PASSIVE_2,
          description = "Increases ${elem} DMG Bonus by 20% when Energy is above 50%."
        ),
        TalentInfo(
          name = "Expedition Prodigy",
          type = TalentType.PASSIVE_UTILITY,
          description = "Decreases expedition duration by 25% when dispatched in their native nation."
        )
      ),
      constellations = (1..6).map { level ->
        ConstellationNode(
          level = level,
          name = "${character.constellation} Node $level",
          description = when (level) {
            1 -> "Enhances ${character.name}'s Elemental Skill with an extra charge and +20% initial DMG."
            2 -> "Reduces opponents' ${elem} RES by 25% when struck by Elemental Burst for 10 seconds."
            3 -> "Increases the Level of Elemental Skill by 3. Maximum upgrade level is 15."
            4 -> "Restores 4 Energy to all party members whenever an elemental reaction is triggered."
            5 -> "Increases the Level of Elemental Burst by 3. Maximum upgrade level is 15."
            else -> "Ultimate unlock: Increases CRIT Rate by 15% and CRIT DMG by 40% during elemental burst."
          }
        )
      }
    )
  }
}
