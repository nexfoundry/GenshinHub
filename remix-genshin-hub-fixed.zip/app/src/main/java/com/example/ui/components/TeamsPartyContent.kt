package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Character
import com.example.model.ElementType
import com.example.ui.theme.BackgroundNavy
import com.example.ui.theme.CardBorderNavy
import com.example.ui.theme.CardNavy
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.StarGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.rememberSubtleHaptics

@Composable
fun TeamsPartyContent(
  activeParty: List<Character>,
  allCharacters: List<Character>,
  onAddToParty: (Character) -> Unit,
  onRemoveFromParty: (String) -> Unit,
  onClearParty: () -> Unit,
  onCharacterClick: (Character) -> Unit,
  modifier: Modifier = Modifier,
  onBackToHome: (() -> Unit)? = null,
) {
  val subtleHaptics = rememberSubtleHaptics()

  // Calculate elemental resonance based on active party
  val resonanceTitle by remember(activeParty) {
    derivedStateOf {
      val elementCounts = activeParty.groupingBy { it.element }.eachCount()
      when {
        (elementCounts[ElementType.PYRO] ?: 0) >= 2 -> "Fervent Flames (+25% ATK)"
        (elementCounts[ElementType.HYDRO] ?: 0) >= 2 -> "Soothing Water (+25% Max HP)"
        (elementCounts[ElementType.ANEMO] ?: 0) >= 2 -> "Impetuous Winds (+10% Movement SPD, -5% Skill CD)"
        (elementCounts[ElementType.ELECTRO] ?: 0) >= 2 -> "High Voltage (Generates Energy Particles on Reactions)"
        (elementCounts[ElementType.DENDRO] ?: 0) >= 2 -> "Sprawling Greenery (+50~100 Elemental Mastery)"
        (elementCounts[ElementType.CRYO] ?: 0) >= 2 -> "Shattering Ice (+15% CRIT Rate against Frozen foes)"
        (elementCounts[ElementType.GEO] ?: 0) >= 2 -> "Enduring Rock (+15% Shield Strength & +15% DMG)"
        activeParty.map { it.element }.distinct().size >= 4 -> "Protective Canopy (+15% All Elemental & Physical RES)"
        else -> "Party Ready (Add 2 matching elements for resonance)"
      }
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(BackgroundNavy)
      .testTag("screen_teams_party"),
    contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 120.dp)
  ) {
    // 1. Header Banner & Party Count
    item(key = "party_header") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (onBackToHome != null) {
            IconButton(
              onClick = {
                subtleHaptics.performBack()
                onBackToHome()
              },
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0xFF131A33))
                .border(1.dp, Color(0xFF233055), CircleShape)
                .testTag("btn_teams_back_home")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back to Home",
                tint = TextPrimary,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
          }
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(PurplePrimary.copy(alpha = 0.2f))
              .border(1.dp, PurpleLight, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Groups,
              contentDescription = null,
              tint = PurpleLight,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Active Party Lineup",
              color = TextPrimary,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "${activeParty.size}/4 Members Selected",
              color = PurpleLight,
              fontSize = 12.sp
            )
          }
        }

        if (activeParty.isNotEmpty()) {
          IconButton(
            onClick = {
              subtleHaptics.performPartyRemove()
              onClearParty()
            },
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(Color(0xFF1B2342))
              .testTag("btn_clear_party")
          ) {
            Icon(
              imageVector = Icons.Default.DeleteSweep,
              contentDescription = "Clear Party",
              tint = TextMuted,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Elemental Resonance Indicator
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101733)),
        border = BorderStroke(1.dp, Color(0x336378B5))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Rounded.Whatshot,
            contentDescription = null,
            tint = PurpleLight,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = resonanceTitle,
            color = TextSecondary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
    }

    // 2. The 4 Active Party Slots Grid
    item(key = "party_slots_grid") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        for (slotIndex in 0 until 4) {
          val character = activeParty.getOrNull(slotIndex)
          Box(modifier = Modifier.weight(1f)) {
            PartySlotCard(
              slotNumber = slotIndex + 1,
              character = character,
              onCharacterClick = { char ->
                subtleHaptics.performCardTap()
                onCharacterClick(char)
              },
              onRemove = { charId ->
                subtleHaptics.performPartyRemove()
                onRemoveFromParty(charId)
              }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))
    }

    // 3. Section Title: Add Characters to Lineup
    item(key = "roster_header") {
      Text(
        text = "TAP A CHARACTER TO ADD TO PARTY",
        color = TextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.8.sp
      )
      Spacer(modifier = Modifier.height(8.dp))
    }

    // 4. Character Roster List
    items(
      items = allCharacters,
      key = { it.id }
    ) { char ->
      val isInParty = activeParty.any { it.id == char.id }

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
          .animateItem(
            fadeInSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing),
            fadeOutSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
            placementSpec = spring(dampingRatio = 0.82f, stiffness = 380f)
          )
          .clip(RoundedCornerShape(14.dp))
          .clickable {
            subtleHaptics.performCardTap()
            onCharacterClick(char)
          }
          .testTag("party_roster_card_${char.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (isInParty) Color(0xFF182042) else CardNavy
        ),
        border = BorderStroke(
          1.dp,
          if (isInParty) char.element.color.copy(alpha = 0.6f) else CardBorderNavy
        )
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Portrait thumbnail
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0xFF131A36))
          ) {
            CharacterPortraitArt(
              character = char,
              modifier = Modifier.fillMaxSize()
            )
            ElementBadge(
              element = char.element,
              size = 16.dp,
              modifier = Modifier
                .padding(3.dp)
                .align(Alignment.TopStart)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          // Meta
          Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = char.name,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.width(6.dp))
              repeat(char.rarity) {
                Icon(
                  imageVector = Icons.Filled.Star,
                  contentDescription = null,
                  tint = StarGold,
                  modifier = Modifier.size(9.dp)
                )
              }
            }
            Text(
              text = "${char.role} • ${char.weapon.displayName}",
              color = TextSecondary,
              fontSize = 11.sp
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          // Add / In-Party Button with subtle haptics
          if (isInParty) {
            OutlinedButton(
              onClick = {
                subtleHaptics.performPartyRemove()
                onRemoveFromParty(char.id)
              },
              shape = RoundedCornerShape(10.dp),
              border = BorderStroke(1.dp, Color(0xFF5A3048)),
              colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Color(0xFFFB7185)
              ),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              modifier = Modifier
                .height(34.dp)
                .testTag("btn_remove_party_${char.id}")
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Remove",
                modifier = Modifier.size(13.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(text = "In Party", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
            }
          } else {
            Button(
              onClick = {
                subtleHaptics.performPartyAdd()
                onAddToParty(char)
              },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = PurplePrimary,
                contentColor = Color.White
              ),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              modifier = Modifier
                .height(34.dp)
                .testTag("btn_add_party_${char.id}")
            ) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add",
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(text = "Add", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PartySlotCard(
  slotNumber: Int,
  character: Character?,
  onCharacterClick: (Character) -> Unit,
  onRemove: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  if (character != null) {
    Card(
      modifier = modifier
        .fillMaxWidth()
        .height(138.dp)
        .clip(RoundedCornerShape(12.dp))
        .clickable { onCharacterClick(character) }
        .testTag("party_slot_$slotNumber"),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = CardNavy),
      border = BorderStroke(1.5.dp, character.element.color.copy(alpha = 0.7f))
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        CharacterPortraitArt(
          character = character,
          modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(55.dp)
            .align(Alignment.BottomCenter)
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, Color(0xE6050816), Color(0xFF050816))
              )
            )
        )

        // Top Row: Slot number badge & Remove icon
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          ElementBadge(element = character.element, size = 16.dp)

          Box(
            modifier = Modifier
              .size(20.dp)
              .clip(CircleShape)
              .background(Color(0x99000000))
              .clickable { onRemove(character.id) }
              .testTag("slot_remove_${character.id}"),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Remove",
              tint = Color.White,
              modifier = Modifier.size(11.dp)
            )
          }
        }

        // Bottom label: Name & Role
        Column(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 4.dp)
        ) {
          Text(
            text = character.name,
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = character.role,
            color = PurpleLight,
            fontSize = 9.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }
    }
  } else {
    // Empty Slot
    Card(
      modifier = modifier
        .fillMaxWidth()
        .height(138.dp)
        .testTag("empty_party_slot_$slotNumber"),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0x33101633)),
      border = BorderStroke(1.dp, Color(0x336378B5))
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Box(
          modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(Color(0x26FFFFFF)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(18.dp)
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Slot $slotNumber",
          color = TextMuted,
          fontSize = 10.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}
