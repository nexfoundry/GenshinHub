package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Visual themes for the three redemption reward cards matching the reference image.
 */
enum class RedemptionThemeType {
  PRIMO_BLUE,
  MORA_PURPLE,
  PRIMO_GOLD
}

/**
 * Data model for a Genshin Impact redemption code item.
 */
data class RedemptionCodeItem(
  val id: String,
  val code: String,
  val categoryTag: String,
  val rewardAmount: String,
  val rewardName: String,
  val validityText: String = "Valid until -",
  val themeType: RedemptionThemeType,
  val tagBgColor: Color,
  val tagTextColor: Color,
)

/**
 * Exactly three cards matching the visual reference image:
 * Card 1: ×60 Primogems | FREEMOGEMS v3.6 | GA9FPD42SJ4V
 * Card 2: Mora / Various items | MORA & FRIENDS | LAQZMTPKNTYH
 * Card 3: ×50 Primogems | FREEMOGEMS | GENSHINGIFT
 */
val defaultRedemptionCodes = listOf(
  RedemptionCodeItem(
    id = "freemogems_1",
    code = "GA9FPD42SJ4V",
    categoryTag = "FREEMOGEMS v3.6",
    rewardAmount = "× 60",
    rewardName = "Primogems",
    validityText = "Valid until -",
    themeType = RedemptionThemeType.PRIMO_BLUE,
    tagBgColor = Color(0xFF1D4ED8),
    tagTextColor = Color(0xFFBAE6FD),
  ),
  RedemptionCodeItem(
    id = "mora_friends",
    code = "LAQZMTPKNTYH",
    categoryTag = "MORA & FRIENDS",
    rewardAmount = "× 0",
    rewardName = "Various items",
    validityText = "Valid until -",
    themeType = RedemptionThemeType.MORA_PURPLE,
    tagBgColor = Color(0xFF6D28D9),
    tagTextColor = Color(0xFFE9D5FF),
  ),
  RedemptionCodeItem(
    id = "genshingift",
    code = "GENSHINGIFT",
    categoryTag = "FREEMOGEMS",
    rewardAmount = "× 50",
    rewardName = "Primogems",
    validityText = "Valid until -",
    themeType = RedemptionThemeType.PRIMO_GOLD,
    tagBgColor = Color(0xFFB45309),
    tagTextColor = Color(0xFFFEF3C7),
  )
)

/**
 * Compact Floating Bottom Sheet displaying current active Redemption Codes.
 *
 * Characteristics:
 * - Takes ~70-75% screen height (the top portion of the screen remains visible behind darkened scrim)
 * - No X button; top center has a sleek drag handle `──────`
 * - User dismisses by tapping outside on the scrim or swiping downward
 * - Features exactly 3 large horizontal cards matching the reference image layout:
 *   - Left 30-32%: dominant glowing reward artwork panel (Primogem crystal / Paimon mascot)
 *   - Right 68-70%: source tag, monospace code with copy button, validity info
 */
@Composable
fun RedemptionCodesSheet(
  onDismiss: () -> Unit,
  onCodeCopied: (String) -> Unit = {},
  codes: List<RedemptionCodeItem> = defaultRedemptionCodes,
  modifier: Modifier = Modifier,
) {
  BackHandler(onBack = onDismiss)

  val clipboardManager = LocalClipboardManager.current
  val haptic = LocalHapticFeedback.current
  val uriHandler = LocalUriHandler.current
  val scope = rememberCoroutineScope()
  val scrollState = rememberScrollState()

  // Track copied feedback state per code ID (shows checkmark for 2 seconds)
  val copiedStateMap = remember { mutableStateMapOf<String, Boolean>() }

  // Staggered entrance animation state for cards
  var cardsVisible by remember { mutableStateOf(false) }
  LaunchedEffect(Unit) {
    cardsVisible = true
  }

  // Drag-to-dismiss downward offset
  var dragOffsetY by remember { mutableFloatStateOf(0f) }
  val animatedDragOffsetY by animateFloatAsState(
    targetValue = dragOffsetY,
    animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
    label = "sheet_drag_offset"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .testTag("sheet_redemption_codes")
  ) {
    // 1. Scrim overlay: Click outside to dismiss
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black.copy(alpha = 0.65f))
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null
        ) { onDismiss() }
    )

    // 2. Compact Bottom Sheet panel: ~70% screen height, rounded top corners
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.70f)
        .align(Alignment.BottomCenter)
        .offset { IntOffset(0, animatedDragOffsetY.roundToInt()) }
        .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
        .background(Color(0xFF070B18))
        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null
        ) { /* Prevent dismissing when tapping sheet background */ }
        .pointerInput(Unit) {
          detectVerticalDragGestures(
            onVerticalDrag = { change, dragAmount ->
              if (dragAmount > 0 || dragOffsetY > 0) {
                dragOffsetY = (dragOffsetY + dragAmount).coerceAtLeast(0f)
                change.consume()
              }
            },
            onDragEnd = {
              if (dragOffsetY > 110f) {
                onDismiss()
              } else {
                dragOffsetY = 0f
              }
            },
            onDragCancel = {
              dragOffsetY = 0f
            }
          )
        }
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(scrollState)
          .navigationBarsPadding()
          .padding(horizontal = 16.dp)
          .padding(top = 12.dp, bottom = 24.dp)
      ) {
        // Drag Handle at top center (replaces X close button)
        Box(
          modifier = Modifier
            .align(Alignment.CenterHorizontally)
            .padding(top = 2.dp, bottom = 14.dp)
            .width(44.dp)
            .height(5.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFF475569))
        )

        // Top Header Row with Title, Subtitle, and Genshin Impact Compass Brand (NO X button)
        RedemptionSheetHeader()

        Spacer(modifier = Modifier.height(18.dp))

        // Exactly the 3 Redemption Code Cards
        Column(
          verticalArrangement = Arrangement.spacedBy(14.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          codes.forEachIndexed { index, item ->
            val isCopied = copiedStateMap[item.id] == true

            val cardAlpha by animateFloatAsState(
              targetValue = if (cardsVisible) 1f else 0f,
              animationSpec = tween(
                durationMillis = 380,
                delayMillis = 60 + index * 85,
                easing = FastOutSlowInEasing
              ),
              label = "card_alpha_$index"
            )

            val cardOffsetY by animateDpAsState(
              targetValue = if (cardsVisible) 0.dp else 26.dp,
              animationSpec = tween(
                durationMillis = 420,
                delayMillis = 60 + index * 85,
                easing = FastOutSlowInEasing
              ),
              label = "card_offset_$index"
            )

            RedemptionCodeCard(
              item = item,
              isCopied = isCopied,
              onCopy = {
                clipboardManager.setText(AnnotatedString(item.code))
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                copiedStateMap[item.id] = true
                onCodeCopied(item.code)
                scope.launch {
                  delay(2000)
                  copiedStateMap[item.id] = false
                }
              },
              testTag = "card_redemption_$index",
              modifier = Modifier.graphicsLayer {
                alpha = cardAlpha
                translationY = cardOffsetY.toPx()
              }
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bottom Info Notice Pill matching reference
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(100.dp))
            .background(Color(0xFF091224).copy(alpha = 0.92f))
            .border(1.dp, Color(0xFF172540), RoundedCornerShape(100.dp))
            .padding(horizontal = 16.dp, vertical = 11.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Box(
              modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(Color(0xFF2563EB)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Rounded.Info,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(13.dp)
              )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Text(
              text = "Codes may have a limited time validity. Redeem them as soon as possible!",
              color = Color(0xFF8FA1B8),
              fontSize = 11.5.sp,
              lineHeight = 15.sp,
              fontWeight = FontWeight.Normal,
              modifier = Modifier.weight(1f)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Direct Link to Hoyoverse Official Code Redemption Portal
        Button(
          onClick = {
            try {
              uriHandler.openUri("https://genshin.hoyoverse.com/en/gift")
            } catch (_: Exception) {
            }
          },
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF1E1B4B),
            contentColor = Color(0xFFC084FC)
          ),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4338CA).copy(alpha = 0.6f)),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .testTag("btn_open_hoyoverse_redeem")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
              contentDescription = null,
              tint = Color(0xFFC084FC),
              modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Open Official HoYoverse Redeem Site",
              color = Color(0xFFE9D5FF),
              fontSize = 13.5.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }
    }
  }
}

/**
 * Header of the Redemption Sheet matching reference image:
 * - Left: "Redemption Code" title & "Redeem codes to get in-game rewards" subtitle
 * - Right: Genshin Impact star compass crest with "GENSHIN IMPACT" subtitle (No X button!)
 */
@Composable
private fun RedemptionSheetHeader(
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(top = 2.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = "Redemption Code",
        color = Color(0xFFF8FAFC),
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.2.sp
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = "Redeem codes to get in-game rewards",
        color = Color(0xFF8FA1B8),
        fontSize = 13.sp,
        fontWeight = FontWeight.Normal
      )
    }

    // Genshin Impact Star Compass Crest & label on right
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier.padding(end = 4.dp)
    ) {
      GenshinCrestWatermark(
        size = 32.dp,
        color = Color(0xFF94A3B8).copy(alpha = 0.75f)
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = "GENSHIN",
        color = Color(0xFF94A3B8).copy(alpha = 0.8f),
        fontSize = 8.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.2.sp
      )
      Text(
        text = "IMPACT",
        color = Color(0xFF94A3B8).copy(alpha = 0.8f),
        fontSize = 7.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.2.sp
      )
    }
  }
}

/**
 * Individual Redemption Code Card matching reference image:
 * - Left (~31% width): Large celestial reward artwork panel with 3D faceted Primogem crystal / mascot artwork,
 *   reward quantity (e.g. × 60) & label (Primogems)
 * - Right (~69% width): Rounded pill badge, Monospace Code container with themed Copy button, and Calendar validity row
 */
@Composable
private fun RedemptionCodeCard(
  item: RedemptionCodeItem,
  isCopied: Boolean,
  onCopy: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  // Theme-specific colors and gradients matching reference image
  val (cardBorderGradient, cardBgColor, copyBtnBg, watermarkColor, leftArtGradient, leftArtBorder) = when (item.themeType) {
    RedemptionThemeType.PRIMO_BLUE -> Tuple6(
      Brush.horizontalGradient(
        listOf(
          Color(0xFF38BDF8).copy(alpha = 0.75f),
          Color(0xFF1D4ED8).copy(alpha = 0.35f),
          Color(0xFF38BDF8).copy(alpha = 0.65f)
        )
      ),
      Color(0xFF070E22),
      Color(0xFF2563EB),
      Color(0xFF38BDF8).copy(alpha = 0.08f),
      Brush.verticalGradient(listOf(Color(0xFF0B1E54), Color(0xFF132F6E), Color(0xFF070C1E))),
      Color(0xFF38BDF8).copy(alpha = 0.45f)
    )
    RedemptionThemeType.MORA_PURPLE -> Tuple6(
      Brush.horizontalGradient(
        listOf(
          Color(0xFFA855F7).copy(alpha = 0.75f),
          Color(0xFF6D28D9).copy(alpha = 0.35f),
          Color(0xFFA855F7).copy(alpha = 0.65f)
        )
      ),
      Color(0xFF0C0A20),
      Color(0xFF7C3AED),
      Color(0xFFA855F7).copy(alpha = 0.08f),
      Brush.verticalGradient(listOf(Color(0xFF240C4C), Color(0xFF3D166B), Color(0xFF0C061A))),
      Color(0xFFA855F7).copy(alpha = 0.45f)
    )
    RedemptionThemeType.PRIMO_GOLD -> Tuple6(
      Brush.horizontalGradient(
        listOf(
          Color(0xFFFBBF24).copy(alpha = 0.75f),
          Color(0xFFB45309).copy(alpha = 0.35f),
          Color(0xFFFBBF24).copy(alpha = 0.65f)
        )
      ),
      Color(0xFF130F14),
      Color(0xFFD97706),
      Color(0xFFF59E0B).copy(alpha = 0.08f),
      Brush.verticalGradient(listOf(Color(0xFF2F1704), Color(0xFF522507), Color(0xFF0E0A16))),
      Color(0xFFF59E0B).copy(alpha = 0.45f)
    )
  }

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(138.dp)
      .clip(RoundedCornerShape(20.dp))
      .background(cardBgColor)
      .border(1.2.dp, cardBorderGradient, RoundedCornerShape(20.dp))
      .testTag(testTag)
  ) {
    // Genshin Star watermark in card background (as shown in reference)
    GenshinCrestWatermark(
      size = 110.dp,
      color = watermarkColor,
      modifier = Modifier
        .align(Alignment.CenterEnd)
        .padding(end = 12.dp)
    )

    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // -------------------------------------------------------------
      // Left Section: Reward Artwork Box (~31.5% of card width)
      // Visually dominant large reward presentation
      // -------------------------------------------------------------
      Box(
        modifier = Modifier
          .fillMaxHeight()
          .fillMaxWidth(0.315f)
          .clip(RoundedCornerShape(16.dp))
          .background(leftArtGradient)
          .border(1.dp, leftArtBorder, RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
      ) {
        // Celestial background artwork & sparkles
        when (item.themeType) {
          RedemptionThemeType.PRIMO_BLUE -> PrimogemRewardArt(themeColor = Color(0xFF38BDF8))
          RedemptionThemeType.MORA_PURPLE -> MascotRewardArt(themeColor = Color(0xFFA855F7))
          RedemptionThemeType.PRIMO_GOLD -> LanternPrimogemArt(themeColor = Color(0xFFF59E0B))
        }

        // Bottom text overlay inside the visual badge
        Column(
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 6.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = item.rewardAmount,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp
          )
          Text(
            text = item.rewardName,
            color = Color(0xFFCBD5E1),
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      Spacer(modifier = Modifier.width(10.dp))

      // -------------------------------------------------------------
      // Right Section: Source Pill, Code Field + Copy Action, Validity (~68.5%)
      // -------------------------------------------------------------
      Column(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight()
          .padding(vertical = 4.dp, horizontal = 2.dp),
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        // 1. Source Label Pill (e.g. FREEMOGEMS v3.6, MORA & FRIENDS, FREEMOGEMS)
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(item.tagBgColor)
            .padding(horizontal = 11.dp, vertical = 3.5.dp)
        ) {
          Text(
            text = item.categoryTag,
            color = item.tagTextColor,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.4.sp
          )
        }

        // 2. Code Container with embedded Copy Button
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF060918).copy(alpha = 0.92f))
            .border(1.dp, Color(0xFF1B2342), RoundedCornerShape(12.dp))
            .padding(start = 10.dp, end = 4.dp),
          contentAlignment = Alignment.CenterStart
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            // Code text in clean bold Monospace
            Text(
              text = item.code,
              color = Color.White,
              fontSize = 14.5.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
              letterSpacing = 0.6.sp,
              maxLines = 1,
              modifier = Modifier.weight(1f)
            )

            // Premium square Copy button matching reference
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(if (isCopied) Color(0xFF16A34A) else copyBtnBg)
                .clickable { onCopy() }
                .testTag("btn_copy_${item.code}"),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = if (isCopied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                contentDescription = if (isCopied) "Copied" else "Copy Code",
                tint = Color.White,
                modifier = Modifier.size(17.dp)
              )
            }
          }
        }

        // 3. Validity Row
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(start = 2.dp, bottom = 2.dp)
        ) {
          Icon(
            imageVector = Icons.Outlined.CalendarToday,
            contentDescription = null,
            tint = Color(0xFF64748B),
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = item.validityText,
            color = Color(0xFF94A3B8),
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Normal
          )
        }
      }
    }
  }
}

/**
 * Primogem Graphic for Cards 1 & 3:
 * Recreates the iconic 4-pointed faceted Genshin Primogem star crystal
 * with sparkling starry night skyline aura and architecture silhouette.
 */
@Composable
private fun PrimogemRewardArt(
  themeColor: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height
    val cx = w / 2f
    val cy = h * 0.35f

    // Soft celestial radial glow aura behind the Primogem
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(
          Color(0x6638BDF8),
          Color(0x221D4ED8),
          Color.Transparent
        ),
        center = Offset(cx, cy),
        radius = w * 0.50f
      )
    )

    // City architecture silhouette at bottom of art window
    drawCitySilhouette(
      w = w,
      h = h,
      silhouetteColor = Color(0xFF06102B).copy(alpha = 0.75f),
      windowGlowColor = Color(0xFFFDE047)
    )

    // Twinkling background star sparkles
    drawSparkle(cx - w * 0.32f, cy - h * 0.16f, 5.5f, Color(0xFF93C5FD))
    drawSparkle(cx + w * 0.32f, cy - h * 0.12f, 4.5f, Color(0xFFBAE6FD))
    drawSparkle(cx - w * 0.28f, cy + h * 0.18f, 4f, Color(0xFF60A5FA))
    drawSparkle(cx + w * 0.28f, cy + h * 0.16f, 5f, Color(0xFFFDE047))

    // Draw the 3D Faceted Primogem Crystal
    drawPrimogemCrystal(cx, cy, w * 0.50f, h * 0.44f)
  }
}

/**
 * Mascot Graphic for Card 2:
 * Recreates the golden halo crown, chibi mascot silhouette, and star sparkles
 * matching the reference card's purple aesthetic.
 */
@Composable
private fun MascotRewardArt(
  themeColor: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height
    val cx = w / 2f
    val cy = h * 0.36f

    // Purple radiant nebula glow
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(
          Color(0x66A855F7),
          Color(0x227C3AED),
          Color.Transparent
        ),
        center = Offset(cx, cy),
        radius = w * 0.52f
      )
    )

    // City silhouette in purple twilight
    drawCitySilhouette(
      w = w,
      h = h,
      silhouetteColor = Color(0xFF130726).copy(alpha = 0.75f),
      windowGlowColor = Color(0xFFFDE047)
    )

    // Twinkling golden & violet star sparkles
    drawSparkle(cx - w * 0.34f, cy - h * 0.16f, 6f, Color(0xFFFBBF24))
    drawSparkle(cx + w * 0.32f, cy - h * 0.14f, 5f, Color(0xFFFDE047))
    drawSparkle(cx - w * 0.26f, cy + h * 0.16f, 4f, Color(0xFFE9D5FF))
    drawSparkle(cx + w * 0.30f, cy + h * 0.18f, 4f, Color(0xFFC084FC))

    // Paimon-style Floating Golden Halo Crown
    val crownY = cy - h * 0.17f
    drawOval(
      color = Color(0xFFF59E0B),
      topLeft = Offset(cx - w * 0.22f, crownY - h * 0.05f),
      size = Size(w * 0.44f, h * 0.10f),
      style = Stroke(width = 3.5f)
    )
    drawOval(
      color = Color(0xFFFEF08A),
      topLeft = Offset(cx - w * 0.20f, crownY - h * 0.045f),
      size = Size(w * 0.40f, h * 0.09f),
      style = Stroke(width = 1.8f)
    )

    // Crown Center Star Gem
    drawSparkle(cx, crownY - h * 0.05f, 6f, Color(0xFFFDE047))

    // Cute Mascot Silhouette (Head & Cheering Arms)
    drawOval(
      color = Color(0xFFFFFBEB),
      topLeft = Offset(cx - w * 0.17f, cy - h * 0.08f),
      size = Size(w * 0.34f, h * 0.22f)
    )
    // White hair bangs & side clips
    val hairPath = Path().apply {
      moveTo(cx - w * 0.17f, cy - h * 0.03f)
      cubicTo(cx - w * 0.12f, cy + h * 0.03f, cx - w * 0.05f, cy + h * 0.03f, cx, cy - h * 0.01f)
      cubicTo(cx + w * 0.05f, cy + h * 0.03f, cx + w * 0.12f, cy + h * 0.03f, cx + w * 0.17f, cy - h * 0.03f)
      lineTo(cx + w * 0.15f, cy - h * 0.09f)
      lineTo(cx - w * 0.15f, cy - h * 0.09f)
      close()
    }
    drawPath(hairPath, color = Color(0xFFFFFFFF))

    // Happy smiling face (two curved eyes & smile)
    drawArc(
      color = Color(0xFF475569),
      startAngle = 180f,
      sweepAngle = 180f,
      useCenter = false,
      topLeft = Offset(cx - w * 0.10f, cy + h * 0.01f),
      size = Size(w * 0.07f, h * 0.04f),
      style = Stroke(width = 2.2f)
    )
    drawArc(
      color = Color(0xFF475569),
      startAngle = 180f,
      sweepAngle = 180f,
      useCenter = false,
      topLeft = Offset(cx + w * 0.03f, cy + h * 0.01f),
      size = Size(w * 0.07f, h * 0.04f),
      style = Stroke(width = 2.2f)
    )
    // Cheerful blush dots
    drawCircle(Color(0xFFF43F5E).copy(alpha = 0.6f), radius = 3.5f, center = Offset(cx - w * 0.11f, cy + h * 0.05f))
    drawCircle(Color(0xFFF43F5E).copy(alpha = 0.6f), radius = 3.5f, center = Offset(cx + w * 0.11f, cy + h * 0.05f))

    // Open cheering arms
    val leftArm = Path().apply {
      moveTo(cx - w * 0.13f, cy + h * 0.06f)
      lineTo(cx - w * 0.28f, cy - h * 0.03f)
      lineTo(cx - w * 0.24f, cy + h * 0.02f)
      close()
    }
    drawPath(leftArm, color = Color(0xFFFFFBEB))

    val rightArm = Path().apply {
      moveTo(cx + w * 0.13f, cy + h * 0.06f)
      lineTo(cx + w * 0.28f, cy - h * 0.03f)
      lineTo(cx + w * 0.24f, cy + h * 0.02f)
      close()
    }
    drawPath(rightArm, color = Color(0xFFFFFBEB))
  }
}

/**
 * Lantern Atmosphere Primogem Graphic for Card 3:
 * Warm glowing lanterns drifting against night sky around a faceted Primogem.
 */
@Composable
private fun LanternPrimogemArt(
  themeColor: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height
    val cx = w / 2f
    val cy = h * 0.35f

    // Warm amber radial aura
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(
          Color(0x66F59E0B),
          Color(0x22B45309),
          Color.Transparent
        ),
        center = Offset(cx, cy),
        radius = w * 0.50f
      )
    )

    // City silhouette in warm twilight
    drawCitySilhouette(
      w = w,
      h = h,
      silhouetteColor = Color(0xFF1C0D05).copy(alpha = 0.75f),
      windowGlowColor = Color(0xFFFDE047)
    )

    // Floating golden lanterns in background
    drawLantern(cx - w * 0.30f, cy + h * 0.12f, 5.5f)
    drawLantern(cx + w * 0.30f, cy + h * 0.08f, 6.5f)
    drawLantern(cx - w * 0.24f, cy - h * 0.14f, 4f)
    drawLantern(cx + w * 0.26f, cy - h * 0.12f, 4.5f)

    // Draw the Primogem Crystal with golden lantern ambient sheen
    drawPrimogemCrystal(cx, cy, w * 0.50f, h * 0.44f, isWarmAmbient = true)
  }
}

/**
 * Helper to draw gothic architecture spires & arches silhouette
 */
private fun DrawScope.drawCitySilhouette(
  w: Float,
  h: Float,
  silhouetteColor: Color,
  windowGlowColor: Color,
) {
  val path = Path().apply {
    moveTo(0f, h)
    lineTo(0f, h * 0.48f)
    lineTo(w * 0.12f, h * 0.38f) // left turret
    lineTo(w * 0.15f, h * 0.48f)
    lineTo(w * 0.25f, h * 0.48f)
    // Left arch
    cubicTo(w * 0.28f, h * 0.40f, w * 0.38f, h * 0.40f, w * 0.42f, h * 0.48f)
    lineTo(w * 0.58f, h * 0.48f)
    // Right arch
    cubicTo(w * 0.62f, h * 0.40f, w * 0.72f, h * 0.40f, w * 0.75f, h * 0.48f)
    lineTo(w * 0.85f, h * 0.48f)
    lineTo(w * 0.88f, h * 0.34f) // right cathedral spire
    lineTo(w * 0.92f, h * 0.34f)
    lineTo(w * 0.96f, h * 0.46f)
    lineTo(w, h * 0.46f)
    lineTo(w, h)
    close()
  }
  drawPath(path, color = silhouetteColor)

  // Warm glowing lantern windows
  drawCircle(windowGlowColor, radius = 2.5f, center = Offset(w * 0.13f, h * 0.52f))
  drawCircle(windowGlowColor, radius = 3.0f, center = Offset(w * 0.86f, h * 0.50f))
  drawCircle(windowGlowColor.copy(alpha = 0.8f), radius = 2.0f, center = Offset(w * 0.50f, h * 0.54f))
}

/**
 * Helper to draw a glowing lantern dot
 */
private fun DrawScope.drawLantern(x: Float, y: Float, radius: Float) {
  drawCircle(
    brush = Brush.radialGradient(
      colors = listOf(Color(0xFFFEF08A), Color(0xFFF59E0B), Color.Transparent),
      center = Offset(x, y),
      radius = radius * 2.2f
    )
  )
  drawCircle(color = Color(0xFFFFFBEB), radius = radius * 0.6f, center = Offset(x, y))
}

/**
 * Helper to draw a 4-pointed sparkle star
 */
private fun DrawScope.drawSparkle(x: Float, y: Float, r: Float, color: Color) {
  val path = Path().apply {
    moveTo(x, y - r)
    cubicTo(x + r * 0.18f, y - r * 0.18f, x + r * 0.18f, y - r * 0.18f, x + r, y)
    cubicTo(x + r * 0.18f, y + r * 0.18f, x + r * 0.18f, y + r * 0.18f, x, y + r)
    cubicTo(x - r * 0.18f, y + r * 0.18f, x - r * 0.18f, y + r * 0.18f, x - r, y)
    cubicTo(x - r * 0.18f, y - r * 0.18f, x - r * 0.18f, y - r * 0.18f, x, y - r)
    close()
  }
  drawPath(path, color = color)
  drawCircle(color = Color.White, radius = r * 0.35f, center = Offset(x, y))
}

/**
 * Reusable helper to draw a 3D faceted Genshin Primogem star crystal.
 */
private fun DrawScope.drawPrimogemCrystal(
  cx: Float,
  cy: Float,
  w: Float,
  h: Float,
  isWarmAmbient: Boolean = false,
) {
  val halfW = w / 2f
  val halfH = h / 2f

  // 4 Main Peak coordinates of the Primogem
  val top = Offset(cx, cy - halfH)
  val bottom = Offset(cx, cy + halfH)
  val left = Offset(cx - halfW, cy)
  val right = Offset(cx + halfW, cy)
  val center = Offset(cx, cy)

  // Inner diamond vertices (facets step)
  val innerH = halfH * 0.30f
  val innerW = halfW * 0.30f
  val innerTop = Offset(cx, cy - innerH)
  val innerBottom = Offset(cx, cy + innerH)
  val innerLeft = Offset(cx - innerW, cy)
  val innerRight = Offset(cx + innerW, cy)

  // 1. Top-Left Facet
  val topLeftFacet = Path().apply {
    moveTo(top.x, top.y)
    lineTo(left.x, left.y)
    lineTo(innerLeft.x, innerLeft.y)
    lineTo(innerTop.x, innerTop.y)
    close()
  }
  drawPath(
    topLeftFacet,
    brush = Brush.linearGradient(
      listOf(
        if (isWarmAmbient) Color(0xFFBAE6FD) else Color(0xFF7DD3FC),
        Color(0xFF38BDF8)
      ),
      start = top,
      end = left
    )
  )

  // 2. Top-Right Facet
  val topRightFacet = Path().apply {
    moveTo(top.x, top.y)
    lineTo(right.x, right.y)
    lineTo(innerRight.x, innerRight.y)
    lineTo(innerTop.x, innerTop.y)
    close()
  }
  drawPath(
    topRightFacet,
    brush = Brush.linearGradient(
      listOf(
        Color(0xFF60A5FA),
        if (isWarmAmbient) Color(0xFFFBBF24) else Color(0xFF3B82F6)
      ),
      start = top,
      end = right
    )
  )

  // 3. Bottom-Left Facet
  val bottomLeftFacet = Path().apply {
    moveTo(bottom.x, bottom.y)
    lineTo(left.x, left.y)
    lineTo(innerLeft.x, innerLeft.y)
    lineTo(innerBottom.x, innerBottom.y)
    close()
  }
  drawPath(
    bottomLeftFacet,
    brush = Brush.linearGradient(
      listOf(Color(0xFF2563EB), Color(0xFF1D4ED8)),
      start = left,
      end = bottom
    )
  )

  // 4. Bottom-Right Facet
  val bottomRightFacet = Path().apply {
    moveTo(bottom.x, bottom.y)
    lineTo(right.x, right.y)
    lineTo(innerRight.x, innerRight.y)
    lineTo(innerBottom.x, innerBottom.y)
    close()
  }
  drawPath(
    bottomRightFacet,
    brush = Brush.linearGradient(
      listOf(
        Color(0xFF7C3AED),
        if (isWarmAmbient) Color(0xFFD97706) else Color(0xFF4F46E5)
      ),
      start = right,
      end = bottom
    )
  )

  // 5. Central Facet Diamond
  val centerDiamond = Path().apply {
    moveTo(innerTop.x, innerTop.y)
    lineTo(innerRight.x, innerRight.y)
    lineTo(innerBottom.x, innerBottom.y)
    lineTo(innerLeft.x, innerLeft.y)
    close()
  }
  drawPath(
    centerDiamond,
    brush = Brush.radialGradient(
      colors = listOf(Color.White, Color(0xFFE0F2FE), Color(0xFF38BDF8)),
      center = center,
      radius = innerW * 1.2f
    )
  )

  // Facet crisp ridge lines
  val strokeColor = Color.White.copy(alpha = 0.75f)
  drawLine(strokeColor, top, innerTop, strokeWidth = 1.2f)
  drawLine(strokeColor, bottom, innerBottom, strokeWidth = 1.2f)
  drawLine(strokeColor, left, innerLeft, strokeWidth = 1.2f)
  drawLine(strokeColor, right, innerRight, strokeWidth = 1.2f)
  drawPath(centerDiamond, color = strokeColor, style = Stroke(width = 1.2f))

  // Center specular highlight sparkle
  drawSparkle(cx, cy, innerW * 0.7f, Color.White)
}

/**
 * Genshin Crest / Star Watermark for card backgrounds and sheet header watermark.
 */
@Composable
private fun GenshinCrestWatermark(
  size: Dp,
  color: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f
    val cy = h / 2f

    // Outer thin circular ring
    drawCircle(
      color = color,
      radius = w * 0.42f,
      center = Offset(cx, cy),
      style = Stroke(width = 1.2f)
    )

    // 4 Cardinal Curved Spikes
    val cardinalPath = Path().apply {
      moveTo(cx, cy - h * 0.48f)
      cubicTo(cx + w * 0.08f, cy - h * 0.12f, cx + w * 0.12f, cy - h * 0.08f, cx + w * 0.48f, cy)
      cubicTo(cx + w * 0.12f, cy + h * 0.08f, cx + w * 0.08f, cy + h * 0.12f, cx, cy + h * 0.48f)
      cubicTo(cx - w * 0.08f, cy + h * 0.12f, cx - w * 0.12f, cy + h * 0.08f, cx - w * 0.48f, cy)
      cubicTo(cx - w * 0.12f, cy - h * 0.08f, cx - w * 0.08f, cy - h * 0.12f, cx, cy - h * 0.48f)
      close()
    }
    drawPath(cardinalPath, color = color, style = Stroke(width = 1.5f))

    // Inner Diamond
    val diamondPath = Path().apply {
      val d = w * 0.12f
      moveTo(cx, cy - d)
      lineTo(cx + d, cy)
      lineTo(cx, cy + d)
      lineTo(cx - d, cy)
      close()
    }
    drawPath(diamondPath, color = color)
  }
}

private data class Tuple6<A, B, C, D, E, F>(
  val a: A,
  val b: B,
  val c: C,
  val d: D,
  val e: E,
  val f: F,
)
