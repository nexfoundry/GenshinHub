package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Article
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.BackgroundNavy
import com.example.ui.theme.StarGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Themed Genshin dialog shown when clicking menu destinations that are placeholders.
 */
@Composable
fun GenshinFeaturePlaceholderDialog(
  featureName: String,
  onDismiss: () -> Unit
) {
  val (icon, subtitle, description) = when (featureName) {
    "Wish Simulator" -> Triple(
      Icons.Rounded.AutoAwesome,
      "Genshin Wish & Gacha Simulator",
      "Simulate character event wishes, pity progression, 50/50 guarantees, and weapon banner paths with accurate drop rates."
    )
    "Calculator" -> Triple(
      Icons.Rounded.Calculate,
      "Teyvat Resource & Damage Calculator",
      "Plan talent level-ups, character ascension materials, artifact damage scalings, and weapon enhancement schedules."
    )
    "News & Events" -> Triple(
      Icons.Rounded.Article,
      "Official Events & Version Notices",
      "Catch up on current limited-time events, special program livestreams, web events, and upcoming Primogem reward schedules."
    )
    "Guides" -> Triple(
      Icons.Rounded.MenuBook,
      "Traveler's Strategy Guides",
      "In-depth Spiral Abyss floor analyses, boss attack patterns, exploration routes, and team rotation breakdowns."
    )
    "Interactive Map" -> Triple(
      Icons.Rounded.LocationOn,
      "Teyvat Interactive Map Companion",
      "Pinpoint Anemoculus, Geoculus, Dendroculus, Hydroculus, Pyroculus, exquisite chests, and regional specialty farming routes."
    )
    "Settings" -> Triple(
      Icons.Rounded.Settings,
      "Preferences & Configuration",
      "Customize audio haptics, theme brightness, cached database synchronization, and local notification alerts."
    )
    "About" -> Triple(
      Icons.Rounded.Info,
      "About Genshin HUB",
      "A dedicated fan-crafted companion app for Travelers exploring Teyvat. Built with Jetpack Compose & Material 3."
    )
    else -> Triple(
      Icons.Rounded.AutoAwesome,
      "Companion Destination",
      "This module is currently being calibrated for the next version update."
    )
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.88f)
        .clip(RoundedCornerShape(22.dp))
        .border(
          width = 1.dp,
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0x80818CF8),
              Color(0x333B82F6),
              Color(0x6660A5FA)
            )
          ),
          shape = RoundedCornerShape(22.dp)
        ),
      color = Color(0xFF0C1024),
      shadowElevation = 24.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color(0xFF101530),
                Color(0xFF0A0E22)
              )
            )
          )
          .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Top row with close button
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Badge
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0x2E6366F1))
              .border(1.dp, Color(0x66818CF8), RoundedCornerShape(8.dp))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = "COMING SOON",
              color = StarGold,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(28.dp)
          ) {
            Icon(
              imageVector = Icons.Rounded.Close,
              contentDescription = "Close Dialog",
              tint = TextSecondary,
              modifier = Modifier.size(18.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Feature Icon in circular illuminated container
        Box(
          modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(
              Brush.radialGradient(
                colors = listOf(
                  Color(0x4D38BDF8),
                  Color(0x266366F1),
                  Color.Transparent
                )
              )
            )
            .border(1.dp, Color(0x66818CF8), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = featureName,
            tint = Color(0xFFE0F2FE),
            modifier = Modifier.size(30.dp)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Feature Title
        Text(
          text = featureName,
          color = TextPrimary,
          fontSize = 19.sp,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Subtitle
        Text(
          text = subtitle,
          color = StarGold.copy(alpha = 0.9f),
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Description
        Text(
          text = description,
          color = TextSecondary,
          fontSize = 13.sp,
          lineHeight = 18.sp,
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Dismiss Button
        ElevatedButton(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.elevatedButtonColors(
            containerColor = Color(0xFF4F46E5),
            contentColor = Color.White
          )
        ) {
          Text(
            text = "Back to Exploration",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }
  }
}
