package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Character
import com.example.ui.theme.CardBorderNavy
import com.example.ui.theme.CardNavy
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.StarGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.rememberSubtleHaptics

@Composable
fun CharacterDetailDialog(
  character: Character,
  onDismiss: () -> Unit,
  onFavoriteToggle: (Character) -> Unit,
  onAddToTeam: (Character) -> Unit,
  modifier: Modifier = Modifier,
) {
  val subtleHaptics = rememberSubtleHaptics()
  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(22.dp))
        .shadow(20.dp, spotColor = character.element.color)
        .testTag("dialog_char_detail"),
      shape = RoundedCornerShape(22.dp),
      border = BorderStroke(1.2.dp, character.element.color.copy(alpha = 0.5f)),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1124))
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        // Hero Header with Portrait
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
        ) {
          CharacterPortraitArt(
            character = character,
            modifier = Modifier.fillMaxWidth()
          )

          // Top action buttons
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            ElementBadge(element = character.element, size = 28.dp)

            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = {
                  subtleHaptics.performToggle()
                  onFavoriteToggle(character)
                },
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color(0x66070B18))
                  .testTag("dialog_fav_btn")
              ) {
                Icon(
                  imageVector = if (character.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                  contentDescription = "Favorite",
                  tint = if (character.isFavorite) Color(0xFFF43F5E) else Color.White,
                  modifier = Modifier.size(18.dp)
                )
              }

              Spacer(modifier = Modifier.width(8.dp))

              IconButton(
                onClick = onDismiss,
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color(0x66070B18))
                  .testTag("dialog_close_btn")
              ) {
                Icon(
                  imageVector = Icons.Default.Close,
                  contentDescription = "Close",
                  tint = Color.White,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }

          // Bottom name tag on portrait
          Column(
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(start = 16.dp, bottom = 10.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              repeat(character.rarity) {
                Icon(
                  imageVector = Icons.Filled.Star,
                  contentDescription = null,
                  tint = StarGold,
                  modifier = Modifier.size(12.dp)
                )
              }
            }
            Text(
              text = character.name,
              color = TextPrimary,
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = character.title,
              color = PurpleLight,
              fontSize = 12.sp
            )
          }
        }

        // Body Content
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          // Meta pills: Vision, Weapon, Role
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            MetaChip(label = character.element.displayName, color = character.element.color)
            MetaChip(label = character.weapon.displayName, color = Color(0xFFA5B4FC))
            MetaChip(label = character.role, color = Color(0xFFFBBF24))
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Lore / Description
          Text(
            text = character.description,
            color = TextSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Stats Grid
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            StatBox(title = "BASE HP", value = "${character.baseHp}", modifier = Modifier.weight(1f))
            Spacer(modifier = Modifier.width(8.dp))
            StatBox(title = "BASE ATK", value = "${character.baseAtk}", modifier = Modifier.weight(1f))
            Spacer(modifier = Modifier.width(8.dp))
            StatBox(title = "CONSTELLATION", value = character.constellation, modifier = Modifier.weight(1.3f))
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Action Button: Add to Team
          Button(
            onClick = {
              subtleHaptics.performPartyAdd()
              onAddToTeam(character)
              onDismiss()
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = PurplePrimary,
              contentColor = Color.White
            ),
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("dialog_btn_add_team")
          ) {
            Text(
              text = "Add to Party Lineup",
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}

@Composable
private fun MetaChip(label: String, color: Color) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = color.copy(alpha = 0.15f),
    border = BorderStroke(1.dp, color.copy(alpha = 0.4f))
  ) {
    Text(
      text = label,
      color = color,
      fontSize = 11.sp,
      fontWeight = FontWeight.Medium,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
    )
  }
}

@Composable
private fun StatBox(title: String, value: String, modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(10.dp))
      .background(Color(0xFF131934))
      .border(1.dp, Color(0xFF1E2850), RoundedCornerShape(10.dp))
      .padding(horizontal = 8.dp, vertical = 6.dp)
  ) {
    Column {
      Text(
        text = title,
        color = TextMuted,
        fontSize = 8.5.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        color = TextPrimary,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1
      )
    }
  }
}
