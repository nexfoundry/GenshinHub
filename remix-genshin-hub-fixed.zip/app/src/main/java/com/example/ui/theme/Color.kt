package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Fantasy Navy Canvas & Surfaces
val BackgroundNavy = Color(0xFF040714)
val SurfaceNavy = Color(0xFF0A0F24)
val CardNavy = Color(0xFF0A1028)
val CardBorderNavy = Color(0xFF1B2446)
val CardGlowBorder = Color(0xFF382F66)

// Purple Brand Accents
val PurplePrimary = Color(0xFFA855F7)
val PurpleSecondary = Color(0xFF7C3AED)
val PurpleLight = Color(0xFFC084FC)
val PurpleDark = Color(0xFF4C1D95)
val PurpleContainer = Color(0xFF241647)
val PurpleGlow = Color(0x66A855F7)

// Elemental Vision Palettes (Exact colors from uploaded reference)
val ElementPyro = Color(0xFFFF5B35)
val ElementPyroGlow = Color(0x66FF5B35)

val ElementHydro = Color(0xFF22BAFF)
val ElementHydroGlow = Color(0x6622BAFF)

val ElementAnemo = Color(0xFF42D8A6)
val ElementAnemoGlow = Color(0x6642D8A6)

val ElementElectro = Color(0xFFBD75F0)
val ElementElectroGlow = Color(0x66BD75F0)

val ElementDendro = Color(0xFFA0D91E)
val ElementDendroGlow = Color(0x66A0D91E)

val ElementCryo = Color(0xFF86E3F6)
val ElementCryoGlow = Color(0x6686E3F6)

val ElementGeo = Color(0xFFEBA51F)
val ElementGeoGlow = Color(0x66EBA51F)

// Star Rarity
val StarGold = Color(0xFFFBBF24)
val StarGoldGlow = Color(0x66FBBF24)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextMuted = Color(0xFF475569)

// UI Chrome
val ChipBackground = Color(0xFF0A1028)
val ChipBorder = Color(0xFF1B2446)
val SearchBarBackground = Color(0xFF080D22)
val SearchBarBorder = Color(0xFF1B2446)
val BottomNavBackground = Color(0xFF060A1A)
val BottomNavBorder = Color(0xFF1B2446)
