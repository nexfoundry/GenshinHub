package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.repository.CharacterRepository
import com.example.model.Character
import com.example.model.SampleCharacters
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class GenshinHubViewModel(application: Application) : AndroidViewModel(application) {
  private val repository: CharacterRepository

  private val _characters = MutableStateFlow<List<Character>>(emptyList())
  val characters: StateFlow<List<Character>> = _characters.asStateFlow()

  private val _isLoading = MutableStateFlow(true)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  private val _isRefreshing = MutableStateFlow(false)
  val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

  private val _activeParty = MutableStateFlow<List<Character>>(
    // Pre-populate with 2 default favorite characters for immediate usability
    SampleCharacters.list.take(2)
  )
  val activeParty: StateFlow<List<Character>> = _activeParty.asStateFlow()

  fun addToParty(character: Character): Boolean {
    val current = _activeParty.value
    if (current.any { it.id == character.id }) {
      return false
    }
    if (current.size < 4) {
      _activeParty.value = current + character
    } else {
      _activeParty.value = current.take(3) + character
    }
    return true
  }

  fun removeFromParty(characterId: String) {
    _activeParty.value = _activeParty.value.filterNot { it.id == characterId }
  }

  fun clearParty() {
    _activeParty.value = emptyList()
  }

  init {
    val database = AppDatabase.getDatabase(application)
    repository = CharacterRepository(database.characterDao())

    viewModelScope.launch {
      _isLoading.value = true
      try {
        // Seed if empty and listen to database changes
        repository.initializeIfEmpty()
        // Provide subtle delay for smooth initial entrance
        delay(350)
        repository.charactersFlow.collect { dbCharacters ->
          if (dbCharacters.isNotEmpty()) {
            _characters.value = dbCharacters
          } else {
            _characters.value = SampleCharacters.list
          }
          _isLoading.value = false
        }
      } catch (_: Exception) {
        _characters.value = SampleCharacters.list
        _isLoading.value = false
      }
    }
  }

  fun refresh() {
    viewModelScope.launch {
      _isRefreshing.value = true
      try {
        // Re-fetch character data directly from the Room database
        val dbData = repository.refetchFromDatabase()
        // Provide tactile duration for smooth pull-to-refresh animation
        delay(650)
        if (dbData.isNotEmpty()) {
          _characters.value = dbData
        }
      } finally {
        _isRefreshing.value = false
      }
    }
  }

  fun toggleFavorite(character: Character) {
    viewModelScope.launch {
      repository.toggleFavorite(character.id, character.isFavorite)
    }
  }
}
