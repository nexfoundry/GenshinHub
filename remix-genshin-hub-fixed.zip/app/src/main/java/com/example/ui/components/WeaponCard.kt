package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Weapon
import com.example.ui.theme.CardBorderNavy
import com.example.ui.theme.CardNavy
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.rememberSubtleHaptics

@Composable
fun WeaponCard(
  weapon: Weapon,
  onClick: (Weapon) -> Unit,
  modifier: Modifier = Modifier,
) {
  val subtleHaptics = rememberSubtleHaptics()
  val isFiveStar = weapon.rarity == 5
  val rarityColor = if (isFiveStar) Color(0xFFFBBF24) else Color(0xFFA855F7)
  val rarityBorder = if (isFiveStar) Color(0x66FBBF24) else Color(0x66A855F7)
  val rarityGlow = if (isFiveStar) Color(0x1AFBBF24) else Color(0x1AA855F7)

  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .clickable {
        subtleHaptics.performCardTap()
        onClick(weapon)
      }
      .testTag("weapon_card_${weapon.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = CardNavy),
    border = BorderStroke(1.dp, rarityBorder)
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.verticalGradient(
            listOf(rarityGlow, Color.Transparent)
          )
        )
        .padding(12.dp)
    ) {
      Column {
        // Top header: Type badge and Rarity Stars
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF0F1528),
            border = BorderStroke(1.dp, Color(0xFF253050))
          ) {
            Text(
              text = weapon.type.displayName,
              color = Color(0xFFC4D1EA),
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            repeat(weapon.rarity) {
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = rarityColor,
                modifier = Modifier.size(13.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Weapon Name
        Text(
          text = weapon.name,
          color = TextPrimary,
          fontSize = 14.5.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Stats Row: Base ATK + Sub-Stat
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          // Base ATK
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF161E38),
            modifier = Modifier.weight(1f)
          ) {
            Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
              Text(text = "Base ATK", color = TextMuted, fontSize = 9.5.sp)
              Text(
                text = "${weapon.baseAtk}",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          // Sub-Stat
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF161E38),
            modifier = Modifier.weight(1f)
          ) {
            Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
              Text(
                text = weapon.subStatName,
                color = TextMuted,
                fontSize = 9.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              Text(
                text = weapon.subStatValue,
                color = rarityColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Passive skill preview
        Text(
          text = weapon.passiveName,
          color = Color(0xFFE2E8F0),
          fontSize = 11.5.sp,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = weapon.passiveDesc,
          color = TextSecondary,
          fontSize = 10.5.sp,
          lineHeight = 14.sp,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}
