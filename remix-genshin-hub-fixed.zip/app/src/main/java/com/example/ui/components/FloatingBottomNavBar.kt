package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.util.rememberSubtleHaptics

// ---------- Data model ----------
data class NavItem(
    @DrawableRes val iconRes: Int,
    val label: String
)

val navItems = listOf(
    NavItem(R.drawable.character, "Characters"),
    NavItem(R.drawable.weapon, "Weapons"),
    NavItem(R.drawable.artifact, "Artifacts"),
    NavItem(R.drawable.teams, "Teams"),
    NavItem(R.drawable.tierlist, "Tier List")
)

// Purple gradient: #8E2DE2 to #6A11CB at 135 degrees
private val purpleGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF8E2DE2), Color(0xFF6A11CB)),
    start = Offset(0f, 0f),
    end = Offset.Infinite
)

// ---------- Bottom Nav Bar ----------
@Composable
fun FloatingBottomNavBar(
    selectedIndex: Int,
    onItemSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 8.dp)
            .height(68.dp)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(34.dp),
                spotColor = Color(0x66000000),
                ambientColor = Color(0x66000000)
            )
            .clip(RoundedCornerShape(34.dp))
            .background(Color(0xFF12141C))
            .border(
                width = 1.dp,
                color = Color(0x1AFFFFFF),
                shape = RoundedCornerShape(34.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        // Inner capsule row (height: 56.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEachIndexed { index, item ->
                val isSelected = index == selectedIndex

                NavBarItem(
                    item = item,
                    isSelected = isSelected,
                    onClick = { onItemSelected(index) }
                )
            }
        }
    }
}

@Composable
private fun RowScope.NavBarItem(
    item: NavItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val subtleHaptics = rememberSubtleHaptics()
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // 1. Tactile press animation: instantaneous physical compression on touch
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "item_press_scale_${item.label}"
    )

    // 2. Responsive, organic spring animation for active capsule width expansion
    val flexGrow by animateFloatAsState(
        targetValue = if (isSelected) 2.4f else 1.0f,
        animationSpec = spring(
            dampingRatio = 0.78f,
            stiffness = 420f
        ),
        label = "item_weight_${item.label}"
    )

    // 3. Background gradient alpha transition
    val bgAlpha by animateFloatAsState(
        targetValue = if (isSelected) 1f else 0f,
        animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing),
        label = "item_bg_alpha_${item.label}"
    )

    // 4. Luminous glow elevation when selected
    val activeGlowElevation by animateDpAsState(
        targetValue = if (isSelected) 8.dp else 0.dp,
        animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing),
        label = "item_glow_${item.label}"
    )

    // 5. Dynamic icon scale and alpha for subtle bounce
    val iconScale by animateFloatAsState(
        targetValue = if (isSelected) 1.08f else 0.94f,
        animationSpec = spring(
            dampingRatio = 0.72f,
            stiffness = 420f
        ),
        label = "item_icon_scale_${item.label}"
    )

    val iconAlpha by animateFloatAsState(
        targetValue = if (isSelected) 1.0f else 0.70f,
        animationSpec = tween(durationMillis = 150, easing = FastOutSlowInEasing),
        label = "item_icon_alpha_${item.label}"
    )

    Box(
        modifier = Modifier
            .weight(flexGrow, fill = true)
            .height(56.dp)
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .shadow(
                elevation = activeGlowElevation,
                shape = RoundedCornerShape(28.dp),
                spotColor = Color(0x998E2DE2),
                ambientColor = Color(0x446A11CB)
            )
            .clip(RoundedCornerShape(28.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = Color.White.copy(alpha = 0.25f)),
                onClick = {
                    subtleHaptics.performTabSelect()
                    onClick()
                }
            )
            .testTag("nav_tab_${item.label.lowercase().replace(" ", "_")}"),
        contentAlignment = Alignment.Center
    ) {
        // Purple gradient background capsule (#8E2DE2 to #6A11CB, 135deg)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = bgAlpha }
                .background(purpleGradient, RoundedCornerShape(28.dp))
        )

        Row(
            modifier = Modifier.padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = item.iconRes),
                contentDescription = item.label,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(28.dp)
                    .graphicsLayer {
                        scaleX = iconScale
                        scaleY = iconScale
                        alpha = iconAlpha
                    }
                    .testTag("nav_icon_${item.label.lowercase().replace(" ", "_")}")
            )

            // Responsive, fluid animated visibility for label with spring expansion
            AnimatedVisibility(
                visible = isSelected,
                enter = expandHorizontally(
                    animationSpec = spring(
                        dampingRatio = 0.80f,
                        stiffness = 420f
                    ),
                    expandFrom = Alignment.Start
                ) + fadeIn(
                    animationSpec = tween(durationMillis = 150, easing = LinearOutSlowInEasing)
                ),
                exit = shrinkHorizontally(
                    animationSpec = tween(durationMillis = 120, easing = FastOutSlowInEasing),
                    shrinkTowards = Alignment.Start
                ) + fadeOut(
                    animationSpec = tween(durationMillis = 80)
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.label,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}

// ---------- Preview Usage ----------
@Composable
fun BottomNavBarPreviewUsage() {
    var selected by remember { mutableStateOf(0) }

    FloatingBottomNavBar(
        selectedIndex = selected,
        onItemSelected = { selected = it }
    )
}
