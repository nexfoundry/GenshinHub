package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Character
import com.example.ui.theme.CardBorderNavy
import com.example.ui.theme.CardNavy
import com.example.ui.theme.StarGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.rememberSubtleHaptics

@Composable
fun CharacterGridCard(
  character: Character,
  onCharacterClick: (Character) -> Unit,
  onFavoriteToggle: (Character) -> Unit,
  modifier: Modifier = Modifier,
) {
  val subtleHaptics = rememberSubtleHaptics()
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val isHovered by interactionSource.collectIsHoveredAsState()

  // Press & hover feedback scale animation
  val targetScale = when {
    isPressed -> 0.95f
    isHovered -> 1.04f
    else -> 1.0f
  }
  val cardScale by animateFloatAsState(
    targetValue = targetScale,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessLow
    ),
    label = "grid_card_scale"
  )

  // Dynamic border highlight on hover
  val borderAlpha by animateFloatAsState(
    targetValue = if (isHovered) 0.85f else 0.35f,
    animationSpec = spring(stiffness = Spring.StiffnessLow),
    label = "grid_card_border"
  )

  // Dynamic shadow elevation on hover
  val shadowElevation by animateDpAsState(
    targetValue = if (isHovered) 12.dp else 6.dp,
    animationSpec = spring(stiffness = Spring.StiffnessLow),
    label = "grid_card_shadow"
  )

  Card(
    modifier = modifier
      .fillMaxWidth()
      .aspectRatio(0.65f)
      .hoverable(interactionSource = interactionSource)
      .scale(cardScale)
      .shadow(shadowElevation, RoundedCornerShape(12.dp), spotColor = character.element.glowColor)
      .clip(RoundedCornerShape(12.dp))
      .clickable(
        interactionSource = interactionSource,
        indication = null
      ) {
        subtleHaptics.performCardTap()
        onCharacterClick(character)
      }
      .testTag("char_card_${character.id}"),
    shape = RoundedCornerShape(12.dp),
    border = BorderStroke(1.dp, character.element.color.copy(alpha = borderAlpha)),
    colors = CardDefaults.cardColors(containerColor = CardNavy),
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      // Character Anime Artwork (full bleed)
      CharacterPortraitArt(
        character = character,
        modifier = Modifier.fillMaxSize()
      )

      // Dark gradient overlay at the bottom for readability of name, rarity, and weapon
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(92.dp)
          .align(Alignment.BottomCenter)
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color.Transparent,
                Color(0x70050816),
                Color(0xDC050816),
                Color(0xFF050816)
              )
            )
          )
      )

      // Top Badges Row: Element on left, Favorite Heart on right
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Element Badge
        ElementBadge(
          element = character.element,
          size = 22.dp,
          modifier = Modifier.testTag("element_badge_${character.id}")
        )

        // Heart Favorite Toggle
        val heartColor by animateColorAsState(
          targetValue = if (character.isFavorite) Color(0xFFF43F5E) else Color(0xCCFFFFFF),
          label = "heart_color"
        )
        val heartScale by animateFloatAsState(
          targetValue = if (character.isFavorite) 1.25f else 1.0f,
          animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
          ),
          label = "heart_scale"
        )

        Box(
          modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(Color(0x66070B1A))
            .clickable {
              subtleHaptics.performToggle()
              onFavoriteToggle(character)
            }
            .testTag("fav_btn_${character.id}"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (character.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            contentDescription = "Favorite",
            tint = heartColor,
            modifier = Modifier
              .size(13.dp)
              .scale(heartScale)
          )
        }
      }

      // Bottom Character Details (5 Stars, Name, Weapon)
      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .fillMaxWidth()
          .padding(horizontal = 7.dp, vertical = 7.dp)
      ) {
        // 5-Star Rarity Indicator
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(bottom = 2.dp)
        ) {
          repeat(character.rarity) {
            Icon(
              imageVector = Icons.Filled.Star,
              contentDescription = null,
              tint = StarGold,
              modifier = Modifier.size(9.dp)
            )
          }
        }

        // Character Name
        Text(
          text = character.name,
          color = TextPrimary,
          fontSize = 12.5.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(2.dp))

        // Weapon Type
        Row(
          verticalAlignment = Alignment.CenterVertically
        ) {
          WeaponIcon(
            weapon = character.weapon,
            color = TextSecondary,
            size = 10.dp
          )
          Spacer(modifier = Modifier.width(3.dp))
          Text(
            text = character.weapon.displayName,
            color = TextSecondary,
            fontSize = 9.5.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }
    }
  }
}

@Composable
fun CharacterListCard(
  character: Character,
  onCharacterClick: (Character) -> Unit,
  onFavoriteToggle: (Character) -> Unit,
  modifier: Modifier = Modifier,
) {
  val subtleHaptics = rememberSubtleHaptics()
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()

  // Press feedback bounce animation
  val cardScale by animateFloatAsState(
    targetValue = if (isPressed) 0.97f else 1.0f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessLow
    ),
    label = "list_card_scale"
  )

  Card(
    modifier = modifier
      .fillMaxWidth()
      .height(84.dp)
      .scale(cardScale)
      .clip(RoundedCornerShape(14.dp))
      .clickable(
        interactionSource = interactionSource,
        indication = null
      ) {
        subtleHaptics.performCardTap()
        onCharacterClick(character)
      }
      .testTag("char_list_card_${character.id}"),
    shape = RoundedCornerShape(14.dp),
    border = BorderStroke(1.dp, character.element.color.copy(alpha = 0.3f)),
    colors = CardDefaults.cardColors(containerColor = CardNavy),
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Portrait Thumbnail
      Box(
        modifier = Modifier
          .size(68.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(Color(0xFF131A36))
      ) {
        CharacterPortraitArt(
          character = character,
          modifier = Modifier.fillMaxSize()
        )
        ElementBadge(
          element = character.element,
          size = 18.dp,
          modifier = Modifier
            .padding(4.dp)
            .align(Alignment.TopStart)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      // Character Meta
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.Center
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = character.name,
            color = TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.width(6.dp))
          Row {
            repeat(character.rarity) {
              Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = null,
                tint = StarGold,
                modifier = Modifier.size(9.dp)
              )
            }
          }
        }

        Text(
          text = character.title,
          color = TextSecondary,
          fontSize = 11.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(3.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          WeaponIcon(
            weapon = character.weapon,
            color = character.element.color,
            size = 11.dp
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "${character.weapon.displayName} • ${character.role}",
            color = TextSecondary,
            fontSize = 10.5.sp
          )
        }
      }

      // Favorite toggle with animated heart pop
      val heartScale by animateFloatAsState(
        targetValue = if (character.isFavorite) 1.25f else 1.0f,
        animationSpec = spring(
          dampingRatio = Spring.DampingRatioHighBouncy,
          stiffness = Spring.StiffnessMedium
        ),
        label = "list_heart_scale"
      )

      IconButton(
        onClick = {
          subtleHaptics.performToggle()
          onFavoriteToggle(character)
        },
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = if (character.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
          contentDescription = "Favorite",
          tint = if (character.isFavorite) Color(0xFFF43F5E) else TextSecondary,
          modifier = Modifier
            .size(18.dp)
            .scale(heartScale)
        )
      }
    }
  }
}
