package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.Character
import com.example.ui.theme.CardNavy
import com.example.ui.theme.TextMuted

fun getCharacterArtworkRes(characterId: String): Int? = when (characterId) {
  "ineffa" -> R.drawable.card_ineffa
  "flins" -> R.drawable.card_flins
  "alyosha" -> R.drawable.card_alyosha
  "varka" -> R.drawable.card_varka
  "columbina" -> R.drawable.card_columbina
  "durin" -> R.drawable.card_durin
  "nefer" -> R.drawable.card_nefer
  "jahoda" -> R.drawable.card_jahoda
  "lan" -> R.drawable.card_lan
  "guizhong" -> R.drawable.card_guizhong
  "lyra" -> R.drawable.card_lyra
  "kael" -> R.drawable.card_kael
  "althea" -> R.drawable.card_althea
  "moraxus" -> R.drawable.card_moraxus
  else -> null
}

@Composable
fun CharacterPortraitArt(
  character: Character,
  modifier: Modifier = Modifier,
) {
  val artworkRes = getCharacterArtworkRes(character.id)
  Box(modifier = modifier) {
    if (artworkRes != null) {
      AsyncImage(
        model = artworkRes,
        contentDescription = character.name,
        placeholder = ColorPainter(CardNavy),
        error = ColorPainter(CardNavy),
        contentScale = ContentScale.Crop,
        modifier = Modifier
          .fillMaxSize()
          .background(CardNavy)
      )
    } else {
      // Clean missing-asset state as requested: no AI placeholder or substituted art
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(CardNavy),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "No Image",
          color = TextMuted,
          fontSize = 11.sp
        )
      }
    }
  }
}
