package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.layout.wrapContentWidth
import com.example.util.rememberSubtleHaptics
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.ripple
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ElementType
import com.example.ui.theme.BackgroundNavy
import com.example.ui.theme.BottomNavBackground
import com.example.ui.theme.BottomNavBorder
import com.example.ui.theme.ChipBackground
import com.example.ui.theme.ChipBorder
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SearchBarBackground
import com.example.ui.theme.SearchBarBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

// -------------------------------------------------------------
// 1. GENSHIN HUB STAR LOGO EMBLEM
// -------------------------------------------------------------
@Composable
fun GenshinStarLogo(
  modifier: Modifier = Modifier,
  size: Dp = 32.dp,
) {
  androidx.compose.foundation.Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f
    val cy = h / 2f

    // Soft radiant violet aura
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(
          Color(0x88A855F7),
          Color(0x337C3AED),
          Color.Transparent
        ),
        center = Offset(cx, cy),
        radius = w * 0.75f
      )
    )

    // 4 Cardinal Sharp Points (North, South, East, West)
    val cardinalPath = androidx.compose.ui.graphics.Path().apply {
      moveTo(cx, cy - h * 0.50f)
      cubicTo(cx + w * 0.07f, cy - h * 0.12f, cx + w * 0.12f, cy - h * 0.07f, cx + w * 0.50f, cy)
      cubicTo(cx + w * 0.12f, cy + h * 0.07f, cx + w * 0.07f, cy + h * 0.12f, cx, cy + h * 0.50f)
      cubicTo(cx - w * 0.07f, cy + h * 0.12f, cx - w * 0.12f, cy + h * 0.07f, cx - w * 0.50f, cy)
      cubicTo(cx - w * 0.12f, cy - h * 0.07f, cx - w * 0.07f, cy - h * 0.12f, cx, cy - h * 0.50f)
      close()
    }
    drawPath(
      cardinalPath,
      brush = Brush.radialGradient(
        colors = listOf(Color.White, Color(0xFFE9D5FF), Color(0xFFA855F7)),
        center = Offset(cx, cy),
        radius = w * 0.48f
      )
    )

    // 4 Diagonal Points (NE, SE, SW, NW)
    val diagonalPath = androidx.compose.ui.graphics.Path().apply {
      val dLen = w * 0.28f
      val dWidth = w * 0.06f
      moveTo(cx + dLen, cy - dLen)
      lineTo(cx + dWidth, cy)
      lineTo(cx + dLen, cy + dLen)
      lineTo(cx, cy + dWidth)
      lineTo(cx - dLen, cy + dLen)
      lineTo(cx - dWidth, cy)
      lineTo(cx - dLen, cy - dLen)
      lineTo(cx, cy - dWidth)
      close()
    }
    drawPath(diagonalPath, color = Color(0xFFF3E8FF))

    // Bright Center Diamond
    val centerDiamond = androidx.compose.ui.graphics.Path().apply {
      val c = w * 0.11f
      moveTo(cx, cy - c)
      lineTo(cx + c, cy)
      lineTo(cx, cy + c)
      lineTo(cx - c, cy)
      close()
    }
    drawPath(centerDiamond, color = Color.White)
  }
}

// -------------------------------------------------------------
// 2. PAGODA & PURPLE NEBULA CELESTIAL ARTWORK
// -------------------------------------------------------------
@Composable
fun PagodaNebulaArtwork(
  modifier: Modifier = Modifier,
) {
  androidx.compose.foundation.Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    val cx = w * 0.38f
    val cy = h * 0.48f

    // Luminous purple celestial radial glow / nebula
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(
          Color(0x997C3AED), // vibrant violet core
          Color(0x664C1D95),
          Color(0x221E1B4B),
          Color.Transparent
        ),
        center = Offset(cx, cy),
        radius = w * 0.55f
      )
    )

    // Mountain crags & mist in foreground under pagoda
    val mountainPath = androidx.compose.ui.graphics.Path().apply {
      moveTo(0f, h)
      cubicTo(w * 0.15f, h * 0.88f, w * 0.25f, h * 0.82f, cx, h * 0.84f)
      cubicTo(w * 0.52f, h * 0.86f, w * 0.70f, h * 0.80f, w, h * 0.92f)
      lineTo(w, h)
      close()
    }
    drawPath(mountainPath, color = Color(0xFF060A1A))

    val roofColor = Color(0xFF0A0F26)
    val bodyColor = Color(0xFF090E22)

    // Pagoda Spire
    drawLine(
      color = Color(0xFFC084FC),
      start = Offset(cx, cy - h * 0.38f),
      end = Offset(cx, cy - h * 0.18f),
      strokeWidth = 1.6.dp.toPx()
    )
    drawCircle(
      color = Color(0xFFE9D5FF),
      radius = 1.5.dp.toPx(),
      center = Offset(cx, cy - h * 0.38f)
    )

    // Tier 1 Roof
    val tier1Roof = androidx.compose.ui.graphics.Path().apply {
      moveTo(cx, cy - h * 0.18f)
      cubicTo(cx - w * 0.08f, cy - h * 0.15f, cx - w * 0.14f, cy - h * 0.14f, cx - w * 0.16f, cy - h * 0.12f)
      lineTo(cx - w * 0.12f, cy - h * 0.09f)
      lineTo(cx + w * 0.12f, cy - h * 0.09f)
      lineTo(cx + w * 0.16f, cy - h * 0.12f)
      cubicTo(cx + w * 0.14f, cy - h * 0.14f, cx + w * 0.08f, cy - h * 0.15f, cx, cy - h * 0.18f)
      close()
    }
    drawPath(tier1Roof, color = roofColor)

    // Tier 2 Roof
    val tier2Roof = androidx.compose.ui.graphics.Path().apply {
      moveTo(cx, cy - h * 0.08f)
      cubicTo(cx - w * 0.12f, cy - h * 0.05f, cx - w * 0.20f, cy - h * 0.04f, cx - w * 0.24f, cy - h * 0.01f)
      lineTo(cx - w * 0.18f, cy + h * 0.04f)
      lineTo(cx + w * 0.18f, cy + h * 0.04f)
      lineTo(cx + w * 0.24f, cy - h * 0.01f)
      cubicTo(cx + w * 0.20f, cy - h * 0.04f, cx + w * 0.12f, cy - h * 0.05f, cx, cy - h * 0.08f)
      close()
    }
    drawPath(tier2Roof, color = roofColor)

    // Tier 3 Roof
    val tier3Roof = androidx.compose.ui.graphics.Path().apply {
      moveTo(cx, cy + h * 0.05f)
      cubicTo(cx - w * 0.16f, cy + h * 0.09f, cx - w * 0.28f, cy + h * 0.10f, cx - w * 0.32f, cy + h * 0.14f)
      lineTo(cx - w * 0.24f, cy + h * 0.20f)
      lineTo(cx + w * 0.24f, cy + h * 0.20f)
      lineTo(cx + w * 0.32f, cy + h * 0.14f)
      cubicTo(cx + w * 0.28f, cy + h * 0.10f, cx + w * 0.16f, cy + h * 0.09f, cx, cy + h * 0.05f)
      close()
    }
    drawPath(tier3Roof, color = roofColor)

    // Pagoda base structure
    drawRect(
      color = bodyColor,
      topLeft = Offset(cx - w * 0.13f, cy + h * 0.20f),
      size = androidx.compose.ui.geometry.Size(w * 0.26f, h * 0.16f)
    )

    // Delicate starlight sparkles
    drawMicroSparkle(Offset(cx - w * 0.28f, cy - h * 0.25f), 3.5.dp.toPx(), Color(0xFFE9D5FF))
    drawMicroSparkle(Offset(cx + w * 0.26f, cy - h * 0.28f), 4.0.dp.toPx(), Color(0xFFFFFFFF))
    drawMicroSparkle(Offset(cx - w * 0.18f, cy + h * 0.28f), 2.5.dp.toPx(), Color(0xFFC084FC))
    drawMicroSparkle(Offset(cx + w * 0.32f, cy + h * 0.18f), 3.0.dp.toPx(), Color(0xFFE9D5FF))
  }
}

private fun DrawScope.drawMicroSparkle(
  center: Offset,
  size: Float,
  color: Color,
) {
  val path = androidx.compose.ui.graphics.Path().apply {
    moveTo(center.x, center.y - size)
    cubicTo(center.x, center.y, center.x, center.y, center.x + size, center.y)
    cubicTo(center.x, center.y, center.x, center.y, center.x, center.y + size)
    cubicTo(center.x, center.y, center.x, center.y, center.x - size, center.y)
    cubicTo(center.x, center.y, center.x, center.y, center.x, center.y - size)
    close()
  }
  drawPath(path, color = color)
}

// -------------------------------------------------------------
// 3. TOP HEADER (EXACTLY MATCHING REFERENCE IMAGE)
// -------------------------------------------------------------
@Composable
fun TopHeader(
  onMenuClick: () -> Unit = {},
  onSearchClick: () -> Unit = {},
  onTicketClick: () -> Unit = {},
  onFavoritesClick: () -> Unit = {},
  showFavoritesOnly: Boolean = false,
  selectedCategory: String = "CHARACTERS",
  onCategoryClick: (String) -> Unit = {},
  // Was `scrollFraction: Float`, computed by the caller on every scroll frame - that
  // meant the caller's whole (very large) composable had to recompose just to hand
  // TopHeader a new number. Passing the stable listState + a rarely-changing boolean
  // instead, and computing the fraction in here, scopes all that per-frame work to
  // this composable alone.
  characterListState: LazyListState? = null,
  isOnCharactersTab: Boolean = true,
  modifier: Modifier = Modifier,
) {
  var ticketCount by remember { mutableStateOf(3) }

  val characterScrollFraction by remember(characterListState) {
    derivedStateOf {
      val state = characterListState
      if (state == null) {
        0f
      } else if (state.firstVisibleItemIndex > 0) {
        1f
      } else {
        (state.firstVisibleItemScrollOffset / 260f).coerceIn(0f, 1f)
      }
    }
  }

  val animatedScrollFraction by animateFloatAsState(
    targetValue = if (isOnCharactersTab) characterScrollFraction else 0f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioNoBouncy,
      stiffness = Spring.StiffnessMediumLow
    ),
    label = "top_header_scroll_anim"
  )
  val clampedFraction = if (animatedScrollFraction.isNaN()) 0f else animatedScrollFraction.coerceIn(0f, 1f)

  // Scroll-based subtle shrink and fade transformations
  val headerScale = 1f - (clampedFraction * 0.08f) // 1.0f -> 0.92f (shrinks slightly)
  val headerAlpha = 1f - (clampedFraction * 0.16f) // 1.0f -> 0.84f (fades slightly)

  // Dynamic logo dimensions with explicit non-zero height (44dp -> 36dp)
  val logoHeight = (44 - (8 * clampedFraction)).coerceAtLeast(34f).dp

  // Inner circular button dimensions
  val buttonInnerSize = (44 - (5 * clampedFraction)).dp // 44dp -> 39dp

  // Header vertical padding (slightly more compact when scrolled)
  val headerVerticalPadding = (4 - (2 * clampedFraction)).dp // 4dp -> 2dp
  val rowVerticalPadding = (6 - (2.5f * clampedFraction)).dp // 6dp -> 3.5dp

  Box(
    modifier = modifier
      .fillMaxWidth()
      .graphicsLayer {
        scaleX = headerScale
        scaleY = headerScale
        alpha = headerAlpha
        transformOrigin = TransformOrigin(0.5f, 0f)
      }
      .background(
        Brush.verticalGradient(
          colors = listOf(
            Color(0xFF0B0C14).copy(alpha = 0.55f + 0.35f * clampedFraction),
            Color(0xFF0B0C14).copy(alpha = 0.20f * clampedFraction)
          )
        )
      )
      .padding(top = headerVerticalPadding, bottom = headerVerticalPadding)
  ) {
    // Top Row: Hamburger + Logo + Ticket Voucher with Badge & Notifications Bell
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(start = 16.dp, end = 20.dp, top = rowVerticalPadding, bottom = rowVerticalPadding),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left: Circular Hamburger Button + Logo Branding
      Row(verticalAlignment = Alignment.CenterVertically) {
        // Circular Hamburger Button with 48.dp touch target & responsive spring press
        HeaderCircleButton(
          onClick = onMenuClick,
          buttonInnerSize = buttonInnerSize,
          testTag = "btn_menu"
        ) {
          Column(
            verticalArrangement = Arrangement.spacedBy(3.2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(modifier = Modifier.width(16.dp).height(1.8.dp).background(Color.White, RoundedCornerShape(1.dp)))
            Box(modifier = Modifier.width(16.dp).height(1.8.dp).background(Color.White, RoundedCornerShape(1.dp)))
            Box(modifier = Modifier.width(16.dp).height(1.8.dp).background(Color.White, RoundedCornerShape(1.dp)))
          }
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Genshin HUB Branding Logo Asset (v2)
        Image(
          painter = painterResource(id = R.drawable.genshin_hub_logo_v2),
          contentDescription = "Genshin HUB",
          contentScale = ContentScale.Fit,
          modifier = Modifier
            .height(logoHeight)
            .wrapContentWidth()
            .testTag("genshin_hub_logo")
        )
      }

      // Right: Ticket Voucher Button with Badge + Notifications Bell Button
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        // Ticket / Voucher Icon Button with Red Badge & responsive spring press
        Box(
          modifier = Modifier.size(48.dp),
          contentAlignment = Alignment.Center
        ) {
          HeaderCircleButton(
            onClick = onTicketClick,
            buttonInnerSize = buttonInnerSize,
            testTag = "btn_header_ticket"
          ) {
            Icon(
              imageVector = Icons.Outlined.ConfirmationNumber,
              contentDescription = "Vouchers",
              tint = Color(0xFFE2E8F0),
              modifier = Modifier.size(20.dp)
            )
          }

          // Small Red Badge showing ticketCount
          if (ticketCount > 0) {
            Box(
              modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = (-1).dp, y = 1.dp)
                .sizeIn(minWidth = 16.dp, minHeight = 16.dp)
                .clip(CircleShape)
                .background(Color(0xFFEF4444))
                .border(1.5.dp, Color(0xFF0B0C14), CircleShape)
                .padding(horizontal = 4.dp, vertical = 0.5.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = ticketCount.toString(),
                color = Color.White,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 11.sp
              )
            }
          }
        }

        // Notifications Bell Button
        HeaderCircleButton(
          onClick = onSearchClick,
          buttonInnerSize = buttonInnerSize,
          testTag = "btn_header_search"
        ) {
          Icon(
            imageVector = Icons.Outlined.Notifications,
            contentDescription = "Notifications",
            tint = Color(0xFFE2E8F0),
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}

@Composable
private fun HeaderCircleButton(
  onClick: () -> Unit,
  buttonInnerSize: androidx.compose.ui.unit.Dp,
  testTag: String,
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (isPressed) 0.88f else 1.0f,
    animationSpec = spring(
      dampingRatio = Spring.DampingRatioMediumBouncy,
      stiffness = Spring.StiffnessMedium
    ),
    label = "header_press_$testTag"
  )
  val subtleHaptics = rememberSubtleHaptics()

  Box(
    modifier = modifier.size(48.dp),
    contentAlignment = Alignment.Center
  ) {
    Box(
      modifier = Modifier
        .size(buttonInnerSize)
        .graphicsLayer {
          scaleX = scale
          scaleY = scale
        }
        .clip(CircleShape)
        .background(Color(0xFF0C132B).copy(alpha = 0.85f))
        .border(1.dp, Color(0xFF202B50), CircleShape)
        .clickable(
          interactionSource = interactionSource,
          indication = ripple(bounded = true, color = Color.White.copy(alpha = 0.25f)),
          onClick = {
            subtleHaptics.performTabSelect()
            onClick()
          }
        )
        .testTag(testTag),
      contentAlignment = Alignment.Center
    ) {
      content()
    }
  }
}

// -------------------------------------------------------------
// 4. ELEMENT FILTER BAR & SEARCH BAR
// -------------------------------------------------------------
private val FilterElements = listOf(
  ElementType.PYRO,
  ElementType.HYDRO,
  ElementType.ANEMO,
  ElementType.ELECTRO,
  ElementType.DENDRO,
  ElementType.CRYO,
  ElementType.GEO,
)

@Composable
fun SearchAndFilterBar(
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  selectedElement: ElementType?,
  onElementSelect: (ElementType) -> Unit,
  onFilterClick: () -> Unit = {},
  showFavoritesOnly: Boolean = false,
  onFavoritesClick: (() -> Unit)? = null,
  placeholderText: String = "Search characters...",
  modifier: Modifier = Modifier,
) {
  val focusManager = LocalFocusManager.current
  val haptic = LocalHapticFeedback.current
  val view = LocalView.current

  Column(modifier = modifier.fillMaxWidth()) {
    // Top Row: Search Input Field + Favorites Button
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Search Bar Container taking available width
      Box(
        modifier = (if (onFavoritesClick != null) Modifier.weight(1f) else Modifier.fillMaxWidth())
          .height(56.dp)
          .clip(RoundedCornerShape(18.dp))
          .background(SearchBarBackground)
          .border(1.dp, SearchBarBorder, RoundedCornerShape(18.dp))
          .padding(horizontal = 16.dp),
        contentAlignment = Alignment.CenterStart
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Box(modifier = Modifier.weight(1f)) {
            if (searchQuery.isEmpty()) {
              Text(
                text = placeholderText,
                color = TextMuted,
                fontSize = 14.sp
              )
            }
            BasicTextField(
              value = searchQuery,
              onValueChange = onSearchQueryChange,
              textStyle = TextStyle(
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal
              ),
              cursorBrush = SolidColor(PurpleLight),
              singleLine = true,
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
              keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("search_text_input")
            )
          }
          if (searchQuery.isNotEmpty()) {
            IconButton(
              onClick = { onSearchQueryChange("") },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = "Clear search",
                tint = TextMuted,
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }

      if (onFavoritesClick != null) {
        Spacer(modifier = Modifier.width(10.dp))

        val favInteractionSource = remember { MutableInteractionSource() }
        val isFavPressed by favInteractionSource.collectIsPressedAsState()
        val favScale by animateFloatAsState(
          targetValue = if (isFavPressed) 0.90f else 1.0f,
          animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
          ),
          label = "fav_btn_press"
        )

        // Favorites button: 56dp x 56dp, corner radius 18dp, star icon 24dp
        Box(
          modifier = Modifier
            .size(56.dp)
            .graphicsLayer {
              scaleX = favScale
              scaleY = favScale
            }
            .clip(RoundedCornerShape(18.dp))
            .background(
              if (showFavoritesOnly) Color(0xFF381E52) else SearchBarBackground
            )
            .border(
              width = 1.dp,
              color = if (showFavoritesOnly) PurplePrimary else SearchBarBorder,
              shape = RoundedCornerShape(18.dp)
            )
            .clickable(
              interactionSource = favInteractionSource,
              indication = ripple(bounded = true, color = PurplePrimary.copy(alpha = 0.35f)),
              onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onFavoritesClick()
              }
            )
            .testTag("btn_favorites_filter"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (showFavoritesOnly) Icons.Rounded.Star else Icons.Outlined.StarBorder,
            contentDescription = if (showFavoritesOnly) "Show all characters" else "Show favorites only",
            tint = if (showFavoritesOnly) Color(0xFFFBBF24) else Color(0xFFE2E8F0),
            modifier = Modifier.size(24.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Exactly 7 elemental icons in one single horizontal row:
    // Pyro, Hydro, Anemo, Electro, Dendro, Cryo, Geo
    // Equal circular size, equal spacing, same visual weight, equal horizontal distribution across available width
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      FilterElements.forEach { element ->
        val isSelected = selectedElement == element
        val elementColor = element.color
        val iconRes = element.getIconRes()

        Box(
          modifier = Modifier
            .weight(1f),
          contentAlignment = Alignment.Center
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .then(
                if (isSelected) {
                  Modifier
                    .shadow(
                      elevation = 6.dp,
                      shape = CircleShape,
                      spotColor = elementColor
                    )
                    .clip(CircleShape)
                    .background(
                      Brush.radialGradient(
                        colors = listOf(
                          elementColor.copy(alpha = 0.35f),
                          Color(0xFF141A32)
                        )
                      )
                    )
                    .border(
                      width = 2.dp,
                      color = elementColor,
                      shape = CircleShape
                    )
                } else {
                  Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF14192F))
                    .border(
                      width = 1.dp,
                      color = Color(0xFF232B4A),
                      shape = CircleShape
                    )
                }
              )
              .clickable {
                val performed = view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (!performed) {
                  haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
                onElementSelect(element)
              }
              .testTag("chip_element_${element.name.lowercase()}"),
            contentAlignment = Alignment.Center
          ) {
            if (iconRes != null) {
              Image(
                painter = painterResource(id = iconRes),
                contentDescription = element.displayName,
                modifier = Modifier.size(24.dp),
                contentScale = ContentScale.Fit
              )
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// 5. BOTTOM NAVIGATION BAR (EXACTLY MATCHING REFERENCE IMAGE)
// -------------------------------------------------------------
enum class BottomNavItem(val title: String) {
  CHARACTERS("Characters"),
  WEAPONS("Weapons"),
  ARTIFACTS("Artifacts"),
  TEAMS("Teams"),
  TIER_LIST("Tier List"),
}


