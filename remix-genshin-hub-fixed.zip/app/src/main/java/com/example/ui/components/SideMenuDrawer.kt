package com.example.ui.components

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Article
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.delay
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

/**
 * Data representation for an item in the side navigation menu.
 */
data class DrawerMenuItem(
  val id: String,
  val title: String,
  val iconVector: ImageVector? = null,
  val iconDrawable: Int? = null,
  val hasArrow: Boolean = true
)

/**
 * Data representation for a category grouping in the side navigation menu.
 */
data class DrawerMenuCategory(
  val title: String,
  val items: List<DrawerMenuItem>,
  val hasDividerLine: Boolean = false
)

/**
 * Menu categories and items matching the reference image exactly (طبق الأصل):
 * - MAIN:
 *     - Home (active capsule with glowing sparkle on right)
 *     - Characters (hair silhouette icon)
 *     - Weapons (tilted sword)
 *     - Artifacts (5-petal flower)
 *     - Teams (3 people group)
 *     - Tier List (3 ascending bars)
 *     - Favorites (heart)
 * - TOOLS (with subtle fading divider):
 *     - Wish Simulator (sparkle star)
 *     - Calculator (calculator)
 *     - Redeem Codes (voucher ticket with star)
 * - EXPLORE (with subtle fading divider):
 *     - News & Events (document/article)
 *     - Guides (book)
 *     - Interactive Map (location pin)
 * - SETTINGS:
 *     - Settings (gear, no arrow)
 *     - About (info, no arrow)
 */
private val drawerMenuCategories = listOf(
  DrawerMenuCategory(
    title = "MAIN",
    items = listOf(
      DrawerMenuItem("home", "Home", iconVector = Icons.Rounded.Home, hasArrow = false),
      DrawerMenuItem("characters", "Characters", iconDrawable = R.drawable.ic_menu_char_silhouette, hasArrow = true),
      DrawerMenuItem("weapons", "Weapons", iconDrawable = R.drawable.ic_menu_sword, hasArrow = true),
      DrawerMenuItem("artifacts", "Artifacts", iconDrawable = R.drawable.ic_menu_flower, hasArrow = true),
      DrawerMenuItem("teams", "Teams", iconDrawable = R.drawable.ic_menu_teams_group, hasArrow = true),
      DrawerMenuItem("tier_list", "Tier List", iconDrawable = R.drawable.ic_menu_barchart, hasArrow = true),
      DrawerMenuItem("favorites", "Favorites", iconVector = Icons.Rounded.Favorite, hasArrow = true)
    )
  ),
  DrawerMenuCategory(
    title = "TOOLS",
    hasDividerLine = true,
    items = listOf(
      DrawerMenuItem("wish_simulator", "Wish Simulator", iconVector = Icons.Rounded.AutoAwesome, hasArrow = true),
      DrawerMenuItem("calculator", "Calculator", iconVector = Icons.Rounded.Calculate, hasArrow = true),
      DrawerMenuItem("redeem_codes", "Redeem Codes", iconDrawable = R.drawable.ic_menu_ticket_star, hasArrow = true)
    )
  ),
  DrawerMenuCategory(
    title = "EXPLORE",
    hasDividerLine = true,
    items = listOf(
      DrawerMenuItem("news_events", "News & Events", iconVector = Icons.AutoMirrored.Rounded.Article, hasArrow = true),
      DrawerMenuItem("guides", "Guides", iconVector = Icons.AutoMirrored.Rounded.MenuBook, hasArrow = true),
      DrawerMenuItem("interactive_map", "Interactive Map", iconVector = Icons.Rounded.LocationOn, hasArrow = true)
    )
  ),
  DrawerMenuCategory(
    title = "SETTINGS",
    items = listOf(
      DrawerMenuItem("settings", "Settings", iconVector = Icons.Rounded.Settings, hasArrow = false),
      DrawerMenuItem("about", "About", iconVector = Icons.Rounded.Info, hasArrow = false)
    )
  )
)

/**
 * Premium Genshin-inspired side navigation drawer matching the reference image.
 *
 * Visual & functional specifications:
 * - Fixed left-side panel occupying ~70% screen width.
 * - Deep fantasy dark blue/navy gradient background.
 * - Rounded right edge (topEnd & bottomEnd = 24.dp) with a luminous glowing cyan/periwinkle border.
 * - Header layout:
 *   - Close button (circular translucent pill with thin X) at top-right.
 *   - Genshin HUB logo with glowing Primogem 4-pointed star & "EXPLORE • BUILD • ENJOY".
 *   - "A thousand worlds, one celebration. — Paimon" quote in italic serif.
 *   - Floating Paimon mascot in the upper right.
 * - Full categorized menu (MAIN, TOOLS, EXPLORE, SETTINGS) with exact icons and options.
 * - Active state: Rounded capsule with soft blue/indigo gradient and glowing star.
 * - Architectural canvas background: Gothic cathedral window, blue hanging banner with gold star crest,
 *   warm street lantern glow, and Glaze Lily flowers.
 * - Footer: "Teyvat Always With You" in cursive script with ✦ sparkle, and version "v1.0.0".
 */
@Composable
fun SideMenuDrawer(
  selectedDestination: String = "Home",
  onDismiss: () -> Unit,
  onMenuItemClick: (String) -> Unit,
  onSupportClick: ((String) -> Unit)? = null,
  modifier: Modifier = Modifier,
  drawerWidthDp: Dp = 280.dp,
  // A lambda instead of a raw Float: reading progress() only inside graphicsLayer{}
  // below defers the read to the draw phase, so dragging updates just this layer's
  // transform instead of recomposing this whole (1000+ line) composable every frame.
  progress: () -> Float = { 1f },
  visible: Boolean = progress() > 0f,
  onDragStarted: (() -> Unit)? = null,
  onDragDelta: ((Float) -> Unit)? = null,
  onDragStopped: ((Float) -> Unit)? = null
) {
  val scrollState = rememberScrollState()

  // Track animation state when drawer becomes visible for staggered entrance
  var isAnimatedIn by remember { mutableStateOf(false) }
  LaunchedEffect(visible) {
    if (visible) {
      delay(16)
      isAnimatedIn = true
    } else {
      isAnimatedIn = false
    }
  }

  // Use uploaded menu_bg_drawer_final.webp drawable directly as background
  val customBgResId = R.drawable.menu_bg_drawer_final

  // Outer container taking the drawer width and full height, offset below the Android Status Bar
  Box(
    modifier = modifier
      .width(drawerWidthDp)
      .fillMaxHeight()
      .windowInsetsPadding(WindowInsets.statusBars.only(WindowInsetsSides.Top))
      .graphicsLayer {
        translationX = (progress() - 1f) * drawerWidthDp.toPx()
      }
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .shadow(
          elevation = 20.dp,
          shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
          spotColor = Color.Black.copy(alpha = 0.9f),
          ambientColor = Color(0xFF0C132C)
        )
        .clip(RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp))
        .border(
          width = 1.2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0x9960A5FA), // Glowing sky blue at top
              Color(0x66818CF8), // Periwinkle mid glow
              Color(0x4D38BDF8), // Cyan edge accent
              Color(0x201E3A8A)  // Deep navy edge fade
            )
          ),
          shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp)
        )
        .draggable(
          state = rememberDraggableState { delta ->
            if (onDragDelta != null) {
              onDragDelta(delta)
            } else if (delta < -12f) {
              onDismiss()
            }
          },
          onDragStarted = {
            onDragStarted?.invoke()
          },
          onDragStopped = { velocity ->
            if (onDragStopped != null) {
              onDragStopped(velocity)
            }
          },
          orientation = Orientation.Horizontal
        )
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = {}
        )
        .testTag("side_menu_panel"),
      shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
      color = Color.Transparent
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        // 1. Background Layer: User-uploaded menu_bg_drawer_final asset directly as drawer background
        if (customBgResId != 0) {
          // User-uploaded menu_bg_drawer_final.webp:
          // Preserves original aspect ratio with ContentScale.Fit, displaying the entire image
          // within the drawer without cropping, stretching, distortion, or extra overlay layers.
          Image(
            painter = painterResource(id = customBgResId),
            contentDescription = "Drawer Background",
            contentScale = ContentScale.Fit,
            alignment = Alignment.TopCenter,
            modifier = Modifier.fillMaxSize()
          )

        // Subtle dark gradient in the lower-left area only (below Redeem Codes):
        // Keeps the area behind "News & Events" and "Guides" darker and visually clean,
        // preventing decorative text/details from overlapping or interfering with menu items,
        // while leaving everything above Redeem Codes 100% untouched and preserving the bright
        // flowers, archway, and glowing lantern toward the right and lower edge.
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.48f)
            .align(Alignment.BottomStart)
            .background(
              Brush.horizontalGradient(
                0.0f to Color(0xE6010A1E),   // Rich deep midnight blue behind lower menu items on left
                0.38f to Color(0x99010A1E),  // Smooth soft transition
                0.62f to Color(0x26010A1E),  // Fades away before the flowers/lantern
                0.75f to Color.Transparent,  // Leaves flowers and lantern on right bright and clear
                1.0f to Color.Transparent
              )
            )
            .background(
              Brush.verticalGradient(
                0.0f to Color.Transparent,   // Seamless transition starting below Redeem Codes
                0.22f to Color(0x33010A1E),
                0.55f to Color(0x66010A1E),
                1.0f to Color(0x8C010A1E)
              )
            )
        )
      } else {
        Canvas(modifier = Modifier.fillMaxSize()) {
          drawGenshinMenuBackground(size)
        }
      }

    // Scrollable Drawer Content
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
    ) {
      // 1. TOP HEADER: Branding/quote (if not already embedded in background)
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)
      ) {
        if (customBgResId == 0) {
          // Upper-right mascot: Floating Paimon peeking out under close button
          FloatingPaimonMascot(
            modifier = Modifier
              .align(Alignment.CenterEnd)
              .padding(top = 18.dp, end = 4.dp)
              .size(width = 90.dp, height = 80.dp)
          )

          // Upper-left: Genshin HUB Branding Logo & Quote
          Column(
            modifier = Modifier
              .fillMaxWidth(0.72f)
              .padding(top = 2.dp)
          ) {
            // Logo & Title
            Row(
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Four-pointed glowing Primogem star emblem
              Box(
                modifier = Modifier.size(30.dp),
                contentAlignment = Alignment.Center
              ) {
                Canvas(modifier = Modifier.size(26.dp)) {
                  drawPrimogemStar(size)
                }
              }

              Spacer(modifier = Modifier.width(8.dp))

              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "Genshin",
                    color = Color.White,
                    fontSize = 18.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                  )
                  Text(
                    text = "Hub",
                    color = Color(0xFFFBBF24),
                    fontSize = 18.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                  )
                }
                Text(
                  text = "EXPLORE • BUILD • ENJOY",
                  color = Color(0xFF94A3B8),
                  fontSize = 8.5.sp,
                  fontWeight = FontWeight.SemiBold,
                  letterSpacing = 1.6.sp
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Paimon quote from the reference image
            Text(
              text = "“A thousand worlds,\none celebration.”\n— Paimon",
              color = Color(0xFFCBD5E1),
              fontSize = 12.sp,
              fontStyle = FontStyle.Italic,
              fontFamily = FontFamily.Serif,
              lineHeight = 16.sp
            )
          }
        } else {
          // When using custom background artwork (which already contains the logo, quote, and Paimon):
          // Provide appropriate vertical space so MAIN items align beneath the quote
          Spacer(modifier = Modifier.height(118.dp))
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 2. CATEGORIZED MENU ITEMS with staggered entrance animation
      var staggerIndex = 0
      drawerMenuCategories.forEachIndexed { catIndex, category ->
        val headerStaggerIndex = staggerIndex++
        val headerAlpha by animateFloatAsState(
          targetValue = if (isAnimatedIn) 1f else 0f,
          animationSpec = tween(
            durationMillis = 240,
            delayMillis = (24 + headerStaggerIndex * 24).coerceAtMost(520),
            easing = FastOutSlowInEasing
          ),
          label = "header_alpha_$catIndex"
        )
        val headerSlideX by animateFloatAsState(
          targetValue = if (isAnimatedIn) 0f else -14f,
          animationSpec = tween(
            durationMillis = 280,
            delayMillis = (24 + headerStaggerIndex * 24).coerceAtMost(520),
            easing = CubicBezierEasing(0.16f, 1.0f, 0.3f, 1.0f)
          ),
          label = "header_slide_$catIndex"
        )

        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
          // Category Header with optional fading horizontal divider
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .graphicsLayer {
                alpha = headerAlpha
                translationX = headerSlideX.dp.toPx()
              }
              .padding(start = 6.dp, end = 6.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = category.title,
              color = Color(0xFF7E8B9B),
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.4.sp
            )

            if (category.hasDividerLine) {
              Spacer(modifier = Modifier.width(10.dp))
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(1.dp)
                  .background(
                    Brush.horizontalGradient(
                      colors = listOf(
                        Color(0x3394A3B8),
                        Color(0x1594A3B8),
                        Color.Transparent
                      )
                    )
                  )
              )
            }
          }

          // Category Menu Items
          category.items.forEach { item ->
            val itemStaggerIndex = staggerIndex++
            val itemAlpha by animateFloatAsState(
              targetValue = if (isAnimatedIn) 1f else 0f,
              animationSpec = tween(
                durationMillis = 260,
                delayMillis = (24 + itemStaggerIndex * 24).coerceAtMost(560),
                easing = FastOutSlowInEasing
              ),
              label = "item_alpha_${item.id}"
            )
            val itemSlideX by animateFloatAsState(
              targetValue = if (isAnimatedIn) 0f else -18f,
              animationSpec = tween(
                durationMillis = 300,
                delayMillis = (24 + itemStaggerIndex * 24).coerceAtMost(560),
                easing = CubicBezierEasing(0.16f, 1.0f, 0.3f, 1.0f)
              ),
              label = "item_slide_${item.id}"
            )

            val isSelected = selectedDestination.equals(item.title, ignoreCase = true) ||
              (item.title == "Home" && (selectedDestination.isEmpty() || selectedDestination == "Home"))

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                  alpha = itemAlpha
                  translationX = itemSlideX.dp.toPx()
                }
                .padding(vertical = 2.dp)
                .clip(RoundedCornerShape(14.dp))
                .then(
                  if (isSelected) {
                    Modifier
                      .background(
                        Brush.horizontalGradient(
                          colors = listOf(
                            Color(0x3D38BDF8),
                            Color(0x2E6366F1),
                            Color(0x1A4F46E5)
                          )
                        )
                      )
                      .border(
                        width = 1.dp,
                        color = Color(0x80818CF8),
                        shape = RoundedCornerShape(14.dp)
                      )
                  } else {
                    Modifier.background(Color.Transparent)
                  }
                )
                .clickable(
                  interactionSource = remember { MutableInteractionSource() },
                  indication = ripple(bounded = true, color = Color.White.copy(alpha = 0.2f)),
                  onClick = { onMenuItemClick(item.title) }
                )
                .padding(horizontal = 14.dp, vertical = 11.dp)
                .testTag("menu_item_${item.id}"),
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Left Icon
              if (item.iconVector != null) {
                Icon(
                  imageVector = item.iconVector,
                  contentDescription = item.title,
                  tint = if (isSelected) Color(0xFFE0F2FE) else Color(0xFFA5B4FC).copy(alpha = 0.85f),
                  modifier = Modifier.size(20.dp)
                )
              } else if (item.iconDrawable != null) {
                Icon(
                  painter = painterResource(id = item.iconDrawable),
                  contentDescription = item.title,
                  tint = if (isSelected) Color(0xFFE0F2FE) else Color(0xFFA5B4FC).copy(alpha = 0.85f),
                  modifier = Modifier.size(20.dp)
                )
              }

              Spacer(modifier = Modifier.width(14.dp))

              // Title Label
              Text(
                text = item.title,
                color = if (isSelected) Color.White else Color(0xFFE2E8F0),
                fontSize = 14.5.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier.weight(1f)
              )

              // Right Indicator: Golden sparkle for active item, or subtle chevron for navigable items
              if (isSelected) {
                Icon(
                  imageVector = Icons.Rounded.AutoAwesome,
                  contentDescription = "Selected",
                  tint = Color(0xFFFBBF24),
                  modifier = Modifier.size(16.dp)
                )
              } else if (item.hasArrow) {
                Icon(
                  imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                  contentDescription = null,
                  tint = Color(0x59FFFFFF),
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }
        }
      }

      // 3. DECORATIVE BOTTOM FOOTER: "Teyvat Always With You" & App Version
      val footerAlpha by animateFloatAsState(
        targetValue = if (isAnimatedIn) 1f else 0f,
        animationSpec = tween(
          durationMillis = 300,
          delayMillis = 400,
          easing = FastOutSlowInEasing
        ),
        label = "footer_alpha"
      )

      Spacer(modifier = Modifier.height(28.dp))
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .graphicsLayer { alpha = footerAlpha }
          .windowInsetsPadding(WindowInsets.navigationBars)
          .padding(horizontal = 22.dp, vertical = 14.dp)
      ) {
        if (customBgResId == 0) {
          Column {
            Text(
              text = "Teyvat\nAlways With You",
              color = Color(0xFFCBD5E1).copy(alpha = 0.85f),
              fontSize = 13.5.sp,
              fontStyle = FontStyle.Italic,
              fontFamily = FontFamily.Serif,
              lineHeight = 17.sp
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
              text = "✦",
              color = Color(0xFFFBBF24).copy(alpha = 0.85f),
              fontSize = 13.sp
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End
        ) {
          Text(
            text = "v1.0.0",
            color = Color(0xFF64748B),
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.testTag("side_menu_version_text")
          )
        }
      }
    }
  }
}
}
}

/**
 * Mascot illustration of Paimon floating in the upper right corner of the drawer.
 * Renders Paimon's floating halo, white hair, cute expression, scarf, and star brooch.
 */
@Composable
private fun FloatingPaimonMascot(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    val cx = w * 0.55f
    val cy = h * 0.50f

    // 1. Surrounding sparkle stars
    drawStarSparkle(Offset(w * 0.15f, h * 0.20f), 4.dp.toPx(), Color(0xFFFBBF24).copy(alpha = 0.7f))
    drawStarSparkle(Offset(w * 0.88f, h * 0.65f), 3.5.dp.toPx(), Color(0xFF60A5FA).copy(alpha = 0.8f))
    drawStarSparkle(Offset(w * 0.25f, h * 0.80f), 3.dp.toPx(), Color.White.copy(alpha = 0.6f))

    // 2. Floating Crown Halo hovering above head
    val haloY = cy - 26.dp.toPx()
    val haloWidth = 24.dp.toPx()
    val haloHeight = 8.dp.toPx()

    // Halo outer dark indigo / gold stroke
    drawOval(
      color = Color(0xFF1E1B4B),
      topLeft = Offset(cx - haloWidth / 2, haloY - haloHeight / 2),
      size = Size(haloWidth, haloHeight),
      style = Stroke(width = 3.dp.toPx())
    )
    drawOval(
      color = Color(0xFFFBBF24),
      topLeft = Offset(cx - haloWidth / 2, haloY - haloHeight / 2),
      size = Size(haloWidth, haloHeight),
      style = Stroke(width = 1.2.dp.toPx())
    )
    // Halo gold star center crest
    drawCircle(
      color = Color(0xFFFDE047),
      radius = 2.dp.toPx(),
      center = Offset(cx, haloY - haloHeight / 2)
    )

    // 3. Hair Back (White fluffy hair)
    drawCircle(
      color = Color(0xFFE2E8F0),
      radius = 18.dp.toPx(),
      center = Offset(cx, cy - 2.dp.toPx())
    )

    // 4. Face (Soft peach skin)
    drawCircle(
      color = Color(0xFFFFF1EB),
      radius = 13.dp.toPx(),
      center = Offset(cx - 2.dp.toPx(), cy)
    )

    // 5. Hair Bangs & Side Tufts
    val hairPath = Path().apply {
      moveTo(cx - 15.dp.toPx(), cy - 8.dp.toPx())
      cubicTo(cx - 10.dp.toPx(), cy - 18.dp.toPx(), cx + 6.dp.toPx(), cy - 18.dp.toPx(), cx + 12.dp.toPx(), cy - 6.dp.toPx())
      cubicTo(cx + 8.dp.toPx(), cy - 4.dp.toPx(), cx + 2.dp.toPx(), cy - 2.dp.toPx(), cx - 1.dp.toPx(), cy - 8.dp.toPx())
      cubicTo(cx - 4.dp.toPx(), cy - 4.dp.toPx(), cx - 10.dp.toPx(), cy - 4.dp.toPx(), cx - 15.dp.toPx(), cy - 8.dp.toPx())
      close()
    }
    drawPath(path = hairPath, color = Color(0xFFF8FAFC))

    // Dark Hair Clip on left side of bangs
    drawRoundRect(
      color = Color(0xFF1E293B),
      topLeft = Offset(cx - 11.dp.toPx(), cy - 12.dp.toPx()),
      size = Size(5.dp.toPx(), 2.5.dp.toPx()),
      cornerRadius = androidx.compose.ui.geometry.CornerRadius(1.dp.toPx())
    )

    // 6. Cute Anime Eyes (Indigo-purple with bright highlights)
    val leftEyeCenter = Offset(cx - 6.5.dp.toPx(), cy + 0.5.dp.toPx())
    val rightEyeCenter = Offset(cx + 2.5.dp.toPx(), cy + 0.5.dp.toPx())

    // Left Eye
    drawOval(
      color = Color(0xFF312E81),
      topLeft = Offset(leftEyeCenter.x - 2.2.dp.toPx(), leftEyeCenter.y - 3.5.dp.toPx()),
      size = Size(4.4.dp.toPx(), 7.dp.toPx())
    )
    drawCircle(color = Color.White, radius = 1.2.dp.toPx(), center = Offset(leftEyeCenter.x - 0.8.dp.toPx(), leftEyeCenter.y - 1.5.dp.toPx()))

    // Right Eye
    drawOval(
      color = Color(0xFF312E81),
      topLeft = Offset(rightEyeCenter.x - 2.2.dp.toPx(), rightEyeCenter.y - 3.5.dp.toPx()),
      size = Size(4.4.dp.toPx(), 7.dp.toPx())
    )
    drawCircle(color = Color.White, radius = 1.2.dp.toPx(), center = Offset(rightEyeCenter.x - 0.8.dp.toPx(), rightEyeCenter.y - 1.5.dp.toPx()))

    // 7. Rosy Cheeks
    drawCircle(
      color = Color(0xFFF472B6).copy(alpha = 0.55f),
      radius = 2.5.dp.toPx(),
      center = Offset(cx - 9.dp.toPx(), cy + 4.5.dp.toPx())
    )
    drawCircle(
      color = Color(0xFFF472B6).copy(alpha = 0.55f),
      radius = 2.5.dp.toPx(),
      center = Offset(cx + 5.5.dp.toPx(), cy + 4.5.dp.toPx())
    )

    // 8. Cheerful Open Smile
    val mouthPath = Path().apply {
      moveTo(cx - 3.dp.toPx(), cy + 5.dp.toPx())
      quadraticTo(cx - 1.5.dp.toPx(), cy + 7.5.dp.toPx(), cx + 0.5.dp.toPx(), cy + 5.dp.toPx())
    }
    drawPath(path = mouthPath, color = Color(0xFF9D174D), style = Stroke(width = 1.2.dp.toPx(), cap = StrokeCap.Round))

    // 9. Collar, Outfit & Golden Star Brooch
    val outfitPath = Path().apply {
      moveTo(cx - 10.dp.toPx(), cy + 12.dp.toPx())
      lineTo(cx + 8.dp.toPx(), cy + 12.dp.toPx())
      lineTo(cx + 12.dp.toPx(), cy + 22.dp.toPx())
      lineTo(cx - 14.dp.toPx(), cy + 22.dp.toPx())
      close()
    }
    drawPath(path = outfitPath, color = Color(0xFFF1F5F9))

    // Scarf navy collar trim
    drawLine(
      color = Color(0xFF1E3A8A),
      start = Offset(cx - 8.dp.toPx(), cy + 13.dp.toPx()),
      end = Offset(cx + 6.dp.toPx(), cy + 13.dp.toPx()),
      strokeWidth = 2.dp.toPx()
    )

    // Golden Star Brooch on chest
    drawStarSparkle(Offset(cx - 1.dp.toPx(), cy + 15.dp.toPx()), 3.dp.toPx(), Color(0xFFFBBF24))

    // Outstretched waving hand to the left
    drawCircle(
      color = Color(0xFFFFF1EB),
      radius = 3.dp.toPx(),
      center = Offset(cx - 16.dp.toPx(), cy + 12.dp.toPx())
    )
  }
}

/**
 * Draws the celestial night sky, gothic castle arch, hanging royal blue banner with gold star emblem,
 * radiant warm street lantern, and Glaze Lily flowers matching the reference image.
 */
private fun DrawScope.drawGenshinMenuBackground(canvasSize: Size) {
  val w = canvasSize.width
  val h = canvasSize.height

  // 1. Twinkling celestial stars and stardust in the upper half
  val stars = listOf(
    Offset(w * 0.12f, h * 0.04f) to 0.7f,
    Offset(w * 0.38f, h * 0.03f) to 0.5f,
    Offset(w * 0.82f, h * 0.07f) to 0.85f,
    Offset(w * 0.22f, h * 0.10f) to 0.4f,
    Offset(w * 0.60f, h * 0.12f) to 0.75f,
    Offset(w * 0.86f, h * 0.19f) to 0.6f,
    Offset(w * 0.18f, h * 0.28f) to 0.45f,
    Offset(w * 0.42f, h * 0.32f) to 0.6f,
    Offset(w * 0.78f, h * 0.40f) to 0.7f,
    Offset(w * 0.10f, h * 0.52f) to 0.5f,
    Offset(w * 0.32f, h * 0.60f) to 0.4f
  )

  stars.forEach { (pos, alpha) ->
    drawCircle(
      color = Color.White.copy(alpha = alpha * 0.85f),
      radius = 1.6.dp.toPx(),
      center = pos
    )
    drawCircle(
      color = Color(0xFF60A5FA).copy(alpha = alpha * 0.35f),
      radius = 3.5.dp.toPx(),
      center = pos
    )
  }

  // 2. Faint silhouette of fairy-tale castle towers/spires in upper-mid background
  val castleSpires = listOf(
    Triple(w * 0.68f, h * 0.16f, 18.dp.toPx()),
    Triple(w * 0.75f, h * 0.14f, 26.dp.toPx()),
    Triple(w * 0.82f, h * 0.17f, 20.dp.toPx())
  )
  castleSpires.forEach { (cx, topY, height) ->
    val spirePath = Path().apply {
      moveTo(cx, topY)
      lineTo(cx + 6.dp.toPx(), topY + height)
      lineTo(cx - 6.dp.toPx(), topY + height)
      close()
    }
    drawPath(path = spirePath, color = Color(0x1F1E293B))
  }

  // 3. ARCHITECTURAL LOWER BACKGROUND: Cathedral Gothic Arch, Blue Hanging Banner, Warm Lantern & Flowers
  // We place this starting around Y = 56% to bottom
  val archTopY = h * 0.54f
  val archRight = w * 0.98f
  val archLeft = w * 0.40f
  val archWidth = archRight - archLeft
  val sillY = h * 0.88f

  // Gothic Arched Window Outer Outline
  val archPath = Path().apply {
    moveTo(archLeft, sillY)
    lineTo(archLeft, archTopY + archWidth * 0.5f)
    cubicTo(
      archLeft, archTopY + archWidth * 0.1f,
      archLeft + archWidth * 0.35f, archTopY,
      archLeft + archWidth * 0.5f, archTopY - 8.dp.toPx()
    )
    cubicTo(
      archLeft + archWidth * 0.65f, archTopY,
      archRight, archTopY + archWidth * 0.1f,
      archRight, archTopY + archWidth * 0.5f
    )
    lineTo(archRight, sillY)
    close()
  }

  // Deep starry open sky seen through the arch
  drawPath(
    path = archPath,
    brush = Brush.verticalGradient(
      colors = listOf(
        Color(0x2E1E3A8A),
        Color(0x1A0F172A),
        Color(0x28030712)
      )
    )
  )

  // Arch Stone Moulding Stroke
  drawPath(
    path = archPath,
    brush = Brush.verticalGradient(
      colors = listOf(
        Color(0x4060A5FA),
        Color(0x2638BDF8),
        Color(0x101E293B)
      )
    ),
    style = Stroke(width = 2.5.dp.toPx())
  )

  // 4. Hanging Royal Blue Tapestry Banner with Swallowtail & Golden Star Crest
  val bannerX = archLeft + archWidth * 0.28f
  val bannerWidth = 36.dp.toPx()
  val bannerTopY = archTopY + 12.dp.toPx()
  val bannerBottomY = archTopY + 110.dp.toPx()

  val bannerPath = Path().apply {
    moveTo(bannerX, bannerTopY)
    lineTo(bannerX + bannerWidth, bannerTopY)
    lineTo(bannerX + bannerWidth, bannerBottomY)
    // Swallowtail point
    lineTo(bannerX + bannerWidth * 0.5f, bannerBottomY - 10.dp.toPx())
    lineTo(bannerX, bannerBottomY)
    close()
  }

  // Banner Royal Blue Fabric
  drawPath(
    path = bannerPath,
    brush = Brush.verticalGradient(
      colors = listOf(
        Color(0x8A1D4ED8),
        Color(0x701E3A8A),
        Color(0x55172554)
      )
    )
  )
  // Banner Gold Trim Border
  drawPath(
    path = bannerPath,
    color = Color(0x66FBBF24),
    style = Stroke(width = 1.dp.toPx())
  )

  // Golden Diamond Star Crest in center of banner
  val crestCenter = Offset(bannerX + bannerWidth * 0.5f, bannerTopY + 45.dp.toPx())
  drawStarSparkle(crestCenter, 7.dp.toPx(), Color(0xCCFBBF24))

  // 5. Stone Sill Balustrade
  val sillPath = Path().apply {
    moveTo(archLeft - 10.dp.toPx(), sillY)
    lineTo(w, sillY)
    lineTo(w, h)
    lineTo(archLeft - 10.dp.toPx(), h)
    close()
  }
  drawPath(
    path = sillPath,
    brush = Brush.verticalGradient(
      colors = listOf(
        Color(0x381E293B),
        Color(0x240F172A),
        Color(0x10020617)
      )
    )
  )

  // 6. Warm Vintage Street Lantern sitting on the stone ledge
  val lanternCenterX = archLeft + archWidth * 0.65f
  val lanternBaseY = sillY + 4.dp.toPx()
  val lanternHeight = 36.dp.toPx()
  val lanternTopY = lanternBaseY - lanternHeight

  // Radiant Warm Golden Radial Bloom from the lantern
  drawCircle(
    brush = Brush.radialGradient(
      colors = listOf(
        Color(0x50FBBF24),
        Color(0x2EF59E0B),
        Color(0x12D97706),
        Color.Transparent
      ),
      center = Offset(lanternCenterX, lanternBaseY - lanternHeight * 0.45f),
      radius = 55.dp.toPx()
    ),
    center = Offset(lanternCenterX, lanternBaseY - lanternHeight * 0.45f),
    radius = 55.dp.toPx()
  )

  // Lantern Glass Body (Glowing warm amber/yellow)
  val glassPath = Path().apply {
    moveTo(lanternCenterX - 7.dp.toPx(), lanternBaseY - 6.dp.toPx())
    lineTo(lanternCenterX + 7.dp.toPx(), lanternBaseY - 6.dp.toPx())
    lineTo(lanternCenterX + 9.dp.toPx(), lanternTopY + 10.dp.toPx())
    lineTo(lanternCenterX - 9.dp.toPx(), lanternTopY + 10.dp.toPx())
    close()
  }
  drawPath(
    path = glassPath,
    brush = Brush.verticalGradient(
      colors = listOf(
        Color(0xFFFEF08A),
        Color(0xFFFBBF24),
        Color(0xFFF59E0B)
      )
    )
  )

  // Lantern Iron Cap (Roof)
  val roofPath = Path().apply {
    moveTo(lanternCenterX, lanternTopY)
    lineTo(lanternCenterX + 12.dp.toPx(), lanternTopY + 10.dp.toPx())
    lineTo(lanternCenterX - 12.dp.toPx(), lanternTopY + 10.dp.toPx())
    close()
  }
  drawPath(path = roofPath, color = Color(0xFF1E293B))
  drawPath(path = roofPath, color = Color(0x66FBBF24), style = Stroke(width = 1.dp.toPx()))

  // Lantern Base
  drawRoundRect(
    color = Color(0xFF1E293B),
    topLeft = Offset(lanternCenterX - 9.dp.toPx(), lanternBaseY - 6.dp.toPx()),
    size = Size(18.dp.toPx(), 6.dp.toPx()),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
  )

  // 7. Cluster of Blooming Blue/Purple Glaze Lily Flowers around the lantern base
  val flowerClusters = listOf(
    Offset(lanternCenterX - 18.dp.toPx(), sillY + 2.dp.toPx()),
    Offset(lanternCenterX - 8.dp.toPx(), sillY + 8.dp.toPx()),
    Offset(lanternCenterX + 12.dp.toPx(), sillY + 5.dp.toPx()),
    Offset(lanternCenterX + 22.dp.toPx(), sillY + 1.dp.toPx())
  )

  flowerClusters.forEach { fCenter ->
    // 5 Petals around center
    val petalCount = 5
    val petalRadius = 4.5.dp.toPx()
    for (i in 0 until petalCount) {
      val angle = (i * (2 * Math.PI / petalCount)).toFloat()
      val px = fCenter.x + (petalRadius * Math.cos(angle.toDouble())).toFloat()
      val py = fCenter.y + (petalRadius * Math.sin(angle.toDouble())).toFloat()
      drawCircle(
        color = Color(0xB3818CF8),
        radius = 2.4.dp.toPx(),
        center = Offset(px, py)
      )
    }
    // Glowing golden flower pistil center
    drawCircle(
      color = Color(0xFFFDE047),
      radius = 1.6.dp.toPx(),
      center = fCenter
    )
  }
}

/**
 * Draws a 4-pointed sparkle star with luminous outer flare.
 */
private fun DrawScope.drawStarSparkle(center: Offset, radius: Float, color: Color) {
  val path = Path().apply {
    moveTo(center.x, center.y - radius)
    cubicTo(
      center.x + radius * 0.15f, center.y - radius * 0.15f,
      center.x + radius * 0.15f, center.y - radius * 0.15f,
      center.x + radius, center.y
    )
    cubicTo(
      center.x + radius * 0.15f, center.y + radius * 0.15f,
      center.x + radius * 0.15f, center.y + radius * 0.15f,
      center.x, center.y + radius
    )
    cubicTo(
      center.x - radius * 0.15f, center.y + radius * 0.15f,
      center.x - radius * 0.15f, center.y + radius * 0.15f,
      center.x - radius, center.y
    )
    cubicTo(
      center.x - radius * 0.15f, center.y - radius * 0.15f,
      center.x - radius * 0.15f, center.y - radius * 0.15f,
      center.x, center.y - radius
    )
    close()
  }
  drawPath(path = path, color = color)
}

/**
 * Draws the iconic 4-pointed Primogem star with glowing core on Canvas.
 */
private fun DrawScope.drawPrimogemStar(size: Size) {
  val cx = size.width / 2f
  val cy = size.height / 2f
  val r = size.width / 2f

  val outerPath = Path().apply {
    moveTo(cx, cy - r)
    cubicTo(cx + r * 0.15f, cy - r * 0.25f, cx + r * 0.25f, cy - r * 0.15f, cx + r, cy)
    cubicTo(cx + r * 0.25f, cy + r * 0.15f, cx + r * 0.15f, cy + r * 0.25f, cx, cy + r)
    cubicTo(cx - r * 0.15f, cy + r * 0.25f, cx - r * 0.25f, cy + r * 0.15f, cx - r, cy)
    cubicTo(cx - r * 0.25f, cy - r * 0.15f, cx - r * 0.15f, cy - r * 0.25f, cx, cy - r)
    close()
  }

  // Draw outer cyan glow
  drawPath(
    path = outerPath,
    brush = Brush.radialGradient(
      colors = listOf(Color(0xFF60A5FA), Color(0xFF3B82F6), Color(0xFF1E3A8A)),
      center = Offset(cx, cy),
      radius = r
    )
  )

  // Inner golden diamond core
  val innerDiamond = Path().apply {
    val ir = r * 0.45f
    moveTo(cx, cy - ir)
    lineTo(cx + ir * 0.7f, cy)
    lineTo(cx, cy + ir)
    lineTo(cx - ir * 0.7f, cy)
    close()
  }

  drawPath(
    path = innerDiamond,
    color = Color(0xFFFBBF24)
  )
}
