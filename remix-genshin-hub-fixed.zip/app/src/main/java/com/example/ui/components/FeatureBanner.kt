package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class BannerItem(
  val id: String,
  val title: String,
  val drawableRes: Int,
  val contentDescription: String,
)

val FeatureBanners = listOf(
  BannerItem(
    id = "astral_actuation",
    title = "Astral Actuation - Ineffa",
    drawableRes = R.drawable.banner_astral_actuation,
    contentDescription = "Astral Actuation Character Event Wish-2 featuring Ineffa",
  ),
  BannerItem(
    id = "lone_light",
    title = "The Lone Light Knocks at Night - Flins",
    drawableRes = R.drawable.banner_lone_light,
    contentDescription = "The Lone Light Knocks at Night Character Event Wish featuring Flins",
  ),
)

@Composable
fun FeatureBanner(
  onExploreClick: () -> Unit = {},
  onBannerClick: (BannerItem) -> Unit = { onExploreClick() },
  modifier: Modifier = Modifier,
) {
  val pagerState = rememberPagerState(pageCount = { FeatureBanners.size })
  val scope = rememberCoroutineScope()
  val subtleHaptics = com.example.util.rememberSubtleHaptics()
  val isDragged by pagerState.interactionSource.collectIsDraggedAsState()

  // Provide subtle tactile haptic feedback when user swipes to another page
  LaunchedEffect(pagerState) {
    var isFirst = true
    snapshotFlow { pagerState.currentPage }.collect {
      if (!isFirst) {
        subtleHaptics.performToggle()
      }
      isFirst = false
    }
  }

  // Auto-advance every 5.5 seconds, automatically pausing while user is actively swiping or dragging
  LaunchedEffect(isDragged, pagerState.isScrollInProgress) {
    if (!isDragged && !pagerState.isScrollInProgress) {
      while (true) {
        delay(5500)
        val nextPage = (pagerState.currentPage + 1) % FeatureBanners.size
        pagerState.animateScrollToPage(
          page = nextPage,
          animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
        )
      }
    }
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .aspectRatio(16f / 9f)
      .shadow(12.dp, RoundedCornerShape(18.dp), spotColor = PurplePrimary.copy(alpha = 0.4f))
      .testTag("feature_banner_carousel"),
    shape = RoundedCornerShape(18.dp),
    border = BorderStroke(
      1.dp,
      Brush.linearGradient(
        listOf(
          Color(0xFF7C3AED).copy(alpha = 0.6f),
          Color(0xFF3B185F).copy(alpha = 0.4f),
          Color(0xFF1E1B4B).copy(alpha = 0.6f),
        )
      )
    ),
    colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1026))
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      // Horizontal Pager with native swipe gesture handling
      HorizontalPager(
        state = pagerState,
        modifier = Modifier
          .fillMaxSize()
          .testTag("banner_horizontal_pager")
      ) { pageIndex ->
        val banner = FeatureBanners[pageIndex]

        Box(
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(18.dp))
            .clickable {
              subtleHaptics.performCardTap()
              onBannerClick(banner)
            }
            .testTag("banner_slide_$pageIndex")
        ) {
          // Exact, unaltered banner image preserved edge-to-edge
          Image(
            painter = painterResource(id = banner.drawableRes),
            contentDescription = banner.contentDescription,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )

          // Subtle bottom vignette gradient to integrate with dark card and indicators
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(36.dp)
              .align(Alignment.BottomCenter)
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    Color.Transparent,
                    Color(0x77070B18),
                  )
                )
              )
          )
        }
      }

      // Subtle pagination indicators (dots) over the banner at the bottom center
      Row(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .padding(bottom = 10.dp)
          .background(
            color = Color(0x77070B18),
            shape = RoundedCornerShape(12.dp)
          )
          .border(
            width = 0.8.dp,
            color = Color(0x33A855F7),
            shape = RoundedCornerShape(12.dp)
          )
          .padding(horizontal = 8.dp, vertical = 4.dp)
          .testTag("pagination_indicators"),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        repeat(FeatureBanners.size) { index ->
          val isSelected = pagerState.currentPage == index

          val dotWidth by animateDpAsState(
            targetValue = if (isSelected) 18.dp else 6.dp,
            animationSpec = tween(durationMillis = 300),
            label = "dot_width_$index"
          )
          val dotColor by animateColorAsState(
            targetValue = if (isSelected) Color(0xFFC084FC) else Color(0x66FFFFFF),
            animationSpec = tween(durationMillis = 300),
            label = "dot_color_$index"
          )

          Box(
            modifier = Modifier
              .height(6.dp)
              .width(dotWidth)
              .clip(CircleShape)
              .background(dotColor)
              .clickable {
                scope.launch {
                  pagerState.animateScrollToPage(
                    page = index,
                    animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing)
                  )
                }
              }
              .testTag("dot_indicator_$index")
          )
        }
      }
    }
  }
}
