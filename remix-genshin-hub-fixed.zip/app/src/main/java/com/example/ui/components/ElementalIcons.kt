package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ElementType
import com.example.model.WeaponType

fun ElementType.getIconRes(): Int? = when (this) {
  ElementType.PYRO -> R.drawable.ic_element_pyro
  ElementType.HYDRO -> R.drawable.ic_element_hydro
  ElementType.ANEMO -> R.drawable.ic_element_anemo
  ElementType.ELECTRO -> R.drawable.ic_element_electro
  ElementType.DENDRO -> R.drawable.ic_element_dendro
  ElementType.CRYO -> R.drawable.ic_element_cryo
  ElementType.GEO -> R.drawable.ic_element_geo
  ElementType.ALL -> null
}

@Composable
fun ElementBadge(
  element: ElementType,
  modifier: Modifier = Modifier,
  size: Dp = 22.dp,
  showBackground: Boolean = true,
) {
  val iconRes = element.getIconRes()

  Box(
    modifier = modifier
      .size(size)
      .then(
        if (showBackground) {
          Modifier
            .shadow(4.dp, CircleShape, spotColor = element.color)
            .clip(CircleShape)
            .background(
              Brush.radialGradient(
                colors = listOf(
                  element.color.copy(alpha = 0.4f),
                  Color(0xFF0D1226).copy(alpha = 0.85f),
                )
              )
            )
        } else {
          Modifier
        }
      ),
    contentAlignment = Alignment.Center,
  ) {
    if (iconRes != null) {
      Image(
        painter = painterResource(id = iconRes),
        contentDescription = element.displayName,
        modifier = Modifier.size(if (showBackground) size * 0.72f else size),
        contentScale = ContentScale.Fit
      )
    } else {
      Canvas(modifier = Modifier.size(size)) {
        drawAllSymbol(element.color)
      }
    }
  }
}

private fun DrawScope.drawAllSymbol(color: Color) {
  val w = size.width
  val h = size.height
  val path = Path().apply {
    moveTo(w * 0.5f, 0f)
    lineTo(w * 0.65f, h * 0.35f)
    lineTo(w, h * 0.5f)
    lineTo(w * 0.65f, h * 0.65f)
    lineTo(w * 0.5f, h)
    lineTo(w * 0.35f, h * 0.65f)
    lineTo(0f, h * 0.5f)
    lineTo(w * 0.35f, h * 0.35f)
    close()
  }
  drawPath(path, color, style = Fill)
}

private fun DrawScope.drawPyroSymbol(color: Color) {
  val w = size.width
  val h = size.height

  // Outer flame silhouette with inner comma swirl cutout using EvenOdd fill
  val flamePath = Path().apply {
    fillType = PathFillType.EvenOdd

    // 1. Outer flame contour (Apex at top center, two side flame tongues, base at bottom)
    moveTo(w * 0.50f, h * 0.94f)
    cubicTo(w * 0.28f, h * 0.88f, w * 0.14f, h * 0.70f, w * 0.16f, h * 0.52f)
    cubicTo(w * 0.17f, h * 0.40f, w * 0.22f, h * 0.32f, w * 0.26f, h * 0.26f)
    cubicTo(w * 0.30f, h * 0.34f, w * 0.35f, h * 0.40f, w * 0.38f, h * 0.38f)
    cubicTo(w * 0.42f, h * 0.24f, w * 0.46f, h * 0.12f, w * 0.50f, h * 0.05f)
    cubicTo(w * 0.54f, h * 0.12f, w * 0.58f, h * 0.24f, w * 0.62f, h * 0.38f)
    cubicTo(w * 0.65f, h * 0.40f, w * 0.70f, h * 0.34f, w * 0.74f, h * 0.26f)
    cubicTo(w * 0.78f, h * 0.32f, w * 0.83f, h * 0.40f, w * 0.84f, h * 0.52f)
    cubicTo(w * 0.86f, h * 0.70f, w * 0.72f, h * 0.88f, w * 0.50f, h * 0.94f)
    close()

    // 2. Hollow inner swirl loop (cut out cleanly without requiring background paint)
    moveTo(w * 0.50f, h * 0.82f)
    cubicTo(w * 0.64f, h * 0.78f, w * 0.72f, h * 0.66f, w * 0.70f, h * 0.54f)
    cubicTo(w * 0.68f, h * 0.42f, w * 0.56f, h * 0.38f, w * 0.46f, h * 0.42f)
    cubicTo(w * 0.36f, h * 0.46f, w * 0.32f, h * 0.56f, w * 0.38f, h * 0.66f)
    cubicTo(w * 0.42f, h * 0.72f, w * 0.48f, h * 0.72f, w * 0.52f, h * 0.68f)
    cubicTo(w * 0.54f, h * 0.64f, w * 0.54f, h * 0.60f, w * 0.50f, h * 0.58f)
    cubicTo(w * 0.48f, h * 0.56f, w * 0.46f, h * 0.56f, w * 0.44f, h * 0.58f)
    cubicTo(w * 0.42f, h * 0.62f, w * 0.46f, h * 0.66f, w * 0.50f, h * 0.66f)
    cubicTo(w * 0.58f, h * 0.66f, w * 0.60f, h * 0.54f, w * 0.58f, h * 0.48f)
    cubicTo(w * 0.54f, h * 0.44f, w * 0.48f, h * 0.46f, w * 0.42f, h * 0.50f)
    cubicTo(w * 0.36f, h * 0.54f, w * 0.38f, h * 0.68f, w * 0.44f, h * 0.76f)
    cubicTo(w * 0.46f, h * 0.78f, w * 0.48f, h * 0.80f, w * 0.50f, h * 0.82f)
    close()
  }
  drawPath(flamePath, color, style = Fill)

  // Floating flame spark core inside the hollow swirl
  val sparkPath = Path().apply {
    moveTo(w * 0.50f, h * 0.56f)
    cubicTo(w * 0.54f, h * 0.60f, w * 0.53f, h * 0.66f, w * 0.49f, h * 0.68f)
    cubicTo(w * 0.45f, h * 0.66f, w * 0.45f, h * 0.60f, w * 0.50f, h * 0.56f)
    close()
  }
  drawPath(sparkPath, color, style = Fill)
}

private fun DrawScope.drawHydroSymbol(color: Color) {
  val w = size.width
  val h = size.height

  // Main water wave swirl curling clockwise around
  val wavePath = Path().apply {
    moveTo(w * 0.42f, h * 0.12f)
    cubicTo(w * 0.66f, h * 0.10f, w * 0.88f, h * 0.24f, w * 0.88f, h * 0.50f)
    cubicTo(w * 0.88f, h * 0.74f, w * 0.74f, h * 0.88f, w * 0.52f, h * 0.88f)
    cubicTo(w * 0.38f, h * 0.88f, w * 0.32f, h * 0.78f, w * 0.36f, h * 0.70f)
    cubicTo(w * 0.40f, h * 0.64f, w * 0.48f, h * 0.68f, w * 0.52f, h * 0.72f)
    cubicTo(w * 0.64f, h * 0.76f, w * 0.74f, h * 0.68f, w * 0.74f, h * 0.50f)
    cubicTo(w * 0.74f, h * 0.36f, w * 0.62f, h * 0.24f, w * 0.46f, h * 0.24f)
    cubicTo(w * 0.38f, h * 0.24f, w * 0.34f, h * 0.18f, w * 0.42f, h * 0.12f)
    close()
  }
  drawPath(wavePath, color, style = Fill)

  // Inner comma droplet
  val innerDroplet = Path().apply {
    moveTo(w * 0.42f, h * 0.42f)
    cubicTo(w * 0.56f, h * 0.40f, w * 0.64f, h * 0.50f, w * 0.62f, h * 0.62f)
    cubicTo(w * 0.60f, h * 0.70f, w * 0.50f, h * 0.72f, w * 0.44f, h * 0.64f)
    cubicTo(w * 0.40f, h * 0.58f, w * 0.42f, h * 0.50f, w * 0.42f, h * 0.42f)
    close()
  }
  drawPath(innerDroplet, color, style = Fill)

  // Two detached fluid droplet dots on the left
  drawCircle(
    color = color,
    radius = w * 0.075f,
    center = Offset(w * 0.18f, h * 0.38f)
  )
  drawCircle(
    color = color,
    radius = w * 0.065f,
    center = Offset(w * 0.20f, h * 0.62f)
  )
}

private fun DrawScope.drawAnemoSymbol(color: Color) {
  val w = size.width
  val h = size.height

  // Top winged plumes (feathered wings spreading out symmetrically)
  val wingsPath = Path().apply {
    moveTo(w * 0.50f, h * 0.38f)
    cubicTo(w * 0.38f, h * 0.26f, w * 0.24f, h * 0.16f, w * 0.12f, h * 0.14f)
    cubicTo(w * 0.18f, h * 0.26f, w * 0.26f, h * 0.36f, w * 0.22f, h * 0.44f)
    cubicTo(w * 0.14f, h * 0.42f, w * 0.08f, h * 0.44f, w * 0.06f, h * 0.46f)
    cubicTo(w * 0.12f, h * 0.54f, w * 0.24f, h * 0.56f, w * 0.28f, h * 0.60f)
    cubicTo(w * 0.20f, h * 0.60f, w * 0.14f, h * 0.64f, w * 0.18f, h * 0.68f)
    cubicTo(w * 0.26f, h * 0.70f, w * 0.36f, h * 0.64f, w * 0.44f, h * 0.54f)
    lineTo(w * 0.50f, h * 0.54f)
    lineTo(w * 0.56f, h * 0.54f)
    cubicTo(w * 0.64f, h * 0.64f, w * 0.74f, h * 0.70f, w * 0.82f, h * 0.68f)
    cubicTo(w * 0.86f, h * 0.64f, w * 0.80f, h * 0.60f, w * 0.72f, h * 0.60f)
    cubicTo(w * 0.76f, h * 0.56f, w * 0.88f, h * 0.54f, w * 0.94f, h * 0.46f)
    cubicTo(w * 0.92f, h * 0.44f, w * 0.86f, h * 0.42f, w * 0.78f, h * 0.44f)
    cubicTo(w * 0.74f, h * 0.36f, w * 0.82f, h * 0.26f, w * 0.88f, h * 0.14f)
    cubicTo(w * 0.76f, h * 0.16f, w * 0.62f, h * 0.26f, w * 0.50f, h * 0.38f)
    close()
  }
  drawPath(wingsPath, color, style = Fill)

  // Lower diamond crest pedestal with EvenOdd diamond cutout
  val pedestalPath = Path().apply {
    fillType = PathFillType.EvenOdd
    // Outer diamond outline
    moveTo(w * 0.50f, h * 0.56f)
    lineTo(w * 0.65f, h * 0.70f)
    lineTo(w * 0.50f, h * 0.88f)
    lineTo(w * 0.35f, h * 0.70f)
    close()

    // Inner diamond eye cutout
    moveTo(w * 0.50f, h * 0.63f)
    lineTo(w * 0.57f, h * 0.70f)
    lineTo(w * 0.50f, h * 0.79f)
    lineTo(w * 0.43f, h * 0.70f)
    close()
  }
  drawPath(pedestalPath, color, style = Fill)
}

private fun DrawScope.drawElectroSymbol(color: Color) {
  val w = size.width
  val h = size.height
  val cx = w * 0.50f
  val cy = h * 0.50f
  val r = w * 0.42f

  // 3 Tomoe swirls arranged radially at 0, 120, 240 degrees (Mitsudomoe)
  for (i in 0 until 3) {
    val baseAngle = (i * 120.0 - 90.0) * Math.PI / 180.0

    val tomoePath = Path().apply {
      val bulbDist = r * 0.42f
      val bulbX = cx + (kotlin.math.cos(baseAngle) * bulbDist).toFloat()
      val bulbY = cy + (kotlin.math.sin(baseAngle) * bulbDist).toFloat()

      moveTo(bulbX, bulbY)
      val tailAngle1 = baseAngle + 0.8
      val tailX1 = cx + (kotlin.math.cos(tailAngle1) * (r * 0.84f)).toFloat()
      val tailY1 = cy + (kotlin.math.sin(tailAngle1) * (r * 0.84f)).toFloat()

      val tailAngle2 = baseAngle + 1.6
      val tipX = cx + (kotlin.math.cos(tailAngle2) * (r * 0.95f)).toFloat()
      val tipY = cy + (kotlin.math.sin(tailAngle2) * (r * 0.95f)).toFloat()

      val hookX = cx + (kotlin.math.cos(tailAngle2 + 0.3) * (r * 0.72f)).toFloat()
      val hookY = cy + (kotlin.math.sin(tailAngle2 + 0.3) * (r * 0.72f)).toFloat()

      cubicTo(tailX1, tailY1, tipX, tipY, hookX, hookY)

      val retAngle = baseAngle + 0.9
      val retX = cx + (kotlin.math.cos(retAngle) * (r * 0.46f)).toFloat()
      val retY = cy + (kotlin.math.sin(retAngle) * (r * 0.46f)).toFloat()

      cubicTo(retX, retY, bulbX, bulbY, bulbX, bulbY)
      close()
    }
    drawPath(tomoePath, color, style = Fill)

    val bulbDist = r * 0.42f
    val bx = cx + (kotlin.math.cos(baseAngle) * bulbDist).toFloat()
    val by = cy + (kotlin.math.sin(baseAngle) * bulbDist).toFloat()
    drawCircle(color = color, radius = r * 0.22f, center = Offset(bx, by))
  }
}

private fun DrawScope.drawDendroSymbol(color: Color) {
  val w = size.width
  val h = size.height

  // Top center sprout leaf
  val topSprout = Path().apply {
    moveTo(w * 0.50f, h * 0.22f)
    cubicTo(w * 0.44f, h * 0.14f, w * 0.46f, h * 0.08f, w * 0.50f, h * 0.04f)
    cubicTo(w * 0.54f, h * 0.08f, w * 0.56f, h * 0.14f, w * 0.50f, h * 0.22f)
    close()
  }
  drawPath(topSprout, color, style = Fill)

  // Two diagonal side sprout leaves
  val leftSprout = Path().apply {
    moveTo(w * 0.34f, h * 0.22f)
    cubicTo(w * 0.26f, h * 0.18f, w * 0.18f, h * 0.18f, w * 0.12f, h * 0.22f)
    cubicTo(w * 0.18f, h * 0.26f, w * 0.26f, h * 0.26f, w * 0.34f, h * 0.22f)
    close()
  }
  drawPath(leftSprout, color, style = Fill)

  val rightSprout = Path().apply {
    moveTo(w * 0.66f, h * 0.22f)
    cubicTo(w * 0.74f, h * 0.18f, w * 0.82f, h * 0.18f, w * 0.88f, h * 0.22f)
    cubicTo(w * 0.82f, h * 0.26f, w * 0.74f, h * 0.26f, w * 0.66f, h * 0.22f)
    close()
  }
  drawPath(rightSprout, color, style = Fill)

  // Main outer heart vine
  val outerHeart = Path().apply {
    moveTo(w * 0.50f, h * 0.36f)
    cubicTo(w * 0.40f, h * 0.24f, w * 0.20f, h * 0.24f, w * 0.14f, h * 0.42f)
    cubicTo(w * 0.10f, h * 0.64f, w * 0.30f, h * 0.84f, w * 0.50f, h * 0.94f)
    cubicTo(w * 0.70f, h * 0.84f, w * 0.90f, h * 0.64f, w * 0.86f, h * 0.42f)
    cubicTo(w * 0.80f, h * 0.24f, w * 0.60f, h * 0.24f, w * 0.50f, h * 0.36f)
    close()
  }
  drawPath(outerHeart, color = color, style = Stroke(width = 2.0.dp.toPx(), cap = StrokeCap.Round))

  // Inner curling sprouting seedlings
  val leftInnerSeed = Path().apply {
    moveTo(w * 0.48f, h * 0.84f)
    cubicTo(w * 0.34f, h * 0.74f, w * 0.28f, h * 0.60f, w * 0.36f, h * 0.48f)
    cubicTo(w * 0.42f, h * 0.40f, w * 0.50f, h * 0.48f, w * 0.46f, h * 0.56f)
    cubicTo(w * 0.42f, h * 0.62f, w * 0.36f, h * 0.56f, w * 0.38f, h * 0.50f)
  }
  drawPath(leftInnerSeed, color = color, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round))

  val rightInnerSeed = Path().apply {
    moveTo(w * 0.52f, h * 0.84f)
    cubicTo(w * 0.66f, h * 0.74f, w * 0.72f, h * 0.60f, w * 0.64f, h * 0.48f)
    cubicTo(w * 0.58f, h * 0.40f, w * 0.50f, h * 0.48f, w * 0.54f, h * 0.56f)
    cubicTo(w * 0.58f, h * 0.62f, w * 0.64f, h * 0.56f, w * 0.62f, h * 0.50f)
  }
  drawPath(rightInnerSeed, color = color, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round))
}

private fun DrawScope.drawCryoSymbol(color: Color) {
  val w = size.width
  val h = size.height
  val cx = w * 0.50f
  val cy = h * 0.50f

  // 1. Top vertical diamond crystal shard
  val topShard = Path().apply {
    moveTo(cx, h * 0.06f)
    lineTo(cx + w * 0.10f, h * 0.22f)
    lineTo(cx, h * 0.36f)
    lineTo(cx - w * 0.10f, h * 0.22f)
    close()
  }
  drawPath(topShard, color, style = Fill)

  // 2. Bottom vertical diamond crystal shard
  val bottomShard = Path().apply {
    moveTo(cx, h * 0.94f)
    lineTo(cx + w * 0.10f, h * 0.78f)
    lineTo(cx, h * 0.64f)
    lineTo(cx - w * 0.10f, h * 0.78f)
    close()
  }
  drawPath(bottomShard, color, style = Fill)

  // 3. Four diagonal chevron facet points
  val angles = listOf(30.0, 150.0, 210.0, 330.0)
  for (deg in angles) {
    val rad = deg * Math.PI / 180.0
    val cos = kotlin.math.cos(rad).toFloat()
    val sin = kotlin.math.sin(rad).toFloat()
    val perpX = -sin
    val perpY = cos

    val facet = Path().apply {
      val tipDist = w * 0.42f
      val midDist = w * 0.28f
      val innerDist = w * 0.16f
      val width = w * 0.09f

      moveTo(cx + cos * tipDist, cy + sin * tipDist)
      lineTo(cx + cos * midDist + perpX * width, cy + sin * midDist + perpY * width)
      lineTo(cx + cos * innerDist, cy + sin * innerDist)
      lineTo(cx + cos * midDist - perpX * width, cy + sin * midDist - perpY * width)
      close()
    }
    drawPath(facet, color, style = Fill)
  }

  // Central 6-pointed star core
  val centerStar = Path().apply {
    for (i in 0 until 6) {
      val rad = (i * 60.0 - 90.0) * Math.PI / 180.0
      val r1 = w * 0.12f
      val x1 = cx + (kotlin.math.cos(rad) * r1).toFloat()
      val y1 = cy + (kotlin.math.sin(rad) * r1).toFloat()
      if (i == 0) moveTo(x1, y1) else lineTo(x1, y1)

      val radMid = rad + (30.0 * Math.PI / 180.0)
      val r2 = w * 0.055f
      val x2 = cx + (kotlin.math.cos(radMid) * r2).toFloat()
      val y2 = cy + (kotlin.math.sin(radMid) * r2).toFloat()
      lineTo(x2, y2)
    }
    close()
  }
  drawPath(centerStar, color, style = Fill)
}

private fun DrawScope.drawGeoSymbol(color: Color) {
  val w = size.width
  val h = size.height
  val cx = w * 0.50f
  val cy = h * 0.50f

  // Outer diamond border
  val outerDiamond = Path().apply {
    moveTo(cx, h * 0.08f)
    lineTo(w * 0.92f, cy)
    lineTo(cx, h * 0.92f)
    lineTo(w * 0.08f, cy)
    close()
  }
  drawPath(
    outerDiamond,
    color = color,
    style = Stroke(width = 2.0.dp.toPx(), cap = StrokeCap.Square, join = StrokeJoin.Miter)
  )

  // Inner stepped interlocking square spiral (Liyue Geo fret)
  val spiralPath = Path().apply {
    moveTo(cx - w * 0.12f, cy - h * 0.24f)
    lineTo(cx + w * 0.24f, cy - h * 0.12f)
    lineTo(cx + w * 0.12f, cy + h * 0.24f)
    lineTo(cx - w * 0.24f, cy + h * 0.12f)
    lineTo(cx - w * 0.12f, cy - h * 0.08f)
    lineTo(cx + w * 0.08f, cy - h * 0.02f)
  }
  drawPath(
    spiralPath,
    color = color,
    style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Square, join = StrokeJoin.Miter)
  )

  // Center solid diamond core
  val centerCore = Path().apply {
    moveTo(cx, cy - h * 0.07f)
    lineTo(cx + w * 0.07f, cy)
    lineTo(cx, cy + h * 0.07f)
    lineTo(cx - w * 0.07f, cy)
    close()
  }
  drawPath(centerCore, color, style = Fill)
}

@Composable
fun WeaponIcon(
  weapon: WeaponType,
  modifier: Modifier = Modifier,
  color: Color = Color(0xFF94A3B8),
  size: Dp = 12.dp,
) {
  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    when (weapon) {
      WeaponType.SWORD -> {
        // Slender diagonal blade
        drawLine(
          color = color,
          start = Offset(w * 0.15f, h * 0.85f),
          end = Offset(w * 0.85f, h * 0.15f),
          strokeWidth = 1.8.dp.toPx(),
          cap = StrokeCap.Round
        )
        drawLine(
          color = color,
          start = Offset(w * 0.2f, h * 0.65f),
          end = Offset(w * 0.35f, h * 0.8f),
          strokeWidth = 2.2.dp.toPx(),
          cap = StrokeCap.Round
        )
      }
      WeaponType.CLAYMORE -> {
        // Broad two-handed greatsword
        val path = Path().apply {
          moveTo(w * 0.15f, h * 0.85f)
          lineTo(w * 0.25f, h * 0.95f)
          lineTo(w * 0.4f, h * 0.8f)
          lineTo(w * 0.85f, h * 0.1f)
          lineTo(w * 0.95f, h * 0.2f)
          lineTo(w * 0.8f, h * 0.4f)
          close()
        }
        drawPath(path, color, style = Fill)
      }
      WeaponType.POLEARM -> {
        // Spear shaft with pointed spearhead
        drawLine(
          color = color,
          start = Offset(w * 0.1f, h * 0.9f),
          end = Offset(w * 0.75f, h * 0.25f),
          strokeWidth = 1.5.dp.toPx(),
          cap = StrokeCap.Round
        )
        val spearHead = Path().apply {
          moveTo(w * 0.65f, h * 0.35f)
          lineTo(w * 0.95f, h * 0.05f)
          lineTo(w * 0.85f, h * 0.45f)
          close()
        }
        drawPath(spearHead, color, style = Fill)
      }
      WeaponType.BOW -> {
        // Curved bow arc and string
        val arc = Path().apply {
          moveTo(w * 0.2f, h * 0.15f)
          cubicTo(w * 0.9f, h * 0.3f, w * 0.9f, h * 0.7f, w * 0.2f, h * 0.85f)
        }
        drawPath(arc, color, style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round))
        drawLine(
          color = color.copy(alpha = 0.6f),
          start = Offset(w * 0.2f, h * 0.15f),
          end = Offset(w * 0.2f, h * 0.85f),
          strokeWidth = 1.dp.toPx()
        )
      }
      WeaponType.CATALYST -> {
        // Arcane floating astrolabe diamond
        val gem = Path().apply {
          moveTo(w * 0.5f, 0.1f * h)
          lineTo(w * 0.9f, h * 0.5f)
          lineTo(w * 0.5f, h * 0.9f)
          lineTo(w * 0.1f, h * 0.5f)
          close()
        }
        drawPath(gem, color, style = Stroke(width = 1.5.dp.toPx()))
        drawCircle(color = color, radius = w * 0.15f, center = Offset(w * 0.5f, h * 0.5f))
      }
    }
  }
}
