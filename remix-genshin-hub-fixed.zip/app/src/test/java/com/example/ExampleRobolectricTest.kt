package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Genshin HUB", appName)
  }

  @Test
  fun `load genshin_hub_logo drawable`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val drawable = androidx.core.content.ContextCompat.getDrawable(context, R.drawable.genshin_hub_logo_v2)
    org.junit.Assert.assertNotNull(drawable)
    println("Drawable v2 loaded successfully: width=${drawable?.intrinsicWidth}, height=${drawable?.intrinsicHeight}")
  }
}
