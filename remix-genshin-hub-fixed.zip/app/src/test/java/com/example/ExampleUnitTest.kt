package com.example

import com.example.model.CharacterDetailProvider
import com.example.model.SampleCharacters
import com.example.model.TalentType
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testCharacterDetailExtendedData() {
    val ineffa = SampleCharacters.list.first { it.id == "ineffa" }
    val profile = CharacterDetailProvider.getProfile(ineffa)

    // Constellations
    assertEquals(6, profile.constellations.size)
    assertEquals("Resonant Capacitor", profile.constellations[0].name)
    assertEquals(1, profile.constellations[0].level)

    // Talents
    assertTrue(profile.talents.any { it.type == TalentType.NORMAL_ATTACK })
    assertTrue(profile.talents.any { it.type == TalentType.ELEMENTAL_SKILL })
    assertTrue(profile.talents.any { it.type == TalentType.ELEMENTAL_BURST })
    assertTrue(profile.talents.any { it.type == TalentType.PASSIVE_1 })

    // Base Stats calculation
    val statsLv90 = CharacterDetailProvider.calculateStats(ineffa, 90)
    assertEquals("${ineffa.baseHp}", statsLv90["Base HP"])
    assertEquals("${ineffa.baseAtk}", statsLv90["Base ATK"])
    assertEquals("${profile.baseDef}", statsLv90["Base DEF"])
    assertEquals("+38.4%", statsLv90["Ascension Stat"])
    assertEquals("88.4%", statsLv90["CRIT DMG"])

    val statsLv1 = CharacterDetailProvider.calculateStats(ineffa, 1)
    val hpLv1 = statsLv1["Base HP"]?.toIntOrNull() ?: 0
    assertTrue(hpLv1 in 1000..1500)
  }

  @Test
  fun testActivePartyLineupCapacity() {
    val characters = SampleCharacters.list
    val party = mutableListOf<com.example.model.Character>()

    // Adding up to 4 characters
    for (i in 0 until 4) {
      party.add(characters[i])
    }
    assertEquals(4, party.size)

    // Remove one character
    party.removeIf { it.id == characters[0].id }
    assertEquals(3, party.size)
    assertFalse(party.any { it.id == characters[0].id })
  }

  @Test
  fun testCharacterEntityFieldsAndMapping() {
    val entity = com.example.data.local.CharacterEntity(
      id = "raiden_shogun",
      name = "Raiden Shogun",
      element = "ELECTRO",
      rarity = 5,
      weaponType = "POLEARM",
      title = "Plane of Euthymia",
      role = "Sub-DPS / Battery"
    )

    // Verify entity fields
    assertEquals("Raiden Shogun", entity.name)
    assertEquals("ELECTRO", entity.element)
    assertEquals(5, entity.rarity)
    assertEquals("POLEARM", entity.weaponType)

    // Verify toDomain conversion
    val domainModel = entity.toDomain()
    assertEquals("Raiden Shogun", domainModel.name)
    assertEquals(com.example.model.ElementType.ELECTRO, domainModel.element)
    assertEquals(5, domainModel.rarity)
    assertEquals(com.example.model.WeaponType.POLEARM, domainModel.weapon)

    // Verify fromDomain conversion
    val entityRecreated = com.example.data.local.CharacterEntity.fromDomain(domainModel)
    assertEquals(entity.id, entityRecreated.id)
    assertEquals(entity.name, entityRecreated.name)
    assertEquals(entity.element, entityRecreated.element)
    assertEquals(entity.rarity, entityRecreated.rarity)
    assertEquals(entity.weaponType, entityRecreated.weaponType)
  }
}

