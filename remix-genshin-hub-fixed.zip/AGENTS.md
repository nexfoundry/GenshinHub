# Persistent Instructions

## Asset Rules (CRITICAL)

Use the assets the user uploads as the ONLY visual source for character artwork, elemental icons, and banners.

### Character Artwork
- Do NOT generate AI character portraits.
- Do NOT create placeholder characters.
- Do NOT use generic avatars, illustrations, colored heads, silhouettes, or generated faces.
- Use the exact character images/assets provided by the user.
- Preserve their original appearance and quality.
- If an asset is missing, leave the corresponding character image area empty or use a clearly marked missing-asset state rather than inventing an image.

### Element Icons
- Do NOT generate, redraw, recreate, trace, or redesign the elemental icons.
- Use the exact 7 elemental icon assets the user uploads (Pyro, Hydro, Anemo, Electro, Dendro, Cryo, Geo).
- Preserve their original shapes, symbols, proportions, and colors.
- Only resize the uploaded icons proportionally to fit the UI.
- Do not apply filters that alter their colors or shapes.

### Banner Images
- Use the exact banner images uploaded.
- Do NOT generate replacement banners.
- Do NOT recreate or redesign the artwork.
- Preserve the original artwork and aspect ratio.
- Only crop/scale it responsively when necessary without stretching.

The uploaded assets are authoritative. If an asset exists in the uploaded files, NEVER substitute it with an AI-generated or placeholder version.
