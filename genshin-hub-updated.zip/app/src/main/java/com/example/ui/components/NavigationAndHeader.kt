package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ElementType
import com.example.ui.theme.BackgroundNavy
import com.example.ui.theme.BottomNavBackground
import com.example.ui.theme.BottomNavBorder
import com.example.ui.theme.ChipBackground
import com.example.ui.theme.ChipBorder
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SearchBarBackground
import com.example.ui.theme.SearchBarBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

// -------------------------------------------------------------
// 1. GENSHIN HUB STAR LOGO EMBLEM
// -------------------------------------------------------------
@Composable
fun GenshinStarLogo(
  modifier: Modifier = Modifier,
  size: Dp = 32.dp,
) {
  androidx.compose.foundation.Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f
    val cy = h / 2f

    // Soft radiant violet aura
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(
          Color(0x88A855F7),
          Color(0x337C3AED),
          Color.Transparent
        ),
        center = Offset(cx, cy),
        radius = w * 0.75f
      )
    )

    // 4 Cardinal Sharp Points (North, South, East, West)
    val cardinalPath = androidx.compose.ui.graphics.Path().apply {
      moveTo(cx, cy - h * 0.50f)
      cubicTo(cx + w * 0.07f, cy - h * 0.12f, cx + w * 0.12f, cy - h * 0.07f, cx + w * 0.50f, cy)
      cubicTo(cx + w * 0.12f, cy + h * 0.07f, cx + w * 0.07f, cy + h * 0.12f, cx, cy + h * 0.50f)
      cubicTo(cx - w * 0.07f, cy + h * 0.12f, cx - w * 0.12f, cy + h * 0.07f, cx - w * 0.50f, cy)
      cubicTo(cx - w * 0.12f, cy - h * 0.07f, cx - w * 0.07f, cy - h * 0.12f, cx, cy - h * 0.50f)
      close()
    }
    drawPath(
      cardinalPath,
      brush = Brush.radialGradient(
        colors = listOf(Color.White, Color(0xFFE9D5FF), Color(0xFFA855F7)),
        center = Offset(cx, cy),
        radius = w * 0.48f
      )
    )

    // 4 Diagonal Points (NE, SE, SW, NW)
    val diagonalPath = androidx.compose.ui.graphics.Path().apply {
      val dLen = w * 0.28f
      val dWidth = w * 0.06f
      moveTo(cx + dLen, cy - dLen)
      lineTo(cx + dWidth, cy)
      lineTo(cx + dLen, cy + dLen)
      lineTo(cx, cy + dWidth)
      lineTo(cx - dLen, cy + dLen)
      lineTo(cx - dWidth, cy)
      lineTo(cx - dLen, cy - dLen)
      lineTo(cx, cy - dWidth)
      close()
    }
    drawPath(diagonalPath, color = Color(0xFFF3E8FF))

    // Bright Center Diamond
    val centerDiamond = androidx.compose.ui.graphics.Path().apply {
      val c = w * 0.11f
      moveTo(cx, cy - c)
      lineTo(cx + c, cy)
      lineTo(cx, cy + c)
      lineTo(cx - c, cy)
      close()
    }
    drawPath(centerDiamond, color = Color.White)
  }
}

// -------------------------------------------------------------
// 2. PAGODA & PURPLE NEBULA CELESTIAL ARTWORK
// -------------------------------------------------------------
@Composable
fun PagodaNebulaArtwork(
  modifier: Modifier = Modifier,
) {
  androidx.compose.foundation.Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    val cx = w * 0.38f
    val cy = h * 0.48f

    // Luminous purple celestial radial glow / nebula
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(
          Color(0x997C3AED), // vibrant violet core
          Color(0x664C1D95),
          Color(0x221E1B4B),
          Color.Transparent
        ),
        center = Offset(cx, cy),
        radius = w * 0.55f
      )
    )

    // Mountain crags & mist in foreground under pagoda
    val mountainPath = androidx.compose.ui.graphics.Path().apply {
      moveTo(0f, h)
      cubicTo(w * 0.15f, h * 0.88f, w * 0.25f, h * 0.82f, cx, h * 0.84f)
      cubicTo(w * 0.52f, h * 0.86f, w * 0.70f, h * 0.80f, w, h * 0.92f)
      lineTo(w, h)
      close()
    }
    drawPath(mountainPath, color = Color(0xFF060A1A))

    val roofColor = Color(0xFF0A0F26)
    val bodyColor = Color(0xFF090E22)

    // Pagoda Spire
    drawLine(
      color = Color(0xFFC084FC),
      start = Offset(cx, cy - h * 0.38f),
      end = Offset(cx, cy - h * 0.18f),
      strokeWidth = 1.6.dp.toPx()
    )
    drawCircle(
      color = Color(0xFFE9D5FF),
      radius = 1.5.dp.toPx(),
      center = Offset(cx, cy - h * 0.38f)
    )

    // Tier 1 Roof
    val tier1Roof = androidx.compose.ui.graphics.Path().apply {
      moveTo(cx, cy - h * 0.18f)
      cubicTo(cx - w * 0.08f, cy - h * 0.15f, cx - w * 0.14f, cy - h * 0.14f, cx - w * 0.16f, cy - h * 0.12f)
      lineTo(cx - w * 0.12f, cy - h * 0.09f)
      lineTo(cx + w * 0.12f, cy - h * 0.09f)
      lineTo(cx + w * 0.16f, cy - h * 0.12f)
      cubicTo(cx + w * 0.14f, cy - h * 0.14f, cx + w * 0.08f, cy - h * 0.15f, cx, cy - h * 0.18f)
      close()
    }
    drawPath(tier1Roof, color = roofColor)

    // Tier 2 Roof
    val tier2Roof = androidx.compose.ui.graphics.Path().apply {
      moveTo(cx, cy - h * 0.08f)
      cubicTo(cx - w * 0.12f, cy - h * 0.05f, cx - w * 0.20f, cy - h * 0.04f, cx - w * 0.24f, cy - h * 0.01f)
      lineTo(cx - w * 0.18f, cy + h * 0.04f)
      lineTo(cx + w * 0.18f, cy + h * 0.04f)
      lineTo(cx + w * 0.24f, cy - h * 0.01f)
      cubicTo(cx + w * 0.20f, cy - h * 0.04f, cx + w * 0.12f, cy - h * 0.05f, cx, cy - h * 0.08f)
      close()
    }
    drawPath(tier2Roof, color = roofColor)

    // Tier 3 Roof
    val tier3Roof = androidx.compose.ui.graphics.Path().apply {
      moveTo(cx, cy + h * 0.05f)
      cubicTo(cx - w * 0.16f, cy + h * 0.09f, cx - w * 0.28f, cy + h * 0.10f, cx - w * 0.32f, cy + h * 0.14f)
      lineTo(cx - w * 0.24f, cy + h * 0.20f)
      lineTo(cx + w * 0.24f, cy + h * 0.20f)
      lineTo(cx + w * 0.32f, cy + h * 0.14f)
      cubicTo(cx + w * 0.28f, cy + h * 0.10f, cx + w * 0.16f, cy + h * 0.09f, cx, cy + h * 0.05f)
      close()
    }
    drawPath(tier3Roof, color = roofColor)

    // Pagoda base structure
    drawRect(
      color = bodyColor,
      topLeft = Offset(cx - w * 0.13f, cy + h * 0.20f),
      size = androidx.compose.ui.geometry.Size(w * 0.26f, h * 0.16f)
    )

    // Delicate starlight sparkles
    drawMicroSparkle(Offset(cx - w * 0.28f, cy - h * 0.25f), 3.5.dp.toPx(), Color(0xFFE9D5FF))
    drawMicroSparkle(Offset(cx + w * 0.26f, cy - h * 0.28f), 4.0.dp.toPx(), Color(0xFFFFFFFF))
    drawMicroSparkle(Offset(cx - w * 0.18f, cy + h * 0.28f), 2.5.dp.toPx(), Color(0xFFC084FC))
    drawMicroSparkle(Offset(cx + w * 0.32f, cy + h * 0.18f), 3.0.dp.toPx(), Color(0xFFE9D5FF))
  }
}

private fun DrawScope.drawMicroSparkle(
  center: Offset,
  size: Float,
  color: Color,
) {
  val path = androidx.compose.ui.graphics.Path().apply {
    moveTo(center.x, center.y - size)
    cubicTo(center.x, center.y, center.x, center.y, center.x + size, center.y)
    cubicTo(center.x, center.y, center.x, center.y, center.x, center.y + size)
    cubicTo(center.x, center.y, center.x, center.y, center.x - size, center.y)
    cubicTo(center.x, center.y, center.x, center.y, center.x, center.y - size)
    close()
  }
  drawPath(path, color = color)
}

// -------------------------------------------------------------
// 3. TOP HEADER (EXACTLY MATCHING REFERENCE IMAGE)
// -------------------------------------------------------------
@Composable
fun TopHeader(
  onMenuClick: () -> Unit = {},
  onSearchClick: () -> Unit = {},
  onFavoritesClick: () -> Unit = {},
  showFavoritesOnly: Boolean = false,
  selectedCategory: String = "CHARACTERS",
  onCategoryClick: (String) -> Unit = {},
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(BackgroundNavy)
      .padding(top = 4.dp, bottom = 2.dp)
  ) {
    // Top Row: Hamburger + Logo + Notifications Bell & Favorites Star
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left: Circular Hamburger Button + Logo Branding
      Row(verticalAlignment = Alignment.CenterVertically) {
        // Circular Hamburger Button
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFF0C132B).copy(alpha = 0.85f))
            .border(1.dp, Color(0xFF202B50), CircleShape)
            .clickable { onMenuClick() }
            .testTag("btn_menu"),
          contentAlignment = Alignment.Center
        ) {
          Column(
            verticalArrangement = Arrangement.spacedBy(3.2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(modifier = Modifier.width(16.dp).height(1.8.dp).background(Color.White, RoundedCornerShape(1.dp)))
            Box(modifier = Modifier.width(16.dp).height(1.8.dp).background(Color.White, RoundedCornerShape(1.dp)))
            Box(modifier = Modifier.width(16.dp).height(1.8.dp).background(Color.White, RoundedCornerShape(1.dp)))
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Genshin HUB Branding Title with Star
        Row(verticalAlignment = Alignment.CenterVertically) {
          GenshinStarLogo(size = 30.dp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Genshin",
              color = Color.White,
              fontFamily = FontFamily.Serif,
              fontStyle = FontStyle.Italic,
              fontWeight = FontWeight.Bold,
              fontSize = 20.sp,
              lineHeight = 22.sp,
              letterSpacing = 0.4.sp
            )
            Text(
              text = "H U B",
              color = Color(0xFFC084FC),
              fontSize = 9.5.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 4.2.sp,
              lineHeight = 11.sp
            )
          }
        }
      }

      // Right: Notifications Bell Button + Favorites Star Button
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Notification Bell Button
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFF0C132B).copy(alpha = 0.85f))
            .border(1.dp, Color(0xFF202B50), CircleShape)
            .clickable { onSearchClick() }
            .testTag("btn_header_search"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Outlined.Notifications,
            contentDescription = "Notifications",
            tint = Color(0xFFE2E8F0),
            modifier = Modifier.size(19.dp)
          )
        }

        // Favorites Star Action Button
        Box(
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(
              if (showFavoritesOnly) Color(0xFF381E52) else Color(0xFF0C132B).copy(alpha = 0.85f)
            )
            .border(
              1.dp,
              if (showFavoritesOnly) PurplePrimary else Color(0xFF202B50),
              CircleShape
            )
            .clickable { onFavoritesClick() }
            .testTag("btn_header_favorites"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (showFavoritesOnly) Icons.Rounded.Star else Icons.Outlined.StarBorder,
            contentDescription = "Favorites",
            tint = if (showFavoritesOnly) Color(0xFFFBBF24) else Color(0xFFE2E8F0),
            modifier = Modifier.size(19.dp)
          )
        }
      }
    }
  }
}

// -------------------------------------------------------------
// 4. ELEMENT FILTER BAR & SEARCH BAR
// -------------------------------------------------------------
private val FilterElements = listOf(
  ElementType.PYRO,
  ElementType.HYDRO,
  ElementType.ANEMO,
  ElementType.ELECTRO,
  ElementType.DENDRO,
  ElementType.CRYO,
  ElementType.GEO,
)

@Composable
fun SearchAndFilterBar(
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  selectedElement: ElementType?,
  onElementSelect: (ElementType) -> Unit,
  onFilterClick: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val focusManager = LocalFocusManager.current
  val haptic = LocalHapticFeedback.current
  val view = LocalView.current

  Column(modifier = modifier.fillMaxWidth()) {
    // Top Row: Search Input Field
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(42.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(SearchBarBackground)
          .border(1.dp, SearchBarBorder, RoundedCornerShape(12.dp))
          .padding(horizontal = 12.dp),
        contentAlignment = Alignment.CenterStart
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Box(modifier = Modifier.weight(1f)) {
            if (searchQuery.isEmpty()) {
              Text(
                text = "Search characters...",
                color = TextMuted,
                fontSize = 13.5.sp
              )
            }
            BasicTextField(
              value = searchQuery,
              onValueChange = onSearchQueryChange,
              textStyle = TextStyle(
                color = TextPrimary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Normal
              ),
              cursorBrush = SolidColor(PurpleLight),
              singleLine = true,
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
              keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("search_text_input")
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Exactly 7 elemental icons in one single horizontal row:
    // Pyro, Hydro, Anemo, Electro, Dendro, Cryo, Geo
    // Equal circular size, equal spacing, same visual weight, equal horizontal distribution across available width
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      FilterElements.forEach { element ->
        val isSelected = selectedElement == element
        val elementColor = element.color
        val iconRes = element.getIconRes()

        Box(
          modifier = Modifier
            .weight(1f),
          contentAlignment = Alignment.Center
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .then(
                if (isSelected) {
                  Modifier
                    .shadow(
                      elevation = 6.dp,
                      shape = CircleShape,
                      spotColor = elementColor
                    )
                    .clip(CircleShape)
                    .background(
                      Brush.radialGradient(
                        colors = listOf(
                          elementColor.copy(alpha = 0.35f),
                          Color(0xFF141A32)
                        )
                      )
                    )
                    .border(
                      width = 2.dp,
                      color = elementColor,
                      shape = CircleShape
                    )
                } else {
                  Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF14192F))
                    .border(
                      width = 1.dp,
                      color = Color(0xFF232B4A),
                      shape = CircleShape
                    )
                }
              )
              .clickable {
                val performed = view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (!performed) {
                  haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
                onElementSelect(element)
              }
              .testTag("chip_element_${element.name.lowercase()}"),
            contentAlignment = Alignment.Center
          ) {
            if (iconRes != null) {
              Image(
                painter = painterResource(id = iconRes),
                contentDescription = element.displayName,
                modifier = Modifier.size(24.dp),
                contentScale = ContentScale.Fit
              )
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// 5. BOTTOM NAVIGATION BAR (EXACTLY MATCHING REFERENCE IMAGE)
// -------------------------------------------------------------
enum class BottomNavItem(val title: String) {
  CHARACTERS("Characters"),
  WEAPONS("Weapons"),
  ARTIFACTS("Artifacts"),
  TEAMS("Teams"),
  TIER_LIST("Tier List"),
}

@Composable
fun GenshinBottomNav(
  selectedItem: BottomNavItem,
  onItemSelected: (BottomNavItem) -> Unit,
  modifier: Modifier = Modifier,
) {
  val view = LocalView.current
  val haptic = LocalHapticFeedback.current
  val items = remember { BottomNavItem.values() }
  val selectedIndex = items.indexOf(selectedItem).coerceAtLeast(0)

  Box(
    modifier = modifier
      .fillMaxWidth()
      .windowInsetsPadding(WindowInsets.navigationBars)
      .padding(horizontal = 16.dp, vertical = 6.dp),
    contentAlignment = Alignment.Center
  ) {
    // Outer floating pill container:
    // Sleek 58.dp height, deep translucent navy glass, soft border, delicate shadow
    BoxWithConstraints(
      modifier = Modifier
        .widthIn(max = 440.dp)
        .fillMaxWidth()
        .height(58.dp)
        .shadow(
          elevation = 8.dp,
          shape = RoundedCornerShape(29.dp),
          spotColor = Color(0x30020617),
          ambientColor = Color(0x18000000)
        )
        .clip(RoundedCornerShape(29.dp))
        .background(
          Brush.verticalGradient(
            listOf(
              Color(0xE6101935), // translucent deep navy top
              Color(0xF20B1124)  // slightly deeper translucent navy bottom
            )
          )
        )
        .border(
          width = 1.dp,
          color = Color(0x286378B5), // delicate celestial navy border
          shape = RoundedCornerShape(29.dp)
        )
        .padding(horizontal = 6.dp, vertical = 5.dp),
      contentAlignment = Alignment.CenterStart
    ) {
      val availableWidth = maxWidth

      // Dynamic animated weights for smooth, continuous rebalancing
      val weights = items.mapIndexed { index, item ->
        val isTarget = index == selectedIndex
        animateFloatAsState(
          targetValue = if (isTarget) 1.62f else 1.0f,
          animationSpec = spring(
            dampingRatio = 0.85f,
            stiffness = Spring.StiffnessMediumLow
          ),
          label = "weight_${item.name}"
        ).value
      }

      val totalWeight = weights.sum()

      // Continuous widths and centers for all 5 item slots
      val itemWidths = remember(weights, availableWidth) {
        weights.map { w -> availableWidth * (w / totalWeight) }
      }

      val itemCenters = remember(itemWidths) {
        val centers = mutableListOf<Dp>()
        var acc = 0.dp
        for (w in itemWidths) {
          centers.add(acc + w / 2)
          acc += w
        }
        centers
      }

      // Smooth traveling pill indicator center
      val targetPillCenter = itemCenters.getOrElse(selectedIndex) { availableWidth / 2 }

      val animatedPillCenter by animateDpAsState(
        targetValue = targetPillCenter,
        animationSpec = spring(
          dampingRatio = 0.82f,
          stiffness = Spring.StiffnessMediumLow
        ),
        label = "pill_center"
      )

      // Active progress per item for label expansion/fade, icon tint
      val activeProgressList = items.mapIndexed { index, item ->
        val isSelected = index == selectedIndex
        animateFloatAsState(
          targetValue = if (isSelected) 1f else 0f,
          animationSpec = tween(
            durationMillis = 240,
            easing = FastOutSlowInEasing
          ),
          label = "active_progress_${item.name}"
        ).value
      }

      // Active pill width: contracts slightly during transit, smoothly expands to fit icon + label at resting destination
      val currentActiveProgress = activeProgressList[selectedIndex]
      val baseActiveSlotWidth = itemWidths.getOrElse(selectedIndex) { 88.dp }
      val restingPillWidth = (baseActiveSlotWidth - 8.dp).coerceIn(74.dp, 100.dp)
      val compactPillWidth = 42.dp

      val animatedPillWidth by animateDpAsState(
        targetValue = androidx.compose.ui.unit.lerp(compactPillWidth, restingPillWidth, currentActiveProgress),
        animationSpec = spring(
          dampingRatio = 0.82f,
          stiffness = Spring.StiffnessMediumLow
        ),
        label = "pill_width"
      )

      val leftOffset = (animatedPillCenter - animatedPillWidth / 2).coerceAtLeast(0.dp)

      // 1. Sliding Active Pill Indicator (rendered behind the item icons)
      Box(
        modifier = Modifier
          .offset(x = leftOffset)
          .width(animatedPillWidth)
          .height(40.dp)
          .align(Alignment.CenterStart)
          .shadow(
            elevation = 4.dp,
            shape = RoundedCornerShape(20.dp),
            spotColor = Color(0x33A855F7),
            ambientColor = Color(0x18A855F7)
          )
          .clip(RoundedCornerShape(20.dp))
          .background(
            Brush.horizontalGradient(
              listOf(
                Color(0xFF581C87), // elegant royal purple
                Color(0xFF3B0764)  // deep lavender purple
              )
            )
          )
          .border(
            width = 1.dp,
            brush = Brush.verticalGradient(
              listOf(
                Color(0x66C084FC), // soft lavender top line
                Color(0x22A855F7)
              )
            ),
            shape = RoundedCornerShape(20.dp)
          )
      )

      // 2. Row of 5 Navigation Slots
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .fillMaxHeight(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        items.forEachIndexed { index, item ->
          val isSelected = index == selectedIndex
          val weight = weights[index]
          val activeProgress = activeProgressList[index]

          val iconRes = when (item) {
            BottomNavItem.CHARACTERS -> R.drawable.ic_nav_characters
            BottomNavItem.WEAPONS -> R.drawable.ic_nav_weapons
            BottomNavItem.ARTIFACTS -> R.drawable.ic_nav_artifacts
            BottomNavItem.TEAMS -> R.drawable.ic_nav_teams
            BottomNavItem.TIER_LIST -> R.drawable.ic_nav_tier_list
          }

          Box(
            modifier = Modifier
              .weight(weight)
              .fillMaxHeight()
              .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
              ) {
                val performed = view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (!performed) {
                  haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
                onItemSelected(item)
              }
              .testTag("nav_item_${item.name.lowercase()}"),
            contentAlignment = Alignment.Center
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center,
              modifier = Modifier.padding(horizontal = 4.dp)
            ) {
              Icon(
                painter = painterResource(id = iconRes),
                contentDescription = item.title,
                tint = androidx.compose.ui.graphics.lerp(
                  Color(0xFF8E9BB5), // refined inactive silvery slate
                  Color(0xFFFAF5FF), // crisp active white-lavender
                  activeProgress
                ),
                modifier = Modifier.size(if (isSelected) 22.dp else 20.dp)
              )

              if (activeProgress > 0.01f) {
                Spacer(modifier = Modifier.width((5 * activeProgress).dp))
                Text(
                  text = item.title,
                  color = Color(0xFFFAF5FF).copy(alpha = activeProgress),
                  fontSize = 11.5.sp,
                  fontWeight = FontWeight.SemiBold,
                  letterSpacing = 0.15.sp,
                  maxLines = 1,
                  overflow = TextOverflow.Clip,
                  modifier = Modifier.graphicsLayer {
                    alpha = activeProgress
                    translationX = (1f - activeProgress) * 6f
                  }
                )
              }
            }
          }
        }
      }
    }
  }
}

