package com.genshinhub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050711)
private val Surface = Color(0xFF0B1020)
private val Surface2 = Color(0xFF11172A)
private val Purple = Color(0xFF9B6CFF)
private val Text = Color(0xFFF3F1FF)
private val Muted = Color(0xFF8D91A8)

data class Character(
    val name: String,
    val element: String,
    val weapon: String,
    val stars: Int,
    val tone: Color
)

private val characters = listOf(
    Character("Alyosha", "Electro", "Sword", 5, Color(0xFF6B4D9E)),
    Character("Varka", "Geo", "Claymore", 5, Color(0xFF8E6C48)),
    Character("Columbina", "Hydro", "Polearm", 5, Color(0xFF3B617B)),
    Character("Dainsleif", "Electro", "Sword", 5, Color(0xFF4B3D79)),
    Character("Nelu", "Dendro", "Catalyst", 5, Color(0xFF4F6D45)),
    Character("Iansan", "Pyro", "Polearm", 4, Color(0xFF9B613B)),
    Character("Mavuika", "Pyro", "Claymore", 5, Color(0xFF8B4A3C)),
    Character("Furina", "Hydro", "Sword", 5, Color(0xFF365D8C)),
    Character("Xilonen", "Geo", "Sword", 5, Color(0xFF6B6543))
)

private val elements = listOf("All", "Pyro", "Hydro", "Anemo", "Electro", "Geo", "Dendro", "Cryo")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GenshinHubApp() }
    }
}

@Composable
fun GenshinHubApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Surface,
            primary = Purple,
            onBackground = Text,
            onSurface = Text
        )
    ) {
        var selectedElement by remember { mutableStateOf("All") }
        var query by remember { mutableStateOf("") }
        var favorites by remember { mutableStateOf(setOf<String>()) }
        var tab by remember { mutableStateOf(0) }

        val filtered = characters.filter {
            (selectedElement == "All" || it.element == selectedElement) &&
            it.name.contains(query, ignoreCase = true)
        }

        Scaffold(
            containerColor = Bg,
            bottomBar = {
                BottomBar(tab) { tab = it }
            }
        ) { padding ->
            if (tab == 0) {
                HomeScreen(
                    modifier = Modifier.padding(padding),
                    query = query,
                    onQuery = { query = it },
                    selectedElement = selectedElement,
                    onElement = { selectedElement = it },
                    characters = filtered,
                    favorites = favorites,
                    onFavorite = { name ->
                        favorites = if (name in favorites) favorites - name else favorites + name
                    }
                )
            } else {
                PlaceholderScreen(
                    modifier = Modifier.padding(padding),
                    title = listOf("Characters", "Weapons", "Artifacts", "Teams", "More")[tab]
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    query: String,
    onQuery: (String) -> Unit,
    selectedElement: String,
    onElement: (String) -> Unit,
    characters: List<Character>,
    favorites: Set<String>,
    onFavorite: (String) -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Bg)
            .padding(horizontal = 14.dp)
    ) {
        Spacer(Modifier.height(10.dp))
        Header()
        Spacer(Modifier.height(18.dp))
        HeroBanner()
        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            SearchBox(query, onQuery, Modifier.weight(1f))
            IconButton(
                onClick = {},
                modifier = Modifier
                    .size(78.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Surface2)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Tune, null, tint = Text, modifier = Modifier.size(22.dp))
                    Text("Filter", fontSize = 12.sp, color = Text)
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            elements.forEach { element ->
                ElementChip(element, element == selectedElement) { onElement(element) }
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "All Characters",
                fontSize = 23.sp,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Text("${characters.size} Characters", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.GridView, null, tint = Purple, modifier = Modifier.size(26.dp))
        }

        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(characters) { c ->
                CharacterCard(c, c.name in favorites) { onFavorite(c.name) }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        RoundIcon(Icons.Default.Menu)
        Spacer(Modifier.width(12.dp))
        Icon(Icons.Default.AutoAwesome, null, tint = Purple, modifier = Modifier.size(27.dp))
        Spacer(Modifier.width(7.dp))
        Column {
            Text("Genshin", fontSize = 27.sp, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Medium)
            Text("H U B", fontSize = 12.sp, color = Purple, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.weight(1f))
        RoundIcon(Icons.Default.Search)
        Spacer(Modifier.width(8.dp))
        RoundIcon(Icons.Default.StarBorder)
    }
}

@Composable
private fun RoundIcon(icon: ImageVector) {
    Box(
        modifier = Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(17.dp))
            .background(Surface2),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = Text, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun HeroBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(185.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF201642), Color(0xFF5E3A91), Color(0xFF111426))
                )
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.45f)
                .align(Alignment.CenterEnd)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color(0xFF8B62D0))
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(18.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                color = Purple.copy(alpha = .25f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Version 5.6", modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp), fontSize = 11.sp)
            }
            Column {
                Text("New Adventures,\nNew Legends", fontSize = 24.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                Text("Discover new characters and build\nyour ultimate team", color = Color(0xFFD7D4E4), fontSize = 11.sp)
            }
            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(containerColor = Purple),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Explore Now")
            }
        }
    }
}

@Composable
private fun SearchBox(value: String, onValueChange: (String) -> Unit, modifier: Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.height(64.dp),
        singleLine = true,
        placeholder = { Text("Search characters...", color = Muted) },
        leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Purple,
            unfocusedBorderColor = Color(0xFF202A43),
            focusedContainerColor = Surface,
            unfocusedContainerColor = Surface
        ),
        shape = RoundedCornerShape(18.dp)
    )
}

@Composable
private fun ElementChip(name: String, selected: Boolean, onClick: () -> Unit) {
    val icon = when (name) {
        "Pyro" -> "🔥"
        "Hydro" -> "≋"
        "Anemo" -> "≋"
        "Electro" -> "ϟ"
        "Geo" -> "◆"
        "Dendro" -> "♧"
        "Cryo" -> "❄"
        else -> "✦"
    }
    Surface(
        onClick = onClick,
        color = if (selected) Purple.copy(alpha = .22f) else Surface,
        border = if (selected) androidx.compose.foundation.BorderStroke(1.dp, Purple) else null,
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(name, fontSize = 12.sp)
        }
    }
}

@Composable
private fun CharacterCard(c: Character, favorite: Boolean, onFavorite: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Surface)
            .clickable { }
            .padding(6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(c.tone.copy(alpha = .85f), Color(0xFF0D1120))
                    )
                )
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xCC15182A))
                    .align(Alignment.TopStart)
                    .padding(6.dp)
            ) {
                Text(elementSymbol(c.element), fontSize = 17.sp)
            }
            IconButton(
                onClick = onFavorite,
                modifier = Modifier.align(Alignment.TopEnd)
            ) {
                Icon(
                    if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    null,
                    tint = if (favorite) Color(0xFFFF5D75) else Text,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                "✦".repeat(c.stars),
                color = Color(0xFFFFD21C),
                fontSize = 10.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(7.dp)
            )
        }
        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 5.dp, start = 3.dp))
        Text("⚔  ${c.weapon}", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 3.dp, bottom = 4.dp))
    }
}

private fun elementSymbol(element: String) = when (element) {
    "Electro" -> "ϟ"
    "Hydro" -> "≋"
    "Pyro" -> "♨"
    "Geo" -> "◆"
    "Dendro" -> "♧"
    "Anemo" -> "≈"
    "Cryo" -> "❄"
    else -> "✦"
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        "Characters" to Icons.Default.AutoAwesome,
        "Weapons" to Icons.Default.ContentCut,
        "Artifacts" to Icons.Default.Hexagon,
        "Teams" to Icons.Default.Group,
        "More" to Icons.Default.MoreHoriz
    )
    NavigationBar(containerColor = Color(0xFF070B18)) {
        items.forEachIndexed { index, (label, icon) ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = { Icon(icon, null) },
                label = { Text(label, fontSize = 9.sp) }
            )
        }
    }
}

@Composable
private fun PlaceholderScreen(modifier: Modifier, title: String) {
    Box(modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Construction, null, tint = Purple, modifier = Modifier.size(50.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("This section is ready for the next data module.", color = Muted)
        }
    }
}
